<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">账面盈利计算</h2>
        <div class="mainBox">
            <Row :gutter="16">
                <Col span="19">
                    <Card style="min-height:780px">
                        <Spin id="loadBox" fix class="loadBox" v-bind:class="{ hide: isHide }">
                            <Icon type="load-c" size=40 class="loadIcon"></Icon>
                            <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                        </Spin>
                        <span id="lookInfoLink" class="lookInfo" @click="changeInfo = true">查看统计口径</span>
                        <Modal id="lookInfoPop" title="账面盈利计算  统计口径说明" v-model="changeInfo" class-name="vertical-center-modal" cancel-text>
                            <h3>数据说明</h3>
                            <p>证券选择范围：A股（暂不支持B股）、债券（不包括债券回购）、权证、基金<br>
                            A股时间范围：自1999-01-01至今<br>
                            B股时间范围：NULL<br>
                            债券时间范围：自1999-01-01至今<br>
                            权证时间范围：自1999-01-01至今<br>
                            基金时间范围：自1999-01-01至今<br>
                            </p>
                            <h3>指标说明</h3>
                            <p>新股申购：包括证券新股、证券增发、债券申购、债券配售<br>
                            累计买入、卖出：包括竞价系统、大宗交易系统的买卖，债券还包括固定收益平台的买卖数据<br>
                            印花税 = 买（卖）金额 * 买（卖）方向印花税率 ，历年印花税有所变化<br>
                            过户费 ：（A股）= 成交股数 / 1000  （B 股）=成交金额*0.05% ，其他品种=0<br>
                            佣金 = 成交金额 * 佣金费率 ，买卖方向皆收<br>
                            &nbsp;&nbsp;&nbsp;&nbsp;注：债券佣金费率为0.02%，其他按前端输入费率，前端无输入则按缺省0.3%计算
                            累计派现金额：按税前金额计算，债券还包括付息
                            配股：包括配股以及增发的配售<br>
                            违法所得 = 期末持股市值 + 累计卖出金额 + 累计派现金额 + 股改送现金金额 – 期初持股市值 – 累计买入金额 – 印花税 – 过户费 – 交易佣金估算 – 配股金额 – 新股申购金额
                            校验 = 期末持股 + 累计卖出数量 + 非交易过户转出 – 期初持股 – 累计买入数量 – 非交易过户转入 – 新股申购数量 – 累计送股数量 – 配股数量 – 股改送股
                            </p>
                            <h3>其他说明</h3>
                            <p>无</p>
                        </Modal>
                        <p id="infoTableList" class="redtext listlength">查询结果共&nbsp;{{dealitems}}&nbsp;条记录</p>
                        <Table height="680" @on-sort-change="infoTableSort" id="infoTable" :context="self" :data="tableData1" :columns="tableColumns1" size="small" ref="table" border stripe></Table>
                        <div style="text-align:right;margin-top:46px;margin-bottom:10px;">
                            <Button id="exportCurrent" type="primary" size="large" @click="exportData(1)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件</Button>
                        </div>
                        
                    </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                    <Card style="min-height:780px">
                        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                            <Row class="uploadBox proCalBtnBox">
                                <Upload action="/base-service/api/decode_upfile?uploadType=ZHYL" :headers="upfileParams" accept=".xls" :on-success="handleSuccessAccount">
                                    <Button id="importAccountBtn" type="ghost" class="uploadExcel">Excel上传</Button>
                                </Upload>
                                <Button id="lookUploadBtn"  @click="lookUploadInfo = true">查看</Button>
                                <Modal v-model="lookUploadInfo" title="查看已上传的文件" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="lookInfoTable" border stripe :columns="columnsLookInfo" :data="dataLookInfo"></Table>
                                </Modal>
                                <Button id="templateBtn"  @click="templateInfo = true">模板</Button>
                                <Modal title="账面盈利计算文件模板" v-model="templateInfo" width="684" class-name="vertical-center-modal" cancel-text>
                                    <Table id="templateTable" border stripe :columns="columnsTemplate" :data="dataTemplate"></Table>
                                </Modal>
                            </Row>
                            <div class="procalList">
                                <p>已上传记录数：<font id="infoUploadAccount" class="bluetext">{{accountList}}</font></p>
                                <p>其中有效记录数：<font id="effectiveNumber" class="bluetext">{{effectiveList}}</font></p>
                            </div>
                            <br>
                            <Row>
                                <h4>佣金费率</h4>
                                <Form-item prop="comRate" id="commissionRate">
                                    <Input-number id="commissionRateValue" :step="0.1" :max="1" :min="0" v-model="comRateValue" style="width:70%;"></Input-number>
                                    <label class="bluetext">&nbsp;&nbsp;%</label>
                                </Form-item>
                            </Row>
                            <Form-item class="showrow" prop="showrow">
                                在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p><label class="redtext fontsize12">(最多显示200行)</label></p>
                            </Form-item>
                            <Form-item>
                                <div class="cxBox"><Button id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查询</Button></div>
                            </Form-item>     
                        
                        </Form>

                    </Card>
                </Col>
            </Row>

        </div>
    </section>
</template>
<script>
import 'whatwg-fetch';  

    export default {
        //页面加载时执行
        mounted:function(){
            //获取URL地址参数
            var urlParams=window.location.href;
            var upfileParamsValue={};
            upfileParamsValue.signature=this.getUrlParams(urlParams).signature;
            this.upfileParams=upfileParamsValue;

        },
        data () {
            return {
                columnsTemplate: [
                    {
                        title: '股东账户',
                        key: 'gdAccounts',
                        width:150,
                    },
                    {
                        title: '证券代码',
                        key: 'zqCode',
                        width:100,
                    },
                    {
                        title: '开始日期',
                        key: 'startDate',
                        width:150,
                    },
                    {
                        title: '结束日期',
                        key: 'endDate',
                        width:150,
                    },
                    {
                        title: '佣金比例',
                        key: 'yjRate',
                        width:100,
                    },
                ],
                dataTemplate: [
                    {
                        gdAccounts: 'A000832200',
                        zqCode: 'ALL',
                        startDate: '20100115',
                        endDate: '20110423',
                        yjRate: 0.002,
                    },
                    {
                        gdAccounts: 'A530916975',
                        zqCode: 'ALL',
                        startDate: '20091221',
                        endDate: '20170607',
                        yjRate: 0.00025,
                    },
                    {
                        gdAccounts: 'A684165286',
                        zqCode: '600081',
                        startDate: '20091221',
                        endDate: '20170607',
                        yjRate: 0.00025,
                    },
                ],
                columnsLookInfo: [
                    {
                        title: '是否有效',
                        key: 'isEffective',
                        width:100,
                    },
                    {
                        title: '股东账户',
                        key: 'gdAccounts',
                        width:150,
                    },
                    {
                        title: '证券代码',
                        key: 'zqCode',
                        width:100,
                    },
                    {
                        title: '开始日期',
                        key: 'startDate',
                        width:150,
                    },
                    {
                        title: '结束日期',
                        key: 'endDate',
                        width:150,
                    },
                    {
                        title: '佣金比例',
                        key: 'jyRate',
                        width:100,
                    },
                    {
                        title: '说明',
                        key: 'explainInfo',
                        width:100,
                    }
                ],
                dataLookInfo: [],
                dataLookEffective: [],
                lookUploadInfo:false,
                templateInfo:false,
                comRateValue:0.3,
                changeInfo:false,
                //查询参数初始化
                testParams:{},
                orderParams:{},
                urlParams:window.location.href,
                isHide:true,
                //文件解析参数
                upfileParams:this.upfileParamsValue,
                dealitems:0,
                //上传股东账户条数
                accountList: 0,
                effectiveList:0,
                formValidate: {
                    showrow:20,                  
                },
                ruleValidate: {
                    showrow: [
                        { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                    ],
                },
                self: this,
                tableData1: [],         
                tableColumns1: [
                    {
                        title: '股东代码',
                        key: 'acctId',
                        "fixed": "left",
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '证券代码',
                        key: 'secCode',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '期初持股',
                        key: 'baseHoldBal',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期初持股市值',
                        key: 'baseMktVal',
                        "width": 200,
                        sortable: true,
                    },  
                    {
                        title: '新股申购数量',
                        key: 'orderVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '新股申购金额',
                        key: 'orderAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '累计买入数量',
                        key: 'accuBuyVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '累计买入金额',
                        key: 'accuBuyAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '累计卖出数量',
                        key: 'accuSellVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '累计卖出金额',
                        key: 'accuSellAmt',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期末持股',
                        key: 'holdBal',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期末持股市值',
                        key: 'mktVal',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '印花税',
                        key: 'stampTaxAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '过户费',
                        key: 'transFeeAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '交易佣金估算',
                        key: 'commFeeAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '实际交易佣金',
                        key: 'realCommFeeAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '累计派现金额',
                        key: 'divAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '累计送股数量',
                        key: 'shareRealVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '配股数量',
                        key: 'placingRealVol',
                        "width": 200,
                        sortable: true,
                    },  
                    {
                        title: '配股金额',
                        key: 'placingRealAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '股改送股数量',
                        key: 'shareReformRealVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '股改送现金金额',
                        key: 'reformDivAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '非交易过户转入',
                        key: 'nontradeIn',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '非交易过户转出',
                        key: 'nontradeOut',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '违法所得（按估算佣金）',
                        key: 'unlawGet',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '违法所得（按实际佣金）',
                        key: 'realUnlawGet',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '校验',
                        key: 'checkhold',
                        "width": 200,
                        sortable: true,
                    },
                ],
            }
        },
        methods: {
            //获取参数
            getUrlParams:function(url){
                var urlArray=url.split("?")[1].split("&"),
                    urlValue={};
                for(var i=0;i<urlArray.length;i++){
                    var urlRowArray=urlArray[i].split("=");
                    urlValue[urlRowArray[0]]=urlRowArray[1];
                }
                return urlValue;
            },
            //设置fetch请求超时方法
             _fetch:function(fetch_promise, timeout) {
                var abort_fn = null;
                var abortInfo=this;
                //这是一个可以被reject的promise
                var abort_promise = new Promise(function(resolve, reject) {
                        abort_fn = function() {
                            console.log('查询超时abort promise');
                            // abortInfo.$Message.warning('查询超时！请重试！');
                        };
                });
                //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
                var abortable_promise = Promise.race([
                        fetch_promise,
                        abort_promise
                ]);
                setTimeout(function() {
                        abort_fn();
                    }, timeout);
                return abortable_promise;
            }, 
            //股东账户已上传条数
            accountListChange:function(e){
                const val = e.target.value;
                const arr = val.trim().split("\n");
                const accountReg = /[A-z]\d$/g;
                let arrNew = [];
                
                for(var i = 0; i < arr.length; i++){
                   if(arr[i] == '' || typeof arr[i] == 'undefined'){
                      arr.splice(i, 1);
                      i= i-1;
                   }
                }
                this.accountList = arr.length;
            },
            //股东账号导入
            handleSuccessAccount(response, file, fileList){
                const arry = response.resData;
                console.log(arry)
                let str = '';
                let  arryAll= [];
                for(var i = 0; i < arry.length; i++){
                    arryAll.push(arry[i]);
                }
                console.log(arryAll)
                this.dataLookInfo = arryAll;
                this.accountList = arryAll.length;
                //判断是否有效
                let effectiveNum = 0;
                for(var i=0;i<arry.length;i++){
                    if(arry[i].isEffective == "true"){
                        effectiveNum ++;
                        this.dataLookEffective.push(arry[i]);
                    }
                }
                this.effectiveList = effectiveNum;

                str = arryAll.join('\n');
                this.formValidate.desc = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
            },
            //原声js写jquery方法
            hasClass:function(obj, cls){  
                return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
            },
            addClass:function(obj, cls){  
                if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
            },
            removeClass:function(obj, cls){  
                if (this.hasClass(obj, cls)) {  
                    var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                    obj.className = obj.className.replace(reg, ' ');  
                }  
            },
            toggleClass:function(obj,cls){  
                if(this.hasClass(obj,cls)){  
                    this.removeClass(obj, cls);  
                }else{  
                    this.addClass(obj, cls);  
                }  
            },
            //传排序参数
            infoTableSort:function(sort){
                orderParams.field=sort.key;
                orderParams.sort=sort.order;
            },
            //查询表单数据
            searchData:function(requestParam){
                this.orderParams={};
                this.isHide=false;
               //const url = '/dwapp/mktdt/zm_acct_gain';
              const url = '/dwapp/mktdt/zm_acct_gain1';

                this._fetch(fetch(url, {
                    method: "POST",
                    body: JSON.stringify(requestParam),
                    mode: 'cors',
                    headers: {
                        "Content-Type": "application/json",
                        "signature":this.getUrlParams(this.urlParams).signature
                    }
                }), 1800000).then(function (response) {
                    return response.json()
                }, function (error) {
                    this.$Message.error('系统繁忙，刷新页面!');
                }).then(data => {
                    var exportButton1 = document.getElementById("exportCurrent");

                    //取数据
                    var dataResponse=data.resData;
                    var dataError=data.message;
                    var datalength = data.respSize;

                    if(dataResponse == null){
                        this.isHide=true;
                        this.$Message.warning("查询出错"+dataError);
                        this.tableData1 = [];
                        this.tableData2 = [];
                        this.dealitems = 0;

                        exportButton1.setAttribute("disabled",true);

                    }else{
                        if(dataResponse.length == 0){
                            this.isHide=true;
                            this.$Message.warning('查询无数据！');
                            this.tableData1 = [];
                            this.tableData2 = [];
                            this.dealitems = 0;

                            exportButton1.setAttribute("disabled",true);
                        }else{
                            var dataArray=[];
                            this.dealitems = datalength;
                            console.log(dataResponse)

                            for(var i=0;i<dataResponse.length;i++){
                                var dataRow={};
                                for(var key in dataResponse[i]){
                                    dataRow[key] = dataResponse[i][key];
                                }
                                dataArray.push(dataRow);
                            }

                            this.tableData1 = dataArray;
                            this.tableData2 = dataArray;
                            exportButton1.removeAttribute("disabled");

                            this.isHide=true;

                        }
                    }
                })
            },
            handleSubmit (name) {
                this.$refs[name].validate((valid) => {
                    if (valid) {
                        this.$Message.success('提交成功!请等待~'); 
                                              this.testParams={
                                   
                                    "userId":this.getUrlParams(this.urlParams).userId,
                                    "userName":this.getUrlParams(this.urlParams).userName,
                                    "commRate":this.comRateValue,
                                   "limit":this.formValidate.showrow,
                                 "excelParams":this.dataLookInfo
                                };
                        console.log(this.testParams,"-----testParams111111111");
                        this.searchData(this.testParams);
                        
                    } else {
                        this.$Message.error('表单验证失败!');
                    }
                })
            },
            clearOne:function(){
                this.formValidate.desc="";
                this.accountList=0;
            },
            exportData (type) {
                //导出参数
                var downfileParams="&signature="+this.getUrlParams(this.urlParams).signature+
                "&userId="+this.getUrlParams(this.urlParams).userId+"&userName="+this.getUrlParams(this.urlParams).userName+
                "&startDate=20170101&endDate=20170101&tabType=BT&accountId=A111222133&secCode=123123"+
                "&commRate="+this.comRateValue.toString()+"&restParams={limit:"+this.formValidate.showrow.toString()+"}"
                +"&excelParams="+this.dataLookEffective;
                if (type === 1) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ACCTGAIN'+downfileParams;                    
                }
            },
        }
    }
</script>