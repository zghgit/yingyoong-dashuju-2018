<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">可疑对象分析</h2>
        <div class="mainBox oaBox">
            <Row :gutter="16">
                <Col span="19">
                <Card style="min-height:780px">
                    <Spin id="loadBox" fix class="loadBox" v-bind:class="{ hide: isHide }">
                        <Icon type="load-c" size=40 class="loadIcon"></Icon>
                        <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                    </Spin>
                    <span id="lookInfoLink" class="lookInfo" @click="changeInfo = true">查看统计口径</span>
                    <Modal id="lookInfoPop" title="可疑对象分析  统计口径说明" v-model="changeInfo" class-name="vertical-center-modal" cancel-text>
                        <h3>数据说明</h3>
                        <p>无</p>
                        <h3>指标说明</h3>
                        <p>无</p>
                        <h3>其他说明</h3>
                        <p>无</p>
                    </Modal>
                    <!--切换表格-->
                    <Tabs type="card" :animated="false" value='' v-model="tabsValue">
                        <Tab-pane label="仅统计竞价交易数据" name='onlyData' style="min-width:1015px;overflow-x:scroll;">
                            <Tabs type="card" :animated="false" style="min-width:1460px;">
                                <Tab-pane label="账户组每日交易持股分析" style="height:600px;">
                                    <p id="qiList1" class="redtext listlength">查询结果共&nbsp;{{dealitems1}}&nbsp;条记录</p>
                                    <Table height="580" @on-sort-change="infoTableSort" id="qiTable1" :context="self" :data="qiTableData1" :columns="qiTableColumns1" size="small" ref="tableOneExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent1" type="primary" size="large" @click="exportData(1)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="组内账户阶段交易持股分析" style="height:600px;">
                                    <p id="qiList2" class="redtext listlength">查询结果共&nbsp;{{dealitems2}}&nbsp;条记录</p>
                                    <Table height="580" @on-sort-change="infoTableSort" id="qiTable2" :context="self" :data="qiTableData2" :columns="qiTableColumns2" size="small" ref="tableTwoExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent2" type="primary" size="large" @click="exportData(2)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="组内账户每日交易持股分析" style="height:600px;">
                                    <p id="qiList3" class="redtext listlength">查询结果共&nbsp;{{dealitems3}}&nbsp;条记录</p>
                                    <Table height="580" @on-sort-change="infoTableSort" id="qiTable3" :context="self" :data="qiTableData3" :columns="qiTableColumns3" size="small" ref="tableThreeExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent3" type="primary" size="large" @click="exportData(3)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="组内账户每日对倒明细" style="height:600px;">
                                    <p id="qiList4" class="redtext listlength">查询结果共&nbsp;{{dealitems4}}&nbsp;条记录</p>
                                    <Table height="580" @on-sort-change="infoTableSort" id="qiTable4" :context="self" :data="qiTableData4" :columns="qiTableColumns4" size="small" ref="tableFourExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent4" type="primary" size="large" @click="exportData(4)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="图1：股价、持股、买卖占比、对倒占比" style="text-align:center;height:600px;">
                                    <div style="height:390px; overflow-y:scroll;">
                                        <p>证卷代码：
                                            <small style="color:blue;">600000 &nbsp;&nbsp;&nbsp;</small>开始日期：
                                            <small style="color:blue;">2015-04-01 &nbsp;&nbsp;&nbsp;</small>结束日期：
                                            <small style="color:blue;">2015-04-30</small>
                                        </p>
                                        <div id="myChartOneFirst" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartOneSecond" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartOneThird" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartOneForth" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartOneFifth" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="图2：股价、持股" style="text-align:center;height:600px;">
                                    <p style="margin-top:10px;">证卷代码：
                                        <small style="color:blue;">600000 &nbsp;&nbsp;&nbsp;</small>开始日期：
                                        <small style="color:blue;">2015-04-01 &nbsp;&nbsp;&nbsp;</small>结束日期：
                                        <small style="color:blue;">2015-04-30</small>
                                    </p>
                                    <div id="myChartTwo" :style="{width: '1000px', height: '400px',margin:'auto'}"></div>
                                </Tab-pane>
                                <Tab-pane label="图3：股价、交易占比" style="text-align:center;height:600px;">
                                    <p style="margin-top:10px;">证卷代码：
                                        <small style="color:blue;">600000 &nbsp;&nbsp;&nbsp;</small>开始日期：
                                        <small style="color:blue;">2015-04-01 &nbsp;&nbsp;&nbsp;</small>结束日期：
                                        <small style="color:blue;">2015-04-30</small>
                                    </p>
                                    <div id="myChartThree" :style="{width: '1000px', height: '400px',margin:'auto'}"></div>
                                </Tab-pane>
    
                            </Tabs>
                        </Tab-pane>
    
                        <Tab-pane label="统计时包含大宗交易数据" name='allData'>
                            <Tabs type="card" :animated="false">
                                <Tab-pane label="账户组每日交易持股分析" style="height:600px;">
                                    <p id="qiList8" class="redtext listlength">查询结果共&nbsp;{{dealitems8}}&nbsp;条记录</p>
                                    <Table height="600" @on-sort-change="infoTableSort" id="qiTable5" :context="self" :data="qiTableData5" :columns="qiTableColumns5" size="small" ref="tableFiveExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent5" type="primary" size="large" @click="exportData(5)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="组内账户阶段交易持股分析" style="height:600px;">
                                    <p id="qiList9" class="redtext listlength">查询结果共&nbsp;{{dealitems9}}&nbsp;条记录</p>
                                    <Table height="600" @on-sort-change="infoTableSort" id="qiTable6" :context="self" :data="qiTableData6" :columns="qiTableColumns6" size="small" ref="tableSixExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent6" type="primary" size="large" @click="exportData(6)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="组内账户每日交易持股分析" style="height:600px;">
                                    <p id="qiList10" class="redtext listlength">查询结果共&nbsp;{{dealitems10}}&nbsp;条记录</p>
                                    <Table height="600" @on-sort-change="infoTableSort" id="qiTable7" :context="self" :data="qiTableData7" :columns="qiTableColumns7" size="small" ref="tableSevenExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent7" type="primary" size="large" @click="exportData(7)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="组内账户每日对倒明细" style="height:600px;">
                                    <p id="qiList11" class="redtext listlength">查询结果共&nbsp;{{dealitems11}}&nbsp;条记录</p>
                                    <Table height="600" @on-sort-change="infoTableSort" id="qiTable8" :context="self" :data="qiTableData8" :columns="qiTableColumns8" size="small" ref="tableEightExport" border stripe></Table>
                                    <div style="position:absolute; bottom:0px;right:0px; z-index:1;">
                                        <Button id="exportCurrent8" type="primary" size="large" @click="exportData(8)" disabled>
                                            <Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件
                                        </Button>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="图1：股价、持股、买卖占比、对倒占比" style="text-align:center; height:600px;">
                                    <div style="height:390px; overflow-y:scroll;">
                                        <p>证卷代码：
                                            <small style="color:blue;">600000 &nbsp;&nbsp;&nbsp;</small>开始日期：
                                            <small style="color:blue;">2015-04-01 &nbsp;&nbsp;&nbsp;</small>结束日期：
                                            <small style="color:blue;">2015-04-30</small>
                                        </p>
                                        <div id="myChartTwoFirst" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartTwoSecond" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartTwoThird" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartTwoForth" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                        <div id="myChartTwoFifth" :style="{width: '600px', height: '400px',margin:'auto'}"></div>
                                    </div>
                                </Tab-pane>
                                <Tab-pane label="图2：股价、持股" style="text-align:center;height:600px;">
                                    <p style="margin-top:10px;">证卷代码：
                                        <small style="color:blue;">600000 &nbsp;&nbsp;&nbsp;</small>开始日期：
                                        <small style="color:blue;">2015-04-01 &nbsp;&nbsp;&nbsp;</small>结束日期：
                                        <small style="color:blue;">2015-04-30</small>
                                    </p>
                                    <div id="myChartFive" :style="{width: '1000px', height: '400px',margin:'auto'}"></div>
                                </Tab-pane>
                                <Tab-pane label="图3：股价、交易占比" style="text-align:center;height:600px;">
                                    <p style="margin-top:10px;">证卷代码：
                                        <small style="color:blue;">600000 &nbsp;&nbsp;&nbsp;</small>开始日期：
                                        <small style="color:blue;">2015-04-01 &nbsp;&nbsp;&nbsp;</small>结束日期：
                                        <small style="color:blue;">2015-04-30</small>
                                    </p>
                                    <div id="myChartSix" :style="{width: '1000px', height: '400px',margin:'auto'}"></div>
                                </Tab-pane>
    
                            </Tabs>
    
                        </Tab-pane>
    
                    </Tabs>
    
                </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                <Card style="min-height:780px">
                    <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                        <b>开始日期</b>
                        <Form-item prop="startdate" id="startDateForm">
                            <Date-picker id="startDate" type="date" :options="startOption" placeholder="选择开始日期" v-model="formValidate.startdate"></Date-picker>
                        </Form-item>
                        <b>结束日期</b>
                        <Form-item prop="enddate" id="endDateForm">
                            <Date-picker id="endDate" type="date" :options="endOption" placeholder="选择结束日期" v-model="formValidate.enddate"></Date-picker>
                        </Form-item>
                        <b>证券代码</b>
                        <Form-item prop="zqCode">
                            <Select v-model="formValidate.zqCode" filterable placeholder="请输入/选择证券代码">
                                <Option v-for="item in zqCodeList" :value="item.value" :key="item">{{ item.label }}</Option>
                            </Select>
                        </Form-item>
                        <b>股东账号</b>
                        <label class="redtext fontsize12">（不超过2500个）</label>
                        <Row class="uploadBox">
                            <Upload action="/base-service/api/decode_upfile?reportType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount">
                                <Button id="importAccountBtn" type="ghost">导入</Button>
                            </Upload>
                            <Button id="clearAccountBtn" v-on:click="clearOne()">清空</Button>
                        </Row>
                        <Row>
                            <p>已上传个数：
                                <font id="infoUploadAccount" class="bluetext">{{accountList}}</font>
                            </p>
                            <Form-item prop="desc" id="AccountForm">
                                <Input id="AccountInput" v-model="formValidate.desc" @on-change="accountListChange" type="textarea" :rows="10" placeholder="请输入股东账号"></Input>
                            </Form-item>
                        </Row>
                        <Form-item class="showrow" prop="showrow">
                            在页面上显示前&nbsp;&nbsp;
                            <Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                            <p>
                                <label class="redtext fontsize12">(最多显示200行)</label>
                            </p>
                        </Form-item>
                        <Form-item>
                            <div class="cxBox">
                                <Button id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查询</Button>
                            </div>
                        </Form-item>
    
                    </Form>
    
                </Card>
                </Col>
            </Row>
    
        </div>
    </section>
</template>
<style scoped="true">
.ivu-tabs{
    overflow:auto;
}
</style>
<script>
import 'whatwg-fetch';

//日期初始值
let lastTradeDate="";

export default {
    //页面加载时执行
    mounted: function () {
        //获取URL地址参数
        var urlParams = window.location.href;
        var upfileParamsValue = {};
        upfileParamsValue.signature = this.getUrlParams(urlParams).signature;
        this.upfileParams=upfileParamsValue;

        //证券代码联想
            this._fetch(fetch('/dwapp/mktdt/all_seccode', {
                method: "POST",
                // body: JSON.stringify(upfileParamsValue),
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json",
                    "signature":this.getUrlParams(urlParams).signature
                }
            }), 1800000).then(function (response) {
                return response.json()
            }, function (error) {
                this.$Message.error('系统繁忙，刷新页面!');
            }).then(data => {
                let codeData = data.resData,
                    zqCodeList = [];
                for(var i=0;i<codeData.length;i++){
                    let zqRow = {};
                    zqRow.value = codeData[i].secCode;
                    zqRow.label = codeData[i].value;
                    zqCodeList.push(zqRow);
                }
                console.log(zqCodeList);
                this.zqCodeList = zqCodeList;

            })

        //格式化日期
        Date.prototype.format = function(format) {
        var date = {
                "M+": this.getMonth() + 1,
                "d+": this.getDate(),
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                "S+": this.getMilliseconds()
        };
        if (/(y+)/i.test(format)) {
                format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
        }
        for (var k in date) {
                if (new RegExp("(" + k + ")").test(format)) {
                        format = format.replace(RegExp.$1, RegExp.$1.length == 1
                                ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
                }
        }
        return format;
        }

        this.drawLineTwo();
    },
    data() {
        return {
            //表单
            zqCodeList: [],
            //开始日期
            startOption: {
                disabledDate(date) {
                    return date && date.valueOf() > Date.now();
                }
            },
            //结束日期 
            endOption: {
                disabledDate(date) {
                    return date && date.valueOf() > Date.now();
                }
            },
            formValidate: {
                showrow: 20,
                startdate: new Date(this.initialDate()),
                enddate: new Date(this.initialDate()),
                desc: '',
                zqCode: '',
            },
            ruleValidate: {
                showrow: [
                    { required: true, type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                ],
                startdate: [
                    { required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }
                ],
                enddate: [
                    { required: true, type: 'date', message: '请选择结束日期', trigger: 'change' }
                ],
                desc: [
                    { required: true, message: '请输入股东账号', trigger: 'blur' },
                ],
                zqCode: [
                    { required: true, message: '请输入/选择证券代码', trigger: 'change' }
                ],
            },
            changeInfo: false,
            //查询参数初始化
            testParams: {},
            orderParams: {},
            urlParams: window.location.href,
            isHide: true,
            //文件解析参数
            upfileParams: this.upfileParamsValue,
            //上传股东账户条数
            accountList: 0,
            self: this,
            //表格数据
            dealitems1: 0,
            dealitems2: 0,
            dealitems3: 0,
            dealitems4: 0,
            dealitems5: 0,
            dealitems6: 0,
            dealitems7: 0,
            dealitems8: 0,
            dealitems9: 0,
            dealitems10: 0,
            dealitems11: 0,
            dealitems12: 0,
            dealitems13: 0,
            dealitems14: 0,
            tabsValue: 'onlyData',

            qiTableData1: [],
            qiTableData2: [],
            qiTableData3: [],
            qiTableData4: [],
            qiTableData5: [],
            qiTableData6: [],
            qiTableData7: [],
            qiTableData8: [],

            qiTableColumns1: [
                {
                    title: '证卷代码',
                    key: 'secCode',
                    width: 100,
                    sortable: true,
                },
                {
                    title: '交易日期',
                    key: 'tradeDate',
                    width: 100,
                    sortable: true,
                },
                {
                    title: '持股数量',
                    key: 'holdVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '持股占总股本比例',
                    key: 'holdVolTotPct',
                    width: 140,
                    sortable: true,
                },
                {
                    title: '持股占非限售流通股本比例',
                    key: 'holdVolNegoPct',
                    width: 190,
                    sortable: true,
                },
                {
                    title: '买入数量占比',
                    key: 'buyVolTradePct',
                    width: 110,
                    sortable: true,
                },
                {
                    title: '买入数量',
                    key: 'buyVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '买入金额',
                    key: 'buyAmt',
                    width: 120,
                    sortable: true
                },
                {
                    title: '买入均价',
                    key: 'buyPrice',
                    width: 120,
                    sortable: true
                },
                {
                    title: '卖出数量占比',
                    key: 'sellVolTradePct',
                    width: 110,
                    sortable: true,
                },
                {
                    title: '卖出数量',
                    key: 'sellVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '卖出金额',
                    key: 'sellAmt',
                    width: 120,
                    sortable: true
                },
                {
                    title: '卖出均价',
                    key: 'sellPrice',
                    width: 120,
                    sortable: true
                },
                {
                    title: '委托买入数量占比',
                    key: 'comBuyVolPct',
                    width: 160,
                    sortable: true,
                },
                {
                    title: '委托买入金额占比',
                    key: 'comBuyAmtPct',
                    width: 160,
                    sortable: true,
                },
                {
                    title: '委托买入数量',
                    key: 'comBuyVol',
                    width: 160,
                    sortable: true
                },
                {
                    title: '委托买入金额',
                    key: 'comBuyAmt',
                    width: 160,
                    sortable: true
                },
                {
                    title: '委托卖出数量占比',
                    key: 'comSellVolPct',
                    width: 160,
                    sortable: true,
                },

                {
                    title: '委托卖出数量',
                    key: 'comSellVol',
                    width: 180,
                    sortable: true
                },
                {
                    title: '委托卖出金额',
                    key: 'comSellAmt',
                    width: 180,
                    sortable: true
                },
                {
                    title: '对倒数量占比',
                    key: 'tradeVolPct',
                    width: 160,
                    sortable: true,
                },
                {
                    title: '对倒数量',
                    key: 'tradeVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '对倒金额',
                    key: 'tradeAmt',
                    width: 120,
                    sortable: true
                },

                {
                    title: '该股收盘价',
                    key: 'currPrice',
                    width: 130,
                    sortable: true
                },
                {
                    title: '市场成交总量（万股）',
                    key: 'tradeVolAll',
                    width: 190,
                    sortable: true

                },
                {
                    title: '市场成交总额（万元）',
                    key: 'tradeAmtAll',
                    width: 190,
                    sortable: true
                },
                {
                    title: '市场委托买入总量（万股）',
                    key: 'orderBVol',
                    width: 220,
                    sortable: true
                },
                {
                    title: '市场委托卖出总量（万股）',
                    key: 'orderSVol',
                    width: 220,
                    sortable: true
                },
                {
                    title: '市场委托买入总额（万元）',
                    key: 'orderBAmt',
                    width: 220,
                    sortable: true
                },
                {
                    title: '市场委托卖出总额（万元）',
                    key: 'orderSAmt',
                    width: 220,
                    sortable: true
                },
                {
                    title: '该股自由流通量（万股）',
                    key: 'freeCap',
                    width: 220,
                    sortable: true
                },
                {
                    title: '该股非限售流通股本（万股）',
                    key: 'negoCap',
                    width: 240,
                    sortable: true
                },
                {
                    title: '该股总股本（万股）',
                    key: 'totCap',
                    width: 180,
                    sortable: true
                }
            ],
            qiTableColumns2: [
                {
                    title: '股东账户',
                    key: 'acctId',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '股东名称',
                    key: 'acctName',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '期末持股数量',
                    key: 'holdVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '买入数量',
                    key: 'buyVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托买入数量',
                    key: 'comBuyVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '买入金额',
                    key: 'buyAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托买入金额',
                    key: 'comBuyAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '买入均价',
                    key: 'buyPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出数量',
                    key: 'sellVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托卖出数量',
                    key: 'comSellVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '卖出金额',
                    key: 'sellAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托卖出金额',
                    key: 'comSellAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '卖出均价',
                    key: 'sellPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒数量',
                    key: 'tradeVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒金额',
                    key: 'tradeAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒均价',
                    key: 'tradePrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '会员营业部',
                    key: 'branchName',
                    width: 120,
                    sortable: true,
                },
                {
                    title: '证件号码',
                    key: 'idCard',
                    width: 120,
                    sortable: true,
                },
            ],
            qiTableColumns3: [
                {
                    title: '交易日期',
                    key: 'tradeDate',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '股东账户',
                    key: 'acctId',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '股东名称',
                    key: 'acctName',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '持股数量',
                    key: 'holdVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '买入数量',
                    key: 'buyVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '买入金额',
                    key: 'buyAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '买入均价',
                    key: 'buyPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出数量',
                    key: 'sellVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出金额',
                    key: 'sellAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出均价',
                    key: 'sellPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒数量',
                    key: 'tradeVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒金额',
                    key: 'tradeAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒均价',
                    key: 'tradePrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托买入数量',
                    key: 'comBuyVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '委托买入金额',
                    key: 'comBuyAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '委托卖出数量',
                    key: 'comSellVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '委托卖出金额',
                    key: 'comSellAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '证件号码',
                    key: 'idCard',
                    width: 120,
                    sortable: true,
                },
            ],
            qiTableColumns4: [
                {
                    title: '交易日期',
                    key: 'tradeDate',
                    width: 135,
                    sortable: true,
                },
                {
                    title: '成交时间',
                    key: 'tradeTime',
                    width: 135,
                    sortable: true,
                },
                {
                    title: '成交编号',
                    key: 'tradeNo',
                    width: 135,
                    sortable: true,
                },
                {
                    title: '卖方股东账户',
                    key: 'sellAcctId',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '卖方股东名称',
                    key: 'sellAcctName',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '买方股东账户',
                    key: 'buyAcctId',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '买方股东名称',
                    key: 'buyAcctName',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '成交数量',
                    key: 'tradeVol',
                    width: 155,
                    sortable: true
                },
                {
                    title: '成交金额',
                    key: 'tradeAmt',
                    width: 155,
                    sortable: true
                },
                {
                    title: '卖方证件号码',
                    key: 'sellIdCard',
                    width: 160,
                    sortable: true,

                },
                {
                    title: '买方证件号码',
                    key: 'buyIdCard',
                    width: 160,
                    sortable: true,
                },
            ],
             qiTableColumns5: [
                {
                    title: '证卷代码',
                    key: 'secCode',
                    width: 100,
                    sortable: true,
                },
                {
                    title: '交易日期',
                    key: 'tradeDate',
                    width: 100,
                    sortable: true,
                },
                {
                    title: '持股数量',
                    key: 'holdVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '持股占总股本比例',
                    key: 'holdVolTotPct',
                    width: 140,
                    sortable: true,
                },
                {
                    title: '持股占非限售流通股本比例',
                    key: 'holdVolNegoPct',
                    width: 190,
                    sortable: true,
                },
                {
                    title: '买入数量占比',
                    key: 'buyVolTradePct',
                    width: 110,
                    sortable: true,
                },
                {
                    title: '买入数量',
                    key: 'buyVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '买入金额',
                    key: 'buyAmt',
                    width: 120,
                    sortable: true
                },
                {
                    title: '买入均价',
                    key: 'buyPrice',
                    width: 120,
                    sortable: true
                },
                {
                    title: '卖出数量占比',
                    key: 'sellVolTradePct',
                    width: 110,
                    sortable: true,
                },
                {
                    title: '卖出数量',
                    key: 'sellVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '卖出金额',
                    key: 'sellAmt',
                    width: 120,
                    sortable: true
                },
                {
                    title: '卖出均价',
                    key: 'sellPrice',
                    width: 120,
                    sortable: true
                },
                {
                    title: '委托买入数量占比',
                    key: 'comBuyVolPct',
                    width: 160,
                    sortable: true,
                },
                {
                    title: '委托买入金额占比',
                    key: 'comBuyAmtPct',
                    width: 160,
                    sortable: true,
                },
                {
                    title: '委托买入数量',
                    key: 'comBuyVol',
                    width: 160,
                    sortable: true
                },
                {
                    title: '委托买入金额',
                    key: 'comBuyAmt',
                    width: 160,
                    sortable: true
                },
                {
                    title: '委托卖出数量占比',
                    key: 'comSellVolPct',
                    width: 160,
                    sortable: true,
                },

                {
                    title: '委托卖出数量',
                    key: 'comSellVol',
                    width: 180,
                    sortable: true
                },
                {
                    title: '委托卖出金额',
                    key: 'comSellAmt',
                    width: 180,
                    sortable: true
                },
                {
                    title: '对倒数量占比',
                    key: 'tradeVolPct',
                    width: 160,
                    sortable: true,
                },
                {
                    title: '对倒数量',
                    key: 'tradeVol',
                    width: 120,
                    sortable: true
                },
                {
                    title: '对倒金额',
                    key: 'tradeAmt',
                    width: 120,
                    sortable: true
                },

                {
                    title: '该股收盘价',
                    key: 'currPrice',
                    width: 130,
                    sortable: true
                },
                {
                    title: '市场成交总量（万股）',
                    key: 'tradeVolAll',
                    width: 190,
                    sortable: true

                },
                {
                    title: '市场成交总额（万元）',
                    key: 'tradeAmtAll',
                    width: 190,
                    sortable: true
                },
                {
                    title: '市场委托买入总量（万股）',
                    key: 'orderBVol',
                    width: 220,
                    sortable: true
                },
                {
                    title: '市场委托卖出总量（万股）',
                    key: 'orderSVol',
                    width: 220,
                    sortable: true
                },
                {
                    title: '市场委托买入总额（万元）',
                    key: 'orderBAmt',
                    width: 220,
                    sortable: true
                },
                {
                    title: '市场委托卖出总额（万元）',
                    key: 'orderSAmt',
                    width: 220,
                    sortable: true
                },
                {
                    title: '该股自由流通量（万股）',
                    key: 'freeCap',
                    width: 220,
                    sortable: true
                },
                {
                    title: '该股非限售流通股本（万股）',
                    key: 'negoCap',
                    width: 240,
                    sortable: true
                },
                {
                    title: '该股总股本（万股）',
                    key: 'totCap',
                    width: 180,
                    sortable: true
                }
            ],
            qiTableColumns6: [
                {
                    title: '股东账户',
                    key: 'acctId',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '股东名称',
                    key: 'acctName',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '期末持股数量',
                    key: 'holdVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '买入数量',
                    key: 'buyVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托买入数量',
                    key: 'comBuyVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '买入金额',
                    key: 'buyAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托买入金额',
                    key: 'comBuyAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '买入均价',
                    key: 'buyPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出数量',
                    key: 'sellVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托卖出数量',
                    key: 'comSellVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '卖出金额',
                    key: 'sellAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托卖出金额',
                    key: 'comSellAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '卖出均价',
                    key: 'sellPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒数量',
                    key: 'tradeVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒金额',
                    key: 'tradeAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒均价',
                    key: 'tradePrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '会员营业部',
                    key: 'branchName',
                    width: 120,
                    sortable: true,
                },
                {
                    title: '证件号码',
                    key: 'idCard',
                    width: 120,
                    sortable: true,
                },
            ],
            qiTableColumns7: [
                {
                    title: '交易日期',
                    key: 'tradeDate',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '股东账户',
                    key: 'acctId',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '股东名称',
                    key: 'acctName',
                    width: 90,
                    sortable: true,
                },
                {
                    title: '持股数量',
                    key: 'holdVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '买入数量',
                    key: 'buyVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '买入金额',
                    key: 'buyAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '买入均价',
                    key: 'buyPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出数量',
                    key: 'sellVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出金额',
                    key: 'sellAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '卖出均价',
                    key: 'sellPrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒数量',
                    key: 'tradeVol',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒金额',
                    key: 'tradeAmt',
                    width: 110,
                    sortable: true
                },
                {
                    title: '对倒均价',
                    key: 'tradePrice',
                    width: 110,
                    sortable: true
                },
                {
                    title: '委托买入数量',
                    key: 'comBuyVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '委托买入金额',
                    key: 'comBuyAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '委托卖出数量',
                    key: 'comSellVol',
                    width: 140,
                    sortable: true
                },
                {
                    title: '委托卖出金额',
                    key: 'comSellAmt',
                    width: 140,
                    sortable: true
                },
                {
                    title: '证件号码',
                    key: 'idCard',
                    width: 120,
                    sortable: true,
                },
            ],
            qiTableColumns8: [
                {
                    title: '交易日期',
                    key: 'tradeDate',
                    width: 135,
                    sortable: true,
                },
                {
                    title: '成交时间',
                    key: 'tradeTime',
                    width: 135,
                    sortable: true,
                },
                {
                    title: '成交编号',
                    key: 'tradeNo',
                    width: 135,
                    sortable: true,
                },
                {
                    title: '卖方股东账户',
                    key: 'sellAcctId',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '卖方股东名称',
                    key: 'sellAcctName',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '买方股东账户',
                    key: 'buyAcctId',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '买方股东名称',
                    key: 'buyAcctName',
                    width: 177,
                    sortable: true,
                },
                {
                    title: '成交数量',
                    key: 'tradeVol',
                    width: 155,
                    sortable: true
                },
                {
                    title: '成交金额',
                    key: 'tradeAmt',
                    width: 155,
                    sortable: true
                },
                {
                    title: '卖方证件号码',
                    key: 'sellIdCard',
                    width: 160,
                    sortable: true,

                },
                {
                    title: '买方证件号码',
                    key: 'buyIdCard',
                    width: 160,
                    sortable: true,
                },
            ],
        }
    },
    methods: {

        // 使用表格数据
        drawLineOne() {
            let myChartOneFirst = this.$echarts.init(document.getElementById('myChartOneFirst'));
            var startdateValue = this.formValidate.startdate;

            var startdate = startdateValue.format('yyyy-MM-dd');
            console.log(startdate)

            var data0 = splitData([

                ['2013/5/28', 2293.4, 2321.32, 2281.47, 2322.1],
                ['2013/5/29', 2323.54, 2324.02, 2321.17, 2334.33],
                ['2013/5/30', 2316.25, 2317.75, 2310.49, 2325.72],
                ['2013/5/31', 2320.74, 2300.59, 2299.37, 2325.53],
                ['2013/6/3', 2300.21, 2299.25, 2294.11, 2313.43],
                ['2013/6/4', 2297.1, 2272.42, 2264.76, 2297.1],
                ['2013/6/5', 2270.71, 2270.93, 2260.87, 2276.86],
                ['2013/6/6', 2264.43, 2242.11, 2240.07, 2266.69],
                ['2013/6/7', 2242.26, 2210.9, 2205.07, 2250.63],
                ['2013/6/13', 2190.1, 2148.35, 2126.22, 2190.1]
            ]);


            function splitData(rawData) {
                var categoryData = [];
                var values = []
                for (var i = 0; i < rawData.length; i++) {
                    categoryData.push(rawData[i].splice(0, 1)[0]);
                    values.push(rawData[i])
                }
                return {
                    categoryData: categoryData,
                    values: values
                };
            }

            function calculateMA(dayCount) {
                var result = [];
                for (var i = 0, len = data0.values.length; i < len; i++) {
                    if (i < dayCount) {
                        result.push('-');
                        continue;
                    }
                    var sum = 0;
                    for (var j = 0; j < dayCount; j++) {
                        sum += data0.values[i - j][1];
                    }
                    result.push(sum / dayCount);
                }
                return result;
            }


            myChartOneFirst.setOption({
                grid: {
                    left: '10%',
                    right: '10%',
                    bottom: '15%'
                },
                xAxis: {
                    type: 'category',
                    data: data0.categoryData,
                    scale: true,
                    boundaryGap: false,
                    axisLine: {
                        onZero: false,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                    splitLine: { show: false },
                    splitNumber: 20,
                    min: 'dataMin',
                    max: 'dataMax'
                },
                yAxis: {
                    scale: true,
                    splitArea: {
                        show: true
                    },
                    name: '日K线',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }
                },

                series: [
                    {
                        name: '日K',
                        type: 'candlestick',
                        data: data0.values,


                    },


                ]
            });

            let myChartOneSecond = this.$echarts.init(document.getElementById('myChartOneSecond'));
            // app.title = '坐标轴刻度与标签对齐';
            myChartOneSecond.setOption({
                color: ['#3398DB'],

                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ['', '', '', '', '', '', ''],
                        axisLine: {
                            onZero: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        },

                    }
                ],
                yAxis: [
                    {
                        type: 'value',
                        name: '市场成交量（万股）',
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }
                ],
                series: [
                    {

                        type: 'bar',
                        barWidth: '60%',
                        data: [10000, 20000, 30000, 40000, 60000]
                    }
                ]
            });

            let myChartOneThird = this.$echarts.init(document.getElementById('myChartOneThird'))

            myChartOneThird.setOption({

                xAxis: {
                    type: 'category',
                    name: '',
                    splitLine: { show: false },
                    data: ['',],
                    axisLine: {
                        onZero: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                yAxis: {
                    type: 'log',
                    name: '持股量',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }

                },
                series: [
                    {
                        name: '',
                        type: 'line',
                        data: [-1, 0, 5, 0, 0, 0,]
                    },

                ]
            });
            let myChartOneForth = this.$echarts.init(document.getElementById('myChartOneForth'))

            myChartOneForth.setOption({
                xAxis: {
                    type: 'category',
                    name: '',
                    splitLine: { show: false },
                    data: ['',],
                    axisLine: {
                        onZero: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                yAxis: {
                    type: 'log',
                    name: '买入占比、卖出占比',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }

                },
                series: [
                    {
                        name: '',
                        type: 'line',
                        data: [-1, 0, 5, 0, 0, 0,]
                    },

                ]
            });

            let myChartOneFifth = this.$echarts.init(document.getElementById('myChartOneFifth'))

            myChartOneFifth.setOption({
                xAxis: {
                    type: 'category',
                    name: '',
                    splitLine: { show: false },
                    data: ['',],
                    axisLine: {
                        onZero: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                yAxis: {
                    type: 'log',
                    name: '对倒占比',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }

                },
                series: [
                    {
                        name: '',
                        type: 'line',
                        data: [-1, 0, 5, 0, 0, 0,]
                    },

                ]
            });

            // 基于准备好的dom，初始化echarts实例
            let myChartTwo = this.$echarts.init(document.getElementById('myChartTwo'))
            var symbolSize = 20;
            var data = [[15, 0], [-50, 10], [-56.5, 20], [-46.5, 30], [-22.1, 40]];
            var points = [];
            // 绘制图表
            myChartTwo.setOption({


                tooltip: {
                    trigger: 'none',
                    axisPointer: {
                        type: 'cross'
                    }
                },
                legend: {
                    show: true,
                    buttom: 'auto',
                    data: [{
                        name: '持股量',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }, {
                        name: '收盘价',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }]
                },

                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis:
                {
                    min: -60,
                    max: 20,
                    type: 'value',
                    axisLine: {
                        onZero: false,
                        lineStyle: {
                            color: 'black'
                        }
                    }
                },

                yAxis: [
                    {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'blue'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }, {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'red'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    },

                ],

                series: [
                    {
                        name: '持股量',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    },
                    {
                        name: '收盘价',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    }

                ],

            });


            let myChartThree = this.$echarts.init(document.getElementById('myChartThree'))
            var symbolSize = 20;
            var data = [[15, 0], [-50, 10], [-56.5, 20], [-46.5, 30], [-22.1, 40]];
            var points = [];
            // 绘制图表
            myChartThree.setOption({
                tooltip: {
                    trigger: 'none',
                    axisPointer: {
                        type: 'cross'
                    }
                },
                legend: {
                    show: true,
                    buttom: 'auto',
                    data: [{
                        name: '交易占比',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }, {
                        name: '收盘价',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }]
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis:
                {
                    min: -60,
                    max: 20,
                    type: 'value',
                    axisLine: {
                        onZero: false, lineStyle: {
                            color: 'black'
                        }
                    }
                },

                yAxis: [
                    {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'blue'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }, {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'red'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }
                ],



                series: [
                    {
                        name: '交易占比',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    },
                    {
                        name: '收盘价',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    }

                ]
            });
        },
        drawLineTwo() {

            let myChartTwoFirst = this.$echarts.init(document.getElementById('myChartTwoFirst'));
            var startdateValue = this.formValidate.startdate;

            var startdate = startdateValue.format('yyyy-MM-dd');
            console.log(startdate)

            var data0 = splitData([

                ['2013/5/28', 2293.4, 2321.32, 2281.47, 2322.1],
                ['2013/5/29', 2323.54, 2324.02, 2321.17, 2334.33],
                ['2013/5/30', 2316.25, 2317.75, 2310.49, 2325.72],
                ['2013/5/31', 2320.74, 2300.59, 2299.37, 2325.53],
                ['2013/6/3', 2300.21, 2299.25, 2294.11, 2313.43],
                ['2013/6/4', 2297.1, 2272.42, 2264.76, 2297.1],
                ['2013/6/5', 2270.71, 2270.93, 2260.87, 2276.86],
                ['2013/6/6', 2264.43, 2242.11, 2240.07, 2266.69],
                ['2013/6/7', 2242.26, 2210.9, 2205.07, 2250.63],
                ['2013/6/13', 2190.1, 2148.35, 2126.22, 2190.1]
            ]);


            function splitData(rawData) {
                var categoryData = [];
                var values = []
                for (var i = 0; i < rawData.length; i++) {
                    categoryData.push(rawData[i].splice(0, 1)[0]);
                    values.push(rawData[i])
                }
                return {
                    categoryData: categoryData,
                    values: values
                };
            }

            function calculateMA(dayCount) {
                var result = [];
                for (var i = 0, len = data0.values.length; i < len; i++) {
                    if (i < dayCount) {
                        result.push('-');
                        continue;
                    }
                    var sum = 0;
                    for (var j = 0; j < dayCount; j++) {
                        sum += data0.values[i - j][1];
                    }
                    result.push(sum / dayCount);
                }
                return result;
            }


            myChartTwoFirst.setOption({
                grid: {
                    left: '10%',
                    right: '10%',
                    bottom: '15%'
                },
                xAxis: {
                    type: 'category',
                    data: data0.categoryData,
                    scale: true,
                    boundaryGap: false,
                    axisLine: {
                        onZero: false,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                    splitLine: { show: false },
                    splitNumber: 20,
                    min: 'dataMin',
                    max: 'dataMax'
                },
                yAxis: {
                    scale: true,
                    splitArea: {
                        show: true
                    },
                    name: '日K线',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }
                },

                series: [
                    {
                        name: '日K',
                        type: 'candlestick',
                        data: data0.values,


                    },


                ]
            });

            let myChartTwoSecond = this.$echarts.init(document.getElementById('myChartTwoSecond'));
            // app.title = '坐标轴刻度与标签对齐';
            myChartTwoSecond.setOption({
                color: ['#3398DB'],

                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: [
                    {
                        type: 'category',
                        data: ['', '', '', '', '', '', ''],
                        axisLine: {
                            onZero: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        },

                    }
                ],
                yAxis: [
                    {
                        type: 'value',
                        name: '市场成交量（万股）',
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }
                ],
                series: [
                    {

                        type: 'bar',
                        barWidth: '60%',
                        data: [10000, 20000, 30000, 40000, 60000]
                    }
                ]
            });

            let myChartTwoThird = this.$echarts.init(document.getElementById('myChartTwoThird'))

            myChartTwoThird.setOption({

                xAxis: {
                    type: 'category',
                    name: '',
                    splitLine: { show: false },
                    data: ['',],
                    axisLine: {
                        onZero: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                yAxis: {
                    type: 'log',
                    name: '持股量',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }

                },
                series: [
                    {
                        name: '',
                        type: 'line',
                        data: [-1, 0, 5, 0, 0, 0,]
                    },

                ]
            });
            let myChartTwoForth = this.$echarts.init(document.getElementById('myChartTwoForth'))

            myChartTwoForth.setOption({
                xAxis: {
                    type: 'category',
                    name: '',
                    splitLine: { show: false },
                    data: ['',],
                    axisLine: {
                        onZero: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                yAxis: {
                    type: 'log',
                    name: '买入占比、卖出占比',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }

                },
                series: [
                    {
                        name: '',
                        type: 'line',
                        data: [-1, 0, 5, 0, 0, 0,]
                    },

                ]
            });

            let myChartTwoFifth = this.$echarts.init(document.getElementById('myChartTwoFifth'))

            myChartTwoFifth.setOption({
                xAxis: {
                    type: 'category',
                    name: '',
                    splitLine: { show: false },
                    data: ['',],
                    axisLine: {
                        onZero: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    },
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                yAxis: {
                    type: 'log',
                    name: '对倒占比',
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#FFC0CB'
                        }
                    }

                },
                series: [
                    {
                        name: '',
                        type: 'line',
                        data: [-1, 0, 5, 0, 0, 0,]
                    },

                ]
            });

            // 基于准备好的dom，初始化echarts实例
            let myChartFive = this.$echarts.init(document.getElementById('myChartFive'))
            var symbolSize = 20;
            var data = [[15, 0], [-50, 10], [-56.5, 20], [-46.5, 30], [-22.1, 40]];
            var points = [];
            // 绘制图表
            myChartFive.setOption({


                tooltip: {
                    trigger: 'none',
                    axisPointer: {
                        type: 'cross'
                    }
                },
                legend: {
                    show: true,
                    buttom: 'auto',
                    data: [{
                        name: '持股量',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }, {
                        name: '收盘价',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }]
                },

                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis:
                {
                    min: -60,
                    max: 20,
                    type: 'value',
                    axisLine: {
                        onZero: false,
                        lineStyle: {
                            color: 'black'
                        }
                    }
                },

                yAxis: [
                    {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'blue'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }, {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'red'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    },

                ],

                series: [
                    {
                        name: '持股量',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    },
                    {
                        name: '收盘价',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    }

                ],

            });


            let myChartSix = this.$echarts.init(document.getElementById('myChartSix'))
            var symbolSize = 20;
            var data = [[15, 0], [-50, 10], [-56.5, 20], [-46.5, 30], [-22.1, 40]];
            var points = [];
            // 绘制图表
            myChartSix.setOption({
                tooltip: {
                    trigger: 'none',
                    axisPointer: {
                        type: 'cross'
                    }
                },
                legend: {
                    show: true,
                    buttom: 'auto',
                    data: [{
                        name: '交易占比',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }, {
                        name: '收盘价',
                        z: 1,
                        icon: 'rect',
                        textStyle: 'black'
                    }]
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis:
                {
                    min: -60,
                    max: 20,
                    type: 'value',
                    axisLine: {
                        onZero: false, lineStyle: {
                            color: 'black'
                        }
                    }
                },

                yAxis: [
                    {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'blue'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }, {
                        min: 0,
                        max: 40,
                        type: 'value',
                        axisLine: {
                            onZero: false, lineStyle: {
                                color: 'red'
                            }
                        },
                        splitLine: {
                            show: true,
                            lineStyle: {
                                color: '#FFC0CB'
                            }
                        }
                    }
                ],



                series: [
                    {
                        name: '交易占比',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    },
                    {
                        name: '收盘价',
                        type: 'line',
                        smooth: true,
                        symbolSize: symbolSize,
                        data: data
                    }

                ]
            });





        },

        //请求初始日期
        initialDate: function () {
            var obj=new XMLHttpRequest();
                obj.open('GET','/base-service/api/predate',false);
                obj.setRequestHeader("signature","20170515XXDW");
                obj.onreadystatechange=function(){
                    if(obj.readyState == 4 && obj.status == 200){
                        const responseData=JSON.parse(obj.responseText);
                        //上一个交易日
                        lastTradeDate = responseData.resData.lastTradeDate;
                        lastTradeDate = lastTradeDate.slice(0,4)+"-"+lastTradeDate.slice(4,6)+"-"+lastTradeDate.slice(6,8);
                    }
                };
                obj.send(null);
                return lastTradeDate;
        },
        //获取参数
        getUrlParams: function (url) {
            var urlArray = url.split("?")[1].split("&"),
                urlValue = {};
            for (var i = 0; i < urlArray.length; i++) {
                var urlRowArray = urlArray[i].split("=");
                urlValue[urlRowArray[0]] = urlRowArray[1];
            }
            return urlValue;
        },
        //设置fetch请求超时方法
        _fetch: function (fetch_promise, timeout) {
            var abort_fn = null;
            var abortInfo = this;
            //这是一个可以被reject的promise
            var abort_promise = new Promise(function (resolve, reject) {
                abort_fn = function () {
                    console.log('查询超时abort promise');
                    // abortInfo.$Message.warning('查询超时！请重试！');
                };
            });
            //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
            var abortable_promise = Promise.race([
                fetch_promise,
                abort_promise
            ]);
            setTimeout(function () {
                abort_fn();
            }, timeout);
            return abortable_promise;
        },
        //股东账户已上传条数
        accountListChange: function (e) {
            const val = e.target.value;
            const arr = val.trim().split("\n");
            const accountReg = /[A-z]\d$/g;
            let arrNew = [];

            for (var i = 0; i < arr.length; i++) {
                if (arr[i] == '' || typeof arr[i] == 'undefined') {
                    arr.splice(i, 1);
                    i = i - 1;
                }
            }
            this.accountList = arr.length;
        },
        //股东账号导入
        handleSuccessAccount(response, file, fileList) {
            const arry = response.resData;
            console.log(arry)
            let str = '';
            let  arryAll= [];
            for(var i = 0; i < arry.length; i++){
                arryAll.push(arry[i]);
            }
            console.log(arryAll)
            this.dataLookInfo = arryAll
            this.accountList = arryAll.length;
            str = arryAll.join('\n');
            this.formValidate.desc = str;
            if(response.message != null){
                this.$Message.warning(response.message);
            }

        },
        //原声js写jquery方法
        hasClass: function (obj, cls) {
            return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
        },
        addClass: function (obj, cls) {
            if (!this.hasClass(obj, cls)) obj.className += " " + cls;
        },
        removeClass: function (obj, cls) {
            if (this.hasClass(obj, cls)) {
                var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
                obj.className = obj.className.replace(reg, ' ');
            }
        },
        toggleClass: function (obj, cls) {
            if (this.hasClass(obj, cls)) {
                this.removeClass(obj, cls);
            } else {
                this.addClass(obj, cls);
            }
        },
        //传排序参数
        infoTableSort: function (sort) {
            orderParams.field = sort.key;
            orderParams.sort = sort.order;
        },
        //查询表单数据
        // 查询数据
        searchData: function () {
            // var form = this.$('#form').serialize()
            // console.log(form)
            this.isHide = false;
            var exportCurrent = document.getElementById("exportCurrent");
            console.log("---22222---------------------");
            var exportCurrentOne = document.getElementById("exportCurrentOne");
            var exportCurrentTwo = document.getElementById("exportCurrentTwo");

            //获取URL地址参数
            var urlParams = window.location.href;
            var upfileParamsValue = {};
            upfileParamsValue.signature = getUrlParams(urlParams).signature;
            this.upfileParams = upfileParamsValue;
            //导出参数
            // var downfileParams = "&signature=" + getUrlParams(urlParams).signature + "&userId=" + getUrlParams(urlParams).userId + "&userName=" + getUrlParams(urlParams).userName;
            function getUrlParams(urlParams) {
                var urlArray = urlParams.split("?")[1].split("&"),
                    urlValue = {};
                for (var i = 0; i < urlArray.length; i++) {
                    var urlRowArray = urlArray[i].split("=");
                    urlValue[urlRowArray[0]] = urlRowArray[1];
                }
                console.log(JSON.stringify(urlValue));
                return urlValue;
            }
            console.log(this.tabsValue)

            var startdateValue = this.formValidate.startdate;

            var startdate = startdateValue.format('yyyy-MM-dd');
            console.log(startdate);
            var enddateValue = this.formValidate.enddate;

            var endDate = enddateValue.format('yyyy-MM-dd');
            console.log(endDate);

            console.log(this.formValidate.desc);

            console.log(this.formValidate.zqCode);

            const descStr = this.formValidate.desc.replace(/[\r\n]/g,',');
            let descArry = descStr.split(',');
            let codelist=this.formValidate.zqCode.split(',');

            var testParams={
"startDate":startdate,
"endDate":endDate,
"userId":this.getUrlParams(this.urlParams).userId,
"userName":this.getUrlParams(this.urlParams).userName,
 "accountId":descArry,
 "secCode":codelist,
"limit":this.formValidate.showrow

}

            if (this.tabsValue == 'onlyData') {
               // this.drawLineOne();

                //获取数据
               // const url = 'http://api.iia.cbpass.net/GetFillData3';
               // const url = 'http://localhost:18002/dwapp/mktdt/so_all';
                const url = '/dwapp/mktdt/so_all';
                fetch(url, {
                    method: "POST",
                     body: JSON.stringify(testParams),
                    mode: 'cors',
                    headers: {
                        "Content-Type": "application/json",
                         "signature":this.getUrlParams(this.urlParams).signature
                    }
                }).then(function (response) {
                    return response.json()
                }, function (error) {
                    console.log(error)
                }).then(data => {
                    exportCurrentOne.removeAttribute("disabled");

                    var dataResponse1 = data.resData.tabList1.data;
                    this.dealitems1=data.resData.tabList1.size;
                    const table = this.table
                    var tableValue = table
                    var dataArray = [];
                    for (var i = 0; i < dataResponse1.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse1[i]) {
                            dataRow[key] = dataResponse1[i][key];
                        }
                        dataArray.push(dataRow);
                    }
                    var dataResponse2 = data.resData.tabList2.data;
                     this.dealitems2=data.resData.tabList2.size;
                     var dataArray2 = [];
                    for (var i = 0; i < dataResponse2.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse2[i]) {
                            dataRow[key] = dataResponse2[i][key];
                        }
                        dataArray2.push(dataRow);
                    }
                    var dataResponse3 = data.resData.tabList3.data;
                    this.dealitems3=data.resData.tabList3.size;
                     var dataArray3 = [];
                    for (var i = 0; i < dataResponse3.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse3[i]) {
                            dataRow[key] = dataResponse3[i][key];
                        }
                        dataArray3.push(dataRow);
                    }
                     var dataResponse4= data.resData.tabList4.data;
                     this.dealitems4=data.resData.tabList4.size;
                     var dataArray4 = [];
                    for (var i = 0; i < dataResponse4.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse4[i]) {
                            dataRow[key] = dataResponse4[i][key];
                        }
                        dataArray4.push(dataRow);
                    }
                     var dataResponse5= data.resData.tabList5.data;
                     this.dealitems8=data.resData.tabList5.size;
                     var dataArray5 = [];
                    for (var i = 0; i < dataResponse5.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse5[i]) {
                            dataRow[key] = dataResponse5[i][key];
                        }
                        dataArray5.push(dataRow);
                    }
                    var dataResponse6= data.resData.tabList6.data;
                    this.dealitems9=data.resData.tabList6.size;
                     var dataArray6 = [];
                    for (var i = 0; i < dataResponse6.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse6[i]) {
                            dataRow[key] = dataResponse6[i][key];
                        }
                        dataArray6.push(dataRow);
                    }
                     var dataResponse7= data.resData.tabList7.data;
                     this.dealitems10=data.resData.tabList7.size;
                     var dataArray7 = [];
                    for (var i = 0; i < dataResponse7.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse7[i]) {
                            dataRow[key] = dataResponse7[i][key];
                        }
                        dataArray7.push(dataRow);
                    }
                    var dataResponse8= data.resData.tabList8.data;
                    this.dealitems11=data.resData.tabList8.size;
                     var dataArray8 = [];
                    for (var i = 0; i < dataResponse8.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse8[i]) {
                            dataRow[key] = dataResponse8[i][key];
                        }
                        dataArray8.push(dataRow);
                    }
                    this.qiTableData1 = dataArray;
                    this.qiTableData2 = dataArray2;
                    this.qiTableData3 = dataArray3;
                    this.qiTableData4 = dataArray4;
                    this.qiTableData5 = dataArray5;
                    this.qiTableData6 = dataArray6;
                    this.qiTableData7 = dataArray7;
                    this.qiTableData8 = dataArray8;

                    if (dataArray.length > 0) {
                        this.isHide = true;
                    }

                })
            }
            if (this.tabsValue == 'allData') {

             //   this.drawLineTwo();
                //获取数据
               // const url = 'http://api.iia.cbpass.net/GetFillData3';
              // const url = 'http://localhost:18002/dwapp/mktdt/so_all';
               const url = '/dwapp/mktdt/so_all';
                fetch(url, {
                    method: "POST",
                    mode: 'cors',
                     body: JSON.stringify(testParams),
                    headers: {
                        "Content-Type": "application/json",
                        "signature":this.getUrlParams(this.urlParams).signature
                    }
                }).then(function (response) {
                    return response.json()
                }, function (error) {
                    console.log(error)
                }).then(data => {
                    exportCurrentTwo.removeAttribute("disabled");

                    var dataResponse = data.Data.Sets1;
                    const table = this.table
                    var tableValue = table
                    var dataArray = [];
                    for (var i = 0; i < dataResponse.length; i++) {
                        var dataRow = {};
                        for (var key in dataResponse[i]) {
                            dataRow[key] = dataResponse[i][key];
                        }
                        dataArray.push(dataRow);
                    }
                    this.qiTableData5 = dataArray;
                    this.qiTableData6 = dataArray;
                    this.qiTableData7 = dataArray;
                    this.qiTableData8 = dataArray;

                    if (dataArray.length > 0) {
                        this.isHide = true;
                    }

                })
            }
        },
        handleSubmit(name) {
            this.$refs[name].validate((valid) => {
                const { desc } = this.formValidate;
                var descValue = desc;
                //股东账号  10 一个大写字母  9个数字
                if (this.formValidate.desc) {
                    const descStr = descValue.replace(/[\r\n]/g, ',');
                    let descArry = descStr.split(',');
                    //判断上传股东账户不能超过2500
                    if (descArry.length > 2500) {
                        this.$Message.error('股东账号不能超过2500个!');
                        return;
                    }
                    for (var i = 0; i < descArry.length; i++) {
                        const descVal = descArry[i].trim();
                        const descReg = /^[A-Z]{1}\d{9}/g;
                        if (!descReg.test(descVal) || descVal.length != 10) {
                            this.$Message.error('股东账号由一个大写字母和9个数字组成！');//AccountForm
                            this.addClass(document.getElementById('AccountForm'), 'ivu-form-item-error');
                            return;
                        }
                    }
                    this.removeClass(document.getElementById('AccountForm'), 'ivu-form-item-error');
                    // descValue = descArry.join(',');
                    descValue = descArry;
                }

                if (valid) {
                    this.$Message.success('提交成功!请等待~');
                    //获取请求参数
                    this.testParams = {
                    "startDate":"20170101",
                    "endDate":"20170101",
                    "limit":this.formValidate.showrow.toString(),
                      "accountId":["A111222133"],
                      "secCode":["123123"],
                      
                        "userId": this.getUrlParams(this.urlParams).userId, "userName": this.getUrlParams(this.urlParams).userName
                    }
                    console.log(this.testParams, "-----testParams111111111");
                    // this.searchData(this.testParams);
                    this.searchData();


                } else {
                    this.$Message.error('表单验证失败!');
                }
            })
        },
        clearOne: function () {
            this.formValidate.desc = "";
            this.accountList = 0;
        },
        exportData (type) {
            //导出参数
            var downfileParams="&signature="+this.getUrlParams(this.urlParams).signature+
            "&userId="+this.getUrlParams(this.urlParams).userId+"&userName="+this.getUrlParams(this.urlParams).userName+
            "&startDate=20180620&endDate=20180620&accountId=A111111111,A222222222&secCode=123123"+
            "&limit="+this.formValidate.showrow.toString();
            if (type === 1) {
                window.location.href='/dwapp/download/dwapp_downfile?reportType=DOUBTDAYBACK&fileType=xlsx'+downfileParams;                    
            } else if (type === 2) {
                window.location.href='/dwapp/download/dwapp_downfile?reportType=DOUBTDAYTRADE&fileType=xlsx'+downfileParams; 
            } else if (type === 3) {
                window.location.href='/dwapp/download/dwapp_downfile?reportType=DOUBTGROUPDAY&fileType=xlsx'+downfileParams; 
            } else if (type === 4) {
                window.location.href='/dwapp/download/dwapp_downfile?reportType=DOUBTGROUPTRADE&fileType=xlsx'+downfileParams; 
            } else if (type === 5) {
                // window.location.href='/dwapp/download/dwapp_downfile?reportType='+downfileParams; 
            } else if (type === 6) {
                // window.location.href='/dwapp/download/dwapp_downfile?reportType='+downfileParams; 
            } else if (type === 7) {
                // window.location.href='/dwapp/download/dwapp_downfile?reportType='+downfileParams; 
            } else if (type === 8) {
                // window.location.href='/dwapp/download/dwapp_downfile?reportType='+downfileParams; 
            }
        },

        exportTable: function () {

            var tabsValue = this.tabsValue
            console.log(tabsValue)

            if (this.tabsValue == 'onlyDate') {
                console.log(1)
                this.$refs.tableOneExport.exportCsv({
                    filename: '账户组每日交易持股分析',
                })
                this.$refs.tableTwoExport.exportCsv({
                    filename: '组内账户阶段交易持股分析'
                })
                this.$refs.tableThreeExport.exportCsv({
                    filename: '组内账户每日交易持股分析'
                })
                this.$refs.tableFourExport.exportCsv({
                    filename: '组内账户每日对倒明细'
                })
            }
            if (this.tabsValue == 'allDate') {
                console.log(2)
                this.$refs.tableFiveExport.exportCsv({
                    filename: '账户组每日交易持股分析',
                })
                this.$refs.tableSixExport.exportCsv({
                    filename: '组内账户阶段交易持股分析'
                })
                this.$refs.tableSevenExport.exportCsv({
                    filename: '组内账户每日交易持股分析'
                })
                this.$refs.tableEightExport.exportCsv({
                    filename: '组内账户每日对倒明细'
                })
            }


        },

    }
}
</script>