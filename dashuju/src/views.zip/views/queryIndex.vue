<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">庄股协查指标查询</h2>
        <div class="mainBox changeBox tabHide">
            <Row :gutter="16">
                <Col span="19">
                    <Card style="min-height:780px">
                        <Spin id="loadBox" fix class="loadBox" v-bind:class="{ hide: isHide }">
                            <Icon type="load-c" size=40 class="loadIcon"></Icon>
                            <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                        </Spin>
                        <span id="lookInfoLink" class="lookInfo" @click="changeInfo = true">查看统计口径</span>
                        <Modal id="lookInfoPop" title="庄股协查指标查询  统计口径说明" v-model="changeInfo" class-name="vertical-center-modal" cancel-text>
                            <h3>数据说明</h3>
                            <p>数据时间范围：自2001年初至今 （应用上线初期只有2009年11月23日及以后的数据，之前的数据将按由近及远的顺序依次弥补加载）<br>
                            证券选择范围：A股、B股、封闭式基金、ETF基金、债券现券、债券回购<br>
                            交易平台范围：统计结果包含普通竞价系统和大宗交易系统<br>
                            </p>
                            <h3>指标说明</h3>
                            <p>买入均价＝买入金额÷买入数量<br>
                            卖出均价＝卖出金额÷卖出数量<br>
                            对于新质押式回购品种而言，本应用中的均价无业务含义。<br>
                            </p>
                            <h3>其他说明</h3>
                            <p>在统计时，“会员营业部名称”字段的值基于成交明细数据中的Stat_Seat_Code来确定。如果某一个股东账户在同一交易日内的成交明细数据中出现了不同的Stat_Seat_Code
                                （这种情况比较少见，但存在），那么以该股东账户当天第一笔交易类申报记录对应的Stat_Seat_Code来作为其当天所有交易的Stat_Seat_Code。即对某一个股东账户而言，
                                在同一交易日内所有交易数据的“会员营业部名称”都相同。
                            </p>
                        </Modal>
                        <!--切换表格-->
                        <Tabs type="card" :animated="false">
                            <Tab-pane label="每日交易、对倒、持仓汇总统计表">
                                <p id="qiList1" class="redtext listlength">查询结果共&nbsp;{{dealitems1}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="qiTable1" :context="self" :data="TableData3" :columns="qiTableColumns1" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                            <Tab-pane label="持仓总体统计表">
                                <p id="qiList2" class="redtext listlength">查询结果共&nbsp;{{dealitems2}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="qiTable2" :context="self" :data="TableData4" :columns="qiTableColumns2" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                            <Tab-pane label="交易总体统计表">
                                <p id="qiList3" class="redtext listlength">查询结果共&nbsp;{{dealitems3}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="qiTable3" :context="self" :data="TableData6" :columns="qiTableColumns3" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                            <Tab-pane label="对倒总体统计表">
                                <p id="qiList4" class="redtext listlength">查询结果共&nbsp;{{dealitems4}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="qiTable4" :context="self" :data="TableData2" :columns="qiTableColumns4" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                            <Tab-pane label="账户组连续二十个交易日交易占比超过30%统计表">
                                <p id="qiList5" class="redtext listlength">查询结果共&nbsp;{{dealitems5}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="qiTable5" :context="self" :data="TableData5" :columns="qiTableColumns5" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                            <Tab-pane label="账户组连续二十个交易日对倒占比超过20%统计表">
                                <p id="qiList6" class="redtext listlength">查询结果共&nbsp;{{dealitems6}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="qiTable6" :context="self" :data="TableData1" :columns="qiTableColumns6" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                        </Tabs>
                        <div style="text-align:right;margin-top:46px;margin-bottom:10px;">
                            <Button id="exportCurrent" type="primary" size="large" @click="exportData(1)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件</Button>
                        </div>
                        
                    </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                    <Card style="min-height:780px">
                        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                            <b>开始日期</b>
                            <Form-item prop="startdate" id="startDateForm">
                                <Date-picker id="startDate" type="date" :options="startOption" placeholder="选择开始日期" v-model="formValidate.startdate"></Date-picker>
                            </Form-item>
                            <b>结束日期</b>
                            <Form-item prop="enddate" id="endDateForm">
                                <Date-picker id="endDate" type="date" :options="endOption" placeholder="选择结束日期" v-model="formValidate.enddate"></Date-picker>
                            </Form-item>
                            <b>证券代码</b>
                            <Form-item prop="zqCode">
                                <Select v-model="formValidate.zqCode" filterable placeholder="请输入/选择证券代码" @on-change="selectCode">
                                    <Option v-for="item in zqCodeList" :value="item.value" :key="item">{{ item.label }}</Option>
                                </Select>
                            </Form-item>
                            <b>股东账号</b><label class="redtext fontsize12">（不超过2500个）</label>
                            <Row class="uploadBox">
                                <Upload action="/base-service/api/decode_upfile?uploadType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount">
                                    <Button id="importAccountBtn" type="ghost">导入</Button>
                                </Upload>
                                <Button id="clearAccountBtn" v-on:click="clearOne()">清空</Button>
                            </Row>
                            <Row>
                                <p>已上传个数：<font id="infoUploadAccount" class="bluetext">{{accountList}}</font></p>
                                <Form-item prop="desc" id="AccountForm">
                                    <Input  id="AccountInput" v-model="formValidate.desc" @on-change="accountListChange" type="textarea" :rows="10" placeholder="请输入股东账号"></Input>
                                </Form-item>
                            </Row>
                            <Form-item class="showrow" prop="showrow">
                                在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p><label class="redtext fontsize12">(最多显示200行)</label></p>
                            </Form-item>
                            <Form-item>
                                <div class="cxBox"><Button id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查询</Button></div>
                            </Form-item>     
                            
                        </Form>

                    </Card>
                </Col>
            </Row>

        </div>
    </section>
</template>
<script>
import 'whatwg-fetch';  

//日期初始值
let lastTradeDate="";

    export default {
        //页面加载时执行
        mounted:function(){
            //获取URL地址参数
            var urlParams=window.location.href;
            var upfileParamsValue={};
            upfileParamsValue.signature=this.getUrlParams(urlParams).signature;
            this.upfileParams = upfileParamsValue;

            //证券代码联想
            this._fetch(fetch('/dwapp/mktdt/all_seccode', {
                method: "POST",
                // body: JSON.stringify(upfileParamsValue),
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json",
                    "signature":this.getUrlParams(urlParams).signature
                }
            }), 1800000).then(function (response) {
                return response.json()
            }, function (error) {
                this.$Message.error('系统繁忙，刷新页面!');
            }).then(data => {
                let codeData = data.resData,
                    zqCodeList = [];
                for(var i=0;i<codeData.length;i++){
                    let zqRow = {};
                    zqRow.value = codeData[i].secCode;
                    zqRow.label = codeData[i].value;
                    zqCodeList.push(zqRow);
                }
                console.log(zqCodeList);
                this.zqCodeList = zqCodeList;

            })
        },
        data () {
            return {
                //表单
                zqCodeList: [],
                //开始日期
                startOption: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                //结束日期 
                endOption: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                formValidate: {
                    showrow:20,
                    startdate:new Date(this.initialDate()),
                    enddate: new Date(this.initialDate()),
                    desc: '',    
                    zqCode:'',               
                },
                ruleValidate: {
                    showrow: [
                        { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                    ],
                    startdate: [
                        { required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }
                    ],
                    enddate: [
                        { required: true, type: 'date', message: '请选择结束日期', trigger: 'change' }
                    ],
                    desc: [
                        { required: true, message: '请输入股东账号', trigger: 'blur' },
                    ],
                    zqCode: [
                        { required: true, message: '请输入/选择证券代码', trigger: 'change' }
                    ],
                },
                changeInfo:false,
                //查询参数初始化
                testParams:{},
                orderParams:{},
                urlParams:window.location.href,
                isHide:true,
                //文件解析参数
                upfileParams:this.upfileParamsValue,
                //上传股东账户条数
				accountList: 0,
                self: this,
                //表格数据
                dealitems1:0,
                dealitems2:0,
                dealitems3:0,
                dealitems4:0,
                dealitems5:0,
                dealitems6:0,
                TableData1: [],
                TableData2: [],
                TableData3: [],
                TableData4: [],
                TableData5: [],
                TableData6: [],
                qiTableColumns1: [
                    {
                        title: '交易日期',
                        key: 'tradeDate',
                        "width": 150,
                    },
                    {
                        title: '证券代码',
                        key: 'secCode',
                        "width": 150,
                    },
                    {
                        title: '买入数量（股）',
                        key: 'buyVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买入金额（万元）',
                        key: 'buyAmt',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '卖出数量（股）',
                        key: 'sellVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '卖出金额（万元）',
                        key: 'sellAmount',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '账户组交易量（股）',
                        key: 'tradeVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '账户组交易量占该股总交易量比重%',
                        key: 'tradeRatio',
                        "width": 250,
                        sortable: true,
                    },
                    {
                        title: '账户组对倒量（股）',
                        key: 'internalTradeVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '账户组对倒量占该股总交易量比重%',
                        key: 'internalTradeRatio',
                        "width": 250,
                        sortable: true,
                    },
                    {
                        title: '账户组持A股流通股总数（股）',
                        key: 'holdVol',
                        "width": 250,
                        sortable: true,
                    },
                    {
                        title: '账户组持A股流通股总数占该股A股流通股本比重%',
                        key: 'holdRatio',
                        "width": 250,
                        sortable: true,
                    },
                    {
                        title: '股本比重%',
                        key: 'totalHoldRatio',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '账户组持A股流通股总数占该股总股本比重%',
                        key: 'tradePrice',
                        "width": 250,
                        sortable: true,
                    },
                ],		
                qiTableColumns2: [
                    {
                        title: '账户组持仓量占流通盘比例（X%）',
                        key: 'ratioTypeDesc',
                        "width": 300,
                    },
                    {
                        title: '账户组持仓量占流通盘比例超过X%的天数',
                        key: 'sumDateCnt',
                        "width": 300,
                    },
                    {
                        title: '账户组持仓量占流通盘比例超过X%的天数／总交易天数',
                        key: 'dateRatio',
                        "width": 350,
                    },
                ],		
                qiTableColumns3: [
                    {
                        title: '账户组交易量占总交易量比例（X%）',
                        key: 'ratioTypeDesc',
                        "width": 300,
                    },
                    {
                        title: '账户组交易量占总交易量比例超过X%的天数',
                        key: 'sumDateCnt',
                        "width": 300,
                    },
                    {
                        title: '账户组交易量占总交易量比例超过X%的天数／总交易天数',
                        key: 'dateRatio',
                        "width": 350,
                    },
                ],		
                qiTableColumns4: [
                    {
                        title: '账户组对倒量占总交易量比例（X%）',
                        key: 'ratioTypeDesc',
                        "width": 300,
                    },
                    {
                        title: '账户组对倒量占总交易量比例超过X%的天数',
                        key: 'sumDateCnt',
                        "width": 300,
                    },
                    {
                        title: '账户组对倒量占总交易量比例超过X%的天数／总交易天数',
                        key: 'dateRatio',
                        "width": 350,
                    },
                ],
                qiTableColumns5: [
                    {
                        title: '开始日期',
                        key: 'tradeDate',
                        "width": 100,
                    },
                    {
                        title: '结束日期',
                        key: 'maxTradeDate',
                        "width": 100,
                    },
                    {
                        title: '期间账户组交易量',
                        key: 'sumTradeVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期间该股总交易量',
                        key: 'sumTotalTradeVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期间账户组交易量占该股总交易量比重%',
                        key: 'sumTradeRatio',
                        "width": 350,
                        sortable: true,
                    },
                     {
                        title: '证券代码',
                        key: 'secCode',
                        "width": 350,
                        sortable: true,
                    },
                ],
                qiTableColumns6: [
                    {
                        title: '开始日期',
                        key: 'tradeDate',
                        "width": 100,
                    },
                    {
                        title: '结束日期',
                        key: 'maxTradeDate',
                        "width": 100,
                    },
                    {
                        title: '期间账户组对倒量',
                        key: 'sumTradeVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期间该股总交对倒量',
                        key: 'sumTotalTradeVol',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '期间账户组对倒量占该股总交易量比重%',
                        key: 'sumTradeRatio',
                        "width": 350,
                        sortable: true,
                    },
                    {
                        title: '证券代码',
                        key: 'secCode',
                        "width": 350,
                        sortable: true,
                    },
                ],
            }
        },
        methods: {
            //证券代码模糊查询截取字段
            selectCode:function(value){
                console.log(value,"------------------------zqcode",this.zqCodeList[0].value);
                var selectValue = value;
                for(var i=0;i<this.zqCodeList;i++){
                    if(selectValue == this.zqCodeList[i].value){
                        this.zqCodeList[i].label.split(".",1);
                        console.log(selectValue,"------------------------zqcode1111111111");
                    }
                }
            },
            //请求初始日期
            initialDate:function(){
                var obj=new XMLHttpRequest();
                obj.open('GET','/base-service/api/predate',false);
                obj.setRequestHeader("signature","20170515XXDW");
                obj.onreadystatechange=function(){
                    if(obj.readyState == 4 && obj.status == 200){
                        const responseData=JSON.parse(obj.responseText);
                        //上一个交易日
                        lastTradeDate = responseData.resData.lastTradeDate;
                        lastTradeDate = lastTradeDate.slice(0,4)+"-"+lastTradeDate.slice(4,6)+"-"+lastTradeDate.slice(6,8);
                    }
                };
                obj.send(null);
                return lastTradeDate;
            },
            //获取参数
            getUrlParams:function(url){
                var urlArray=url.split("?")[1].split("&"),
                    urlValue={};
                for(var i=0;i<urlArray.length;i++){
                    var urlRowArray=urlArray[i].split("=");
                    urlValue[urlRowArray[0]]=urlRowArray[1];
                }
                return urlValue;
            },
            //设置fetch请求超时方法
             _fetch:function(fetch_promise, timeout) {
                var abort_fn = null;
                var abortInfo=this;
                //这是一个可以被reject的promise
                var abort_promise = new Promise(function(resolve, reject) {
                        abort_fn = function() {
                            console.log('查询超时abort promise');
                            // abortInfo.$Message.warning('查询超时！请重试！');
                        };
                });
                //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
                var abortable_promise = Promise.race([
                        fetch_promise,
                        abort_promise
                ]);
                setTimeout(function() {
                        abort_fn();
                    }, timeout);
                return abortable_promise;
            }, 
            //股东账户已上传条数
			accountListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				let arrNew = [];
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.accountList = arr.length;
			},
            //股东账号导入
		      handleSuccessAccount(response, file, fileList){
                const arry = response.resData;
                console.log(arry)
                let str = '';
                let  arryAll= [];
                for(var i = 0; i < arry.length; i++){
                    arryAll.push(arry[i]);
                }
                console.log(arryAll)
                this.dataLookInfo = arryAll
                this.accountList = arryAll.length;
                str = arryAll.join('\n');
                this.formValidate.desc = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
            },
            //原声js写jquery方法
            hasClass:function(obj, cls){  
                return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
            },
            addClass:function(obj, cls){  
                if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
            },
            removeClass:function(obj, cls){  
                if (this.hasClass(obj, cls)) {  
                    var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                    obj.className = obj.className.replace(reg, ' ');  
                }  
            },
            toggleClass:function(obj,cls){  
                if(this.hasClass(obj,cls)){  
                    this.removeClass(obj, cls);  
                }else{  
                    this.addClass(obj, cls);  
                }  
            },
            //传排序参数
            infoTableSort:function(sort){
                orderParams.field=sort.key;
                orderParams.sort=sort.order;
            },
            //查询表单数据
            searchData:function(requestParam){
                this.orderParams={};
                this.isHide=false;
                const url = '/dwapp/mktdt/zg_every_sum';

                this._fetch(fetch(url, {
                    method: "POST",
                    body: JSON.stringify(requestParam),
                    mode: 'cors',
                    headers: {
                        "Content-Type": "application/json",
                        "signature":this.getUrlParams(this.urlParams).signature
                    }
                }), 1800000).then(function (response) {
                    return response.json()
                }, function (error) {
                    this.$Message.error('系统繁忙，刷新页面!');
                }).then(data => {
                    var exportButton1 = document.getElementById("exportCurrent");
                    var _this = this;
                    //取数据
                    var dataResponse=data.resData;
                    var dataError=data.message;
                    var datalength1 = data.resData.zgBackPropList.size;
                    var datalength2 = data.resData.zgBackSumList.size;
                    var datalength3 = data.resData.zgEverySumList.size;
                    var datalength4 = data.resData.zgPositionSumList.size;
                    var datalength5 = data.resData.zgTradePropList.size;
                    var datalength6 = data.resData.zgTradeSumList.size;

                    if(dataResponse == null){
                        this.isHide=true;
                        this.$Message.warning("查询出错"+dataError);
                        this.TableData1 = [];
                        this.TableData2 = [];
                        this.TableData3 = [];
                        this.TableData4 = [];
                        this.TableData5 = [];
                        this.TableData6 = [];
                        this.dealitems1 = datalength1;
                        this.dealitems2 = datalength2;
                        this.dealitems3 = datalength3;
                        this.dealitems4 = datalength4;
                        this.dealitems5 = datalength5;
                        this.dealitems6 = datalength6;

                        exportButton1.setAttribute("disabled",true);

                    }else{
                        if(dataResponse.length == 0){
                            this.isHide=true;
                            this.$Message.warning('查询无数据！');
                            this.TableData1 = [];
                            this.TableData2 = [];
                            this.TableData3 = [];
                            this.TableData4 = [];
                            this.TableData5 = [];
                            this.TableData6 = [];
                            this.dealitems1 = datalength1;
                            this.dealitems2 = datalength2;
                            this.dealitems3 = datalength3;
                            this.dealitems4 = datalength4;
                            this.dealitems5 = datalength5;
                            this.dealitems6 = datalength6;

                            exportButton1.setAttribute("disabled",true);
                        }else{
                            var dataArray1=[];
                            var dataArray2=[];
                            var dataArray3=[];
                            var dataArray4=[];
                            var dataArray5=[];
                            var dataArray6=[];
                            this.dealitems1 = datalength1;
                            this.dealitems2 = datalength2;
                            this.dealitems3 = datalength3;
                            this.dealitems4 = datalength4;
                            this.dealitems5 = datalength5;
                            this.dealitems6 = datalength6;

                            for(var i=0;i<dataResponse.zgBackPropList.data.length;i++){
                                var dataRow1={};
                                for(var key in dataResponse.zgBackPropList.data[i]){
                                    dataRow1[key] = dataResponse.zgBackPropList.data[i][key];
                                }
                                dataArray1.push(dataRow1);
                            }
                            for(var i=0;i<dataResponse.zgBackSumList.data.length;i++){
                                var dataRow2={};
                                for(var key in dataResponse.zgBackSumList.data[i]){
                                    dataRow2[key] = dataResponse.zgBackSumList.data[i][key];
                                }
                                dataArray2.push(dataRow2);
                            }
                            for(var i=0;i<dataResponse.zgEverySumList.data.length;i++){
                                var dataRow3={};
                                for(var key in dataResponse.zgEverySumList.data[i]){
                                    dataRow3[key] = dataResponse.zgEverySumList.data[i][key];
                                }
                                dataArray3.push(dataRow3);
                            }
                            for(var i=0;i<dataResponse.zgPositionSumList.data.length;i++){
                                var dataRow4={};
                                for(var key in dataResponse.zgPositionSumList.data[i]){
                                    dataRow4[key] = dataResponse.zgPositionSumList.data[i][key];
                                }
                                dataArray4.push(dataRow4);
                            }
                            for(var i=0;i<dataResponse.zgTradePropList.data.length;i++){
                                var dataRow5={};
                                for(var key in dataResponse.zgTradePropList.data[i]){
                                    dataRow5[key] = dataResponse.zgTradePropList.data[i][key];
                                }
                                dataArray5.push(dataRow5);
                            }
                            for(var i=0;i<dataResponse.zgTradeSumList.data.length;i++){
                                var dataRow6={};
                                for(var key in dataResponse.zgTradeSumList.data[i]){
                                    dataRow6[key] = dataResponse.zgTradeSumList.data[i][key];
                                }
                                dataArray6.push(dataRow6);
                            }
                            console.log(dataArray1)
                            console.log(dataArray2)
                            console.log(dataArray3)
                            console.log(dataArray4)
                            console.log(dataArray5)
                            console.log(dataArray6)
                            _this.TableData1 = dataArray1;
                            _this.TableData2 = dataArray2;
                            _this.TableData3 = dataArray3;
                            _this.TableData4 = dataArray4;
                            _this.TableData5 = dataArray5;
                            _this.TableData6 = dataArray6;
                            exportButton1.removeAttribute("disabled");

                            this.isHide=true;

                        }
                    }
                })
            },
            handleSubmit (name) {
                this.$refs[name].validate((valid) => {
                    const { desc } = this.formValidate;
                    var descValue = desc;
                    //股东账号  10 一个大写字母  9个数字
					if(this.formValidate.desc){
						const descStr = descValue.replace(/[\r\n]/g,',');
						let descArry = descStr.split(',');
                        //判断上传股东账户不能超过2500
                        if(descArry.length>2500){
                            this.$Message.error('股东账号不能超过2500个!');
                            return;
                        }
						for(var i=0; i < descArry.length; i++){
							const descVal = descArry[i].trim();
							const descReg = /^[A-Z]{1}\d{9}/g; 
							if(!descReg.test(descVal) || descVal.length != 10){
								this.$Message.error('股东账号由一个大写字母和9个数字组成！');//AccountForm
								this.addClass(document.getElementById('AccountForm'),'ivu-form-item-error');
								return;
							}
						}
						this.removeClass(document.getElementById('AccountForm'),'ivu-form-item-error');
						// descValue = descArry.join(',');
                        descValue = descArry;
					}

                    if (valid) {
                        this.$Message.success('提交成功!请等待~'); 
                        //获取请求参数
                        /*this.testParams={
                            "accountId":descValue,"limit":this.formValidate.showrow.toString(),
                            "userId":this.getUrlParams(this.urlParams).userId, "userName":this.getUrlParams(this.urlParams).userName
                            }*/
                        this.testParams= {
                        "startDate":"20170620",
                        "endDate":"20170620",
                        "userId":"112", 
                        "limit":"1",
                        "userName":"aaa", 
                        "accountId":["A011567381"],
                        "accountId2":["A017172017"],
                        "secCode":["123123"]
                        },
                        console.log(this.testParams,"-----testParams111111111");
                        this.searchData(this.testParams);
                        
                    } else {
                        this.$Message.error('表单验证失败!');
                    }
                })
            },
            clearOne:function(){
                this.formValidate.desc="";
                this.accountList=0;
            },
            exportData (type) {
                //导出参数
                var downfileParams="&signature="+this.getUrlParams(this.urlParams).signature+
                "&userId="+this.getUrlParams(this.urlParams).userId+"&userName="+this.getUrlParams(this.urlParams).userName+
                "&startDate=20170620&endDate=20170620&limit=1&accountId=A011567381&secCode=123123";
                if (type === 1) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ZGEVERYSUM&fileType=xlsx'+downfileParams;                    
                } 
            },
        }
    }
</script>