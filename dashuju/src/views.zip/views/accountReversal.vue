<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">两组账户对倒明细查询</h2>
        <div class="mainBox changeBox">
            <Row :gutter="16">
                <Col span="19">
                    <Card style="min-height:780px">
                        <Spin id="loadBox" fix class="loadBox" v-bind:class="{ hide: isHide }">
                            <Icon type="load-c" size=40 class="loadIcon"></Icon>
                            <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                        </Spin>
                        <span id="lookInfoLink" class="lookInfo" @click="changeInfo = true">查看统计口径</span>
                        <Modal id="lookInfoPop" title="两组账户对倒明细查询  统计口径说明" v-model="changeInfo" class-name="vertical-center-modal" cancel-text>
                            <h3>数据说明</h3>
                            <p>数据时间范围：自2001年初至今 （应用上线初期只有2009年11月23日及以后的数据，之前的数据将按由近及远的顺序依次弥补加载）<br>
                            证券选择范围：A股、B股、封闭式基金、ETF基金、债券现券、债券回购<br>
                            交易平台范围：统计结果包含普通竞价系统和大宗交易系统<br>
                            </p>
                            <h3>指标说明</h3>
                            <p>买入均价＝买入金额÷买入数量<br>
                            卖出均价＝卖出金额÷卖出数量<br>
                            对于新质押式回购品种而言，本应用中的均价无业务含义。<br>
                            </p>
                            <h3>其他说明</h3>
                            <p>在统计时，“会员营业部名称”字段的值基于成交明细数据中的Stat_Seat_Code来确定。如果某一个股东账户在同一交易日内的成交明细数据中出现了不同的Stat_Seat_Code
                                （这种情况比较少见，但存在），那么以该股东账户当天第一笔交易类申报记录对应的Stat_Seat_Code来作为其当天所有交易的Stat_Seat_Code。即对某一个股东账户而言，
                                在同一交易日内所有交易数据的“会员营业部名称”都相同。
                            </p>
                        </Modal>
                        <!--切换表格-->
                        <Tabs type="card" :animated="false">
                            <Tab-pane label="仅统计竞价交易数据">
                                <p id="qiList1" class="redtext listlength">查询结果共&nbsp;{{dealitems1}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="Table1" :context="self" :data="TableData1" :columns="TableColumns1" size="small" ref="table" border stripe></Table>
                                <div style="text-align:right;margin-top:46px;margin-bottom:10px;">
                                    <Button id="exportCurrent" type="primary" size="large" @click="exportData(1)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件</Button>
                                </div>
                            </Tab-pane>
                            <Tab-pane label="统计时包含大宗交易数据">
                                <p id="qiList2" class="redtext listlength">查询结果共&nbsp;{{dealitems2}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="Table2" :context="self" :data="TableData2" :columns="TableColumns2" size="small" ref="table" border stripe></Table>
                                <div style="text-align:right;margin-top:46px;margin-bottom:10px;">
                                    <Button id="exportCurrent2" type="primary" size="large" @click="exportData(2)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件</Button>
                                </div>
                            </Tab-pane>
                        </Tabs>
                        
                    </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                    <Card style="min-height:780px">
                        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                            <b>开始日期</b>
                            <Form-item prop="startdate" id="startDateForm">
                                <Date-picker id="startDate" type="date" :options="startOption" placeholder="选择开始日期" v-model="formValidate.startdate"></Date-picker>
                            </Form-item>
                            <b>结束日期</b>
                            <Form-item prop="enddate" id="endDateForm">
                                <Date-picker id="endDate" type="date" :options="endOption" placeholder="选择结束日期" v-model="formValidate.enddate"></Date-picker>
                            </Form-item>
                            <b>证券代码</b>
                            <Form-item prop="zqCode">
                                <Select v-model="formValidate.zqCode" filterable placeholder="请输入/选择证券代码">
                                    <Option v-for="item in zqCodeList" :value="item.value" :key="item">{{ item.label }}</Option>
                                </Select>
                            </Form-item>
                            <b>账户组A</b><label class="redtext fontsize12">（不超过1200个）</label>
                            <Row class="uploadBox">
                                <Upload action="/base-service/api/decode_upfile?uploadType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount">
                                    <Button id="importAccountBtn" type="ghost">导入</Button>
                                </Upload>
                                <Button id="clearAccountBtn" v-on:click="clearOne()">清空</Button>
                            </Row>
                            <Row>
                                <p>已上传个数：<font id="infoUploadAccount" class="bluetext">{{accountList}}</font></p>
                                <Form-item prop="desc" id="AccountForm">
                                    <Input  id="AccountInput" v-model="formValidate.desc" @on-change="accountListChange" type="textarea" :rows="3" placeholder="请输入股东账号"></Input>
                                </Form-item>
                            </Row>
                            <b>账户组B</b><label class="redtext fontsize12">（不超过1200个）</label>
                            <Row class="uploadBox">
                                <Upload action="/base-service/api/decode_upfile?uploadType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount2">
                                    <Button id="importAccountBtn2" type="ghost">导入</Button>
                                </Upload>
                                <Button id="clearAccountBtn2" v-on:click="clearTwo()">清空</Button>
                            </Row>
                            <Row>
                                <p>已上传个数：<font id="infoUploadAccount2" class="bluetext">{{accountList2}}</font></p>
                                <Form-item prop="desc" id="AccountForm2">
                                    <Input  id="AccountInput2" v-model="formValidate.desc2" @on-change="accountListChange2" type="textarea" :rows="3" placeholder="请输入股东账号"></Input>
                                </Form-item>
                            </Row>
                            <Form-item class="showrow" prop="showrow">
                                在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p><label class="redtext fontsize12">(最多显示200行)</label></p>
                            </Form-item>
                            <Form-item>
                                <div class="cxBox"><Button id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查询</Button></div>
                            </Form-item>     
                            
                        </Form>

                    </Card>
                </Col>
            </Row>

        </div>
    </section>
</template>
<script>
import 'whatwg-fetch';  

//日期初始值
let lastTradeDate="";

    export default {
        //页面加载时执行
        mounted:function(){
            //获取URL地址参数
            var urlParams=window.location.href;
            var upfileParamsValue={};
            upfileParamsValue.signature=this.getUrlParams(urlParams).signature;
            this.upfileParams = upfileParamsValue;

            //证券代码联想
            this._fetch(fetch('/dwapp/mktdt/all_seccode', {
                method: "POST",
                // body: JSON.stringify(upfileParamsValue),
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json",
                    "signature":this.getUrlParams(urlParams).signature
                }
            }), 1800000).then(function (response) {
                return response.json()
            }, function (error) {
                this.$Message.error('系统繁忙，刷新页面!');
            }).then(data => {
                let codeData = data.resData,
                    zqCodeList = [];
                for(var i=0;i<codeData.length;i++){
                    let zqRow = {};
                    zqRow.value = codeData[i].secCode;
                    zqRow.label = codeData[i].value;
                    zqCodeList.push(zqRow);
                }
                console.log(zqCodeList);
                this.zqCodeList = zqCodeList;
                 //tmp hard code
                 this.zqCodeList=[{
                        value: '601718',
                        label: '601718'
                    }];
            })


        },
        data () {
            return {
                //表单
                zqCodeList: [],
                //开始日期
                startOption: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                //结束日期 
                endOption: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                formValidate: {
                    showrow:20,
                    startdate: new Date(this.initialDate()),
                    enddate: new Date(this.initialDate()),
                    desc: '',   
                    desc2: '',  
                    zqCode:'',               
                },
                ruleValidate: {
                    showrow: [
                        { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                    ],
                    startdate: [
                        { required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }
                    ],
                    enddate: [
                        { required: true, type: 'date', message: '请选择结束日期', trigger: 'change' }
                    ],
                    desc: [
                        { required: true, message: '请输入账户组A', trigger: 'blur' },
                    ],
                    desc2: [
                        { required: true, message: '请输入账户组B', trigger: 'blur' },
                    ],
                    zqCode: [
                        { required: true, message: '请输入/选择证券代码', trigger: 'change' }
                    ],
                },
                changeInfo:false,
                //查询参数初始化
                testParams:{},
                orderParams:{},
                urlParams:window.location.href,
                isHide:true,
                //文件解析参数
                upfileParams:this.upfileParamsValue,
                //上传股东账户条数
				accountList: 0,
                accountList2: 0,
                self: this,
                //表格数据
                dealitems1:0,
                dealitems2:0,
                TableData1: [],
                TableData2: [],							
                TableColumns1: [
                    {
                        title: '成交时间',
                        key: 'tradeTime',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交编号',
                        key: 'tradeNo',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方所在账户组',
                        key: 'acctGroupBuy',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方股东账户',
                        key: 'acctIdBuy',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方账户名称',
                        key: 'acctNameBuy',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方所在账户组',
                        key: 'acctGroupSell',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方股东账号',
                        key: 'acctIdSell',
                        "width": 150,
                        sortable: true,
                    },				
                    {
                        title: '卖方账户名称',
                        key: 'acctNameSell',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交数量',
                        key: 'tradeAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交金额',
                        key: 'tradeVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方证件号',
                        key: 'idCardSell',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方证件号',
                        key: 'idCardBuy',
                        "width": 150,
                        sortable: true,
                    },
                ],		
                TableColumns2: [
                      {
                        title: '成交时间',
                        key: 'tradeTime',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交编号',
                        key: 'tradeNo',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方所在账户组',
                        key: 'acctGroupBuy',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方股东账户',
                        key: 'acctIdBuy',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方账户名称',
                        key: 'acctNameBuy',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方所在账户组',
                        key: 'acctGroupSell',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方股东账号',
                        key: 'acctIdSell',
                        "width": 150,
                        sortable: true,
                    },              
                    {
                        title: '卖方账户名称',
                        key: 'acctNameSell',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交数量',
                        key: 'tradeAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交金额',
                        key: 'tradeVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方证件号',
                        key: 'idCardSell',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方证件号',
                        key: 'idCardBuy',
                        "width": 150,
                        sortable: true,
                    },
                ],	
            }
        },
        methods: {
            //请求初始日期
            initialDate:function(){
                var obj=new XMLHttpRequest();
                obj.open('GET','/base-service/api/predate',false);
                obj.setRequestHeader("signature","20170515XXDW");
                obj.onreadystatechange=function(){
                    if(obj.readyState == 4 && obj.status == 200){
                        const responseData=JSON.parse(obj.responseText);
                        //上一个交易日
                        lastTradeDate = responseData.resData.lastTradeDate;
                        lastTradeDate = lastTradeDate.slice(0,4)+"-"+lastTradeDate.slice(4,6)+"-"+lastTradeDate.slice(6,8);
                    }
                };
                obj.send(null);
                return lastTradeDate;
            },
            //获取参数
            getUrlParams:function(url){
                var urlArray=url.split("?")[1].split("&"),
                    urlValue={};
                for(var i=0;i<urlArray.length;i++){
                    var urlRowArray=urlArray[i].split("=");
                    urlValue[urlRowArray[0]]=urlRowArray[1];
                }
                return urlValue;
            },
            //设置fetch请求超时方法
             _fetch:function(fetch_promise, timeout) {
                var abort_fn = null;
                var abortInfo=this;
                //这是一个可以被reject的promise
                var abort_promise = new Promise(function(resolve, reject) {
                        abort_fn = function() {
                            console.log('查询超时abort promise');
                            // abortInfo.$Message.warning('查询超时！请重试！');
                        };
                });
                //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
                var abortable_promise = Promise.race([
                        fetch_promise,
                        abort_promise
                ]);
                setTimeout(function() {
                        abort_fn();
                    }, timeout);
                return abortable_promise;
            }, 
            //股东账户已上传条数
			accountListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				let arrNew = [];
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.accountList = arr.length;
			},
            accountListChange2:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				let arrNew = [];
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.accountList2 = arr.length;
			},
         //股东账号导入
              handleSuccessAccount(response, file, fileList){
                const arry = response.resData;
                console.log(arry)
                let str = '';
                let  arryAll= [];
                for(var i = 0; i < arry.length; i++){
                    arryAll.push(arry[i]);
                }
                console.log(arryAll)
                this.dataLookInfo = arryAll
                this.accountList = arryAll.length;
                str = arryAll.join('\n');
                this.formValidate.desc = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
            },
              handleSuccessAccount2(response, file, fileList){
                const arry1 = response.resData;
                console.log(arry1)
                let str2 = '';
                let  arryAll1= [];
                for(var i = 0; i < arry1.length; i++){
                    arryAll1.push(arry1[i]);
                }
                console.log(arryAll1)
                this.dataLookInfo2 = arryAll1
                this.accountList2 = arryAll1.length;
                str2 = arryAll1.join('\n');
                this.formValidate.desc2 = str2;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
            },
            //原声js写jquery方法
            hasClass:function(obj, cls){  
                return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
            },
            addClass:function(obj, cls){  
                if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
            },
            removeClass:function(obj, cls){  
                if (this.hasClass(obj, cls)) {  
                    var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                    obj.className = obj.className.replace(reg, ' ');  
                }  
            },
            toggleClass:function(obj,cls){  
                if(this.hasClass(obj,cls)){  
                    this.removeClass(obj, cls);  
                }else{  
                    this.addClass(obj, cls);  
                }  
            },
            //传排序参数
            infoTableSort:function(sort){
                orderParams.field=sort.key;
                orderParams.sort=sort.order;
            },
            //查询表单数据
            searchData:function(requestParam){
                this.orderParams={};
                this.isHide=false;
                const url = '/dwapp/mktdt/tw_back_detail';

                this._fetch(fetch(url, {
                    method: "POST",
                    body: JSON.stringify(requestParam),
                    mode: 'cors',
                    headers: {
                        "Content-Type": "application/json",
                        "signature":this.getUrlParams(this.urlParams).signature
                    }
                }), 1800000).then(function (response) {
                    return response.json()
                }, function (error) {
                    this.$Message.error('系统繁忙，刷新页面!');
                }).then(data => {
                    var exportButton1 = document.getElementById("exportCurrent");
                    var exportButton2 = document.getElementById("exportCurrent2");
                    var _this = this;

                    //取数据
                    var dataResponse=data.resData;
                    var dataError=data.message;
                    var datalength = data.respSize;

                    if(dataResponse == null){
                        this.isHide=true;
                        this.$Message.warning("查询出错"+dataError);
                        this.TableData1 = [];
                        this.TableData2 = [];
                        this.dealitems1 = 0;

                        exportButton1.setAttribute("disabled",true);
                        exportButton2.setAttribute("disabled",true);

                    }else{
                        if(dataResponse.length == 0){
                            this.isHide=true;
                            this.$Message.warning('查询无数据！');
                            this.TableData1 = [];
                            this.TableData2 = [];
                            this.dealitems1 = 0;

                            exportButton1.setAttribute("disabled",true);
                            exportButton2.setAttribute("disabled",true);
                        }else{
                            var dataArray1=[];
                            var dataArray2=[];
                            this.dealitems1 = dataResponse.list.data.length;
                            this.dealitems2 = dataResponse.listBt.data.length;
                            console.log(dataResponse)

                            for(var i=0;i<dataResponse.list.data.length;i++){
                                var dataRow1={};
                                for(var key in dataResponse.list.data[i]){
                                    dataRow1[key] = dataResponse.list.data[i][key];
                                }
                                dataArray1.push(dataRow1);
                            }
                             for(var i=0;i<dataResponse.listBt.data.length;i++){
                                var dataRow2={};
                                for(var key in dataResponse.listBt.data[i]){
                                    dataRow2[key] = dataResponse.listBt.data[i][key];
                                }
                                dataArray2.push(dataRow2);
                            }

                            
                            _this.TableData1 = dataArray1;
                            _this.TableData2 = dataArray2;

                            console.log(_this.TableData1);
                            console.log(_this.TableData2);
                            exportButton1.removeAttribute("disabled");
                            exportButton2.removeAttribute("disabled");

                            this.isHide=true;

                        }
                    }
                })
            },
            handleSubmit (name) {
                this.$refs[name].validate((valid) => {
                    const { desc } = this.formValidate;
                    var descValue = desc;
                    //股东账号  10 一个大写字母  9个数字
					if(this.formValidate.desc){
						const descStr = descValue.replace(/[\r\n]/g,',');
						let descArry = descStr.split(',');
                        //判断上传股东账户不能超过2500
                        if(descArry.length>1200){
                            this.$Message.error('账户组A不能超过1200个!');
                            return;
                        }
						for(var i=0; i < descArry.length; i++){
							const descVal = descArry[i].trim();
							const descReg = /^[A-Z]{1}\d{9}/g; 
							if(!descReg.test(descVal) || descVal.length != 10){
								this.$Message.error('股东账号由一个大写字母和9个数字组成！');//AccountForm
								this.addClass(document.getElementById('AccountForm'),'ivu-form-item-error');
								return;
							}
						}
						this.removeClass(document.getElementById('AccountForm'),'ivu-form-item-error');
						// descValue = descArry.join(',');
                        descValue = descArry;
					}

                    if (valid) {
                        this.$Message.success('提交成功!请等待~'); 
                        //获取请求参数
                        var startdateValue = this.formValidate.startdate;

            var startdate = startdateValue.format('yyyy-MM-dd');
            console.log(startdate);
            var enddateValue = this.formValidate.enddate;

            var endDate = enddateValue.format('yyyy-MM-dd');
            console.log(endDate);

            console.log(this.formValidate.desc);

            console.log(this.formValidate.zqCode);

            const descStr = this.formValidate.desc.replace(/[\r\n]/g,',');
            let descArry = descStr.split(',');
            let codelist=this.formValidate.zqCode.split(',');
                        
                        this.testParams={
                            "startDate":"20180620",
                            "endDate":"20180620",
                            "accountId":descValue,
                            "accountId2":["A017172017"],
                            "secCode":["123123"],
                            "limit":this.formValidate.showrow.toString(),
                            "userId":this.getUrlParams(this.urlParams).userId, 
                            "userName":this.getUrlParams(this.urlParams).userName
                            }
                        console.log(this.testParams,"-----testParams111111111");
                        this.searchData(this.testParams);
                        
                    } else {
                        this.$Message.error('表单验证失败!');
                    }
                })
            },
            clearOne:function(){
                this.formValidate.desc="";
                this.accountList=0;
            },
            clearTwo:function(){
                this.formValidate.desc2="";
                this.accountList2=0;
            },
            exportData (type) {
                //导出参数
                var downfileParams="&signature="+this.getUrlParams(this.urlParams).signature+
                "&userId="+this.getUrlParams(this.urlParams).userId+"&userName="+this.getUrlParams(this.urlParams).userName+
                "&startDate=20180620&endDate=20180620&accountId=A111111111,A222222222&accountId2=A017172017,A222222222&secCode=123123"+
                "&limit="+this.formValidate.showrow.toString();
                if (type === 1) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ACCTREV&fileType=xlsx'+downfileParams;                    
                } else if (type === 2) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ACCTREVBT&fileType=xlsx'+downfileParams; 
                }
            },
        }
    }
</script>