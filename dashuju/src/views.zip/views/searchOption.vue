<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">期权投资者参与权证交易情况</h2>
        <div class="mainBox">
            <Row :gutter="16">
                <Col span="19">
                    <Card style="min-height:780px">
                        <Spin id="loadBox" fix class="loadBox" v-bind:class="{ hide: isHide }">
                            <Icon type="load-c" size=40 class="loadIcon"></Icon>
                            <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                        </Spin>
                        <span id="lookInfoLink" class="lookInfo" @click="modal10 = true">查看统计口径</span>
                        <Modal class="modal overHeight" title="期权投资者参与权证交易情况 统计口径说明" v-model="modal10" class-name="vertical-center-modal" cancel-text  :scrollable="true" >
                            <h3 class="text">
                                <b>数据说明</b>
                            </h3>
                            <p class="textP">只统计期权投资者账户对权证的交易情况</p>
                            <h3 class="text">
                                <b>指标说明</b>
                            </h3>
                            <p class="textP">
                                1.证券账户，即投资者衍生品账户对应的现货账户。<br>
                                2.权证首笔交易日期，即期权投资者首笔权证的交易日期。<br>
                                3.权证最后交易日期，即期权投资者最后一笔权证的交易日期。<br>
                                4.权证日均交易金额，即（投资者所有权证交易金额合计值）/投资者权证总交易天数权证累计交易金额，即投资者对所有权证交易金额的合计。<br>
                                5.权证盈亏情况 =卖出收入金额-买入支付金额+（行权时现货价格-行权价）*行权张数-（行权时现货价格-行权价）*被行权张数。<br>
                            </p>
                            </p>
                            <h3 class="text">
                                <b>其他说明</b>
                            </h3>
                            <p class="textP">无</p>
                        </Modal>
                        <p id="infoTableList" class="redtext listlength">查询结果共&nbsp;{{this.data1.length}}&nbsp;条记录</p>
                        <Table height="600" :columns="columns1" :data="data1" style="display:scroll-x"></Table>
                        <div style="text-align:right;margin-top:46px;margin-bottom:10px;">
                            <Button id="calExportBtn" type="primary" size="large" @click="exportData(1)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件</Button>
                        </div>
                    </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                    <Card style="min-height:780px">
                        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate">
                            <b>期权投资者账户</b>
                            <Form-item prop='desc' id="AccountForm" style="margin-top:5px;">
                                <Input id="AccountInput" v-model="formValidate.desc" placeholder="请输入..."></Input>
                            </Form-item>
                            <Form-item class="showrow" prop="showrow">
                                在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p><label class="redtext fontsize12">(最多显示200行)</label></p>
                            </Form-item>
                            <Form-item>
                                <Button type="primary" @click="handleSubmit('formValidate')" style="float:right;width:80px;">查询</Button>
                            </Form-item>
                        </Form>
                    </Card>
                </Col>
            </Row>

        </div>
    </section>
</template>

<script>
export default {
    name: 'threeFour',
         //页面加载时执行
        mounted:function(){
            //获取URL地址参数
            var urlParams=window.location.href;
            var upfileParamsValue={};
            upfileParamsValue.signature=this.getUrlParams(urlParams).signature;
            this.upfileParams=upfileParamsValue;

        },
    data() {
        return {
            items: 0,
            modal10: false,
            isHide: true,
            formValidate: {
                desc: '',
                showrow:20,
            },
            urlParams:window.location.href,
            upfileParams:this.upfileParamsValue,
            ruleValidate: {
                desc: [
                    { message: '请输入账户...', trigger: 'blur' }
                ],
                showrow: [
                    { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                ],

            },
            model11: '',
            columns1: [
                {
                    title: '证券账户',
                    key: 'acctId',
                    width: 120,
                    sortable: true,
                },
                {
                    title: '权证首笔交易日期',
                    key: 'minMinTradeDate',
                    width: 200,
                    sortable: true,
                },
                {
                    title: '权证最后交易日期',
                    key: 'maxMaxTradeDate',
                    width: 200,
                    sortable: true,
                },
                {
                    title: '权证日均交易金额（元）',
                    key: 'avgTradeAmt',
                    width: 250,
                    sortable: true,

                },
                {
                    title: '权证累计交易金额（元）',
                    key: 'tradeAmt',
                    width: 250,
                    sortable: true,
                },
                {
                    title: '权证盈亏情况（元）',
                    key: 'tradeAmtPf',
                    width: 250,
                    sortable: true,
                }
            ],
            data1: [],

            columns2: [
                {
                    title: '成交标志',
                    key: 'logo',
                    width: 90
                },
                {
                    title: '成交标志描述',
                    key: 'describe',
                    width: 120
                },
                {
                    title: '算法',
                    key: 'ari',

                }
            ],
            data2: [
                {
                    logo: 'M',
                    describe: '全部成交',
                    ari: '当日该笔交易的申报数量和成交数量相等，则认为该笔交易为全部成交交易'
                },
                {
                    logo: 'W',
                    describe: '撤单',
                    ari: '当日该笔交易的申报数量和成交数量不相等，同时撤单时间不为空，则认为该笔交易为撤单交易'
                },
                {
                    logo: 'O',
                    describe: '其他有效申报',
                    ari: '当日该笔交易的申报数量和成交数量不相等，同时其撤单时间为空，则认为该笔交易为其他有效申报交易'
                },
            ]
        }
    },

    methods: {
      //获取参数
        getUrlParams:function(url){
            var urlArray=url.split("?")[1].split("&"),
                urlValue={};
            for(var i=0;i<urlArray.length;i++){
                var urlRowArray=urlArray[i].split("=");
                urlValue[urlRowArray[0]]=urlRowArray[1];
            }
            return urlValue;
        },
        hasClass:function(obj, cls){  
            return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
        },
        addClass:function(obj, cls){  
            if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
        },
        removeClass:function(obj, cls){  
            if (this.hasClass(obj, cls)) {  
                var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                obj.className = obj.className.replace(reg, ' ');  
            }  
        },
        handleSubmit(name) {
            this.$refs[name].validate((valid) => {
                const { desc } = this.formValidate;
                var descValue = desc;
                //期权账号  10 一个大写字母  9个数字
                if(this.formValidate.desc){
                    const descReg = /^[A-Z]{1}\d{9}/g; 
                    if(!descReg.test(descValue) || descValue.length != 10){
                        this.$Message.error('期权投资者账户由一个大写字母和9个数字组成！');
                        this.addClass(document.getElementById('AccountForm'),'ivu-form-item-error');
                        return;
                    }
                    this.removeClass(document.getElementById('AccountForm'),'ivu-form-item-error');
                    descValue = [descValue];                 
                }else{
                    descValue = ["ALL"];
                }
                if (valid) {
                    this.$Message.success('提交成功!');
                     this.testParams={
                        "limit":this.formValidate.showrow.toString(),   
                        "userId":this.getUrlParams(this.urlParams).userId,
                        "userName":this.getUrlParams(this.urlParams).userName,
                        "accountId":descValue
                    }
                    this.searchDate(this.testParams);
                } else {
                    this.$Message.error('表单验证失败!');
                }
            })
        },
        handleReset(name) {
            this.$refs[name].resetFields();
        },
        searchDate: function (requestParam) {
            this.isHide=false;

            //获取数据 并传递数据
            const url = '/dwapp/mktdt/qq_warrant_trade';
            fetch(url, {
                method: "POST",
                body: JSON.stringify(requestParam),
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json",
                    "signature":this.getUrlParams(this.urlParams).signature
                }
            }).then(function (response) {
                return response.json()
            }, function (error) {
                console.log(error)
            }).then(data => {
                var  exportButton1  =document.getElementById('calExportBtn')
                var dataResponse = data.resData;


                    if(dataResponse == null){
                        this.isHide=true;
                        this.$Message.warning("查询出错"+dataError);
                        this.tableData1 = [];
                        this.tableData2 = [];
                        this.dealitems = 0;

                        exportButton1.setAttribute("disabled",true);

                    }else{
                        if(dataResponse.length == 0){
                            this.isHide=true;
                            this.$Message.warning('查询无数据！');
                            this.tableData1 = [];
                            this.tableData2 = [];
                            this.dealitems = 0;

                            exportButton1.setAttribute("disabled",true);
                        }else{
                            var dataArray=[];
                            console.log(dataResponse)

                            for(var i=0;i<dataResponse.length;i++){
                                var dataRow={};
                                for(var key in dataResponse[i]){
                                    dataRow[key] = dataResponse[i][key];
                                }
                                dataArray.push(dataRow);
                            }

                            this.data1 = dataArray;
                            exportButton1.removeAttribute("disabled");

                            this.isHide=true;

                        }
                    }

            })
        },
         exportData (type) {
        //导出参数
        var downfileParams="&signature="+this.getUrlParams(this.urlParams).signature+
        "&userId="+this.getUrlParams(this.urlParams).userId+"&userName="+this.getUrlParams(this.urlParams).userName
        +"&limit="+this.formValidate.showrow.toString()+"&accountId="+this.formValidate.desc;
        if (type === 1) {
            window.location.href='/dwapp/download/dwapp_downfile?reportType=QQTZ&fileType=xls'+downfileParams;                    
        }
    },
    }


}
</script>

<style>

</style>

