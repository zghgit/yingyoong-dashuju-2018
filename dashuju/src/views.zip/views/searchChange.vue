<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">交易营业部变更查询</h2>
        <div class="mainBox changeBox">
            <Row :gutter="16">
                <Col span="19">
                    <Card style="min-height:780px">
                        <Spin id="loadBox" fix class="loadBox" v-bind:class="{ hide: isHide }">
                            <Icon type="load-c" size=40 class="loadIcon"></Icon>
                            <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                        </Spin>
                        <span id="lookInfoLink" class="lookInfo" @click="changeInfo = true">查看统计口径</span>
                        <Modal id="lookInfoPop" title="交易营业部变更查询  统计口径说明" v-model="changeInfo" class-name="vertical-center-modal" cancel-text>
                            <h3>数据说明</h3>
                            <p>数据时间范围：自2001年初至今</p>
                            <h3>指标说明</h3>
                            <p>无</p>
                            <h3>其他说明</h3>
                            <p>1．	“账户交易营业部变更情况”的查询结果基于该股东账户的成交明细数据（不含大宗交易）生成。如果该股东账户某一笔成交明细数据中的“统计PBU”字段（Stat_Seat_Code）对应的会员代码或营业部代码与前一笔成交记录不同，则在结果集内会按照该笔成交明细的会员营业部信息新增一条记录。
                            <br>
                            2．	“账户指定交易变动情况”的结果数据按照以下算法规则生成：
                            <br>
                            (1)	在新交易系统上线前（2009-11-20及以前），以“指定交易变动数据”中每条记录的“证券代码”（799999指定，799998撤销）为依据，来判断该账户的变动类型。在新交易系统上线后（2009-11-23及以后），以“指定交易变动数据”中每条记录的“业务代码”（DT指定，DC撤销）为依据，来判断该账户的变动类型。
                            <br>
                            (2)	查询结果数据中的“对应PBU”是指“指定交易变动数据” 中每条记录的“PBU代码”（或者“席位代码”），“对应营业部”是指根据“对应PBU”获取得到的“会员营业部名称”。
                            <br>
                            (3)	结果数据中，“变动类型”为“指定”的记录，其“对应PBU”和“对应营业部”为变动后的状态。“变动类型”为“撤销”的记录，其“对应PBU”和“对应营业部”为变动前的状态。
                        </p>
                        </Modal>
                        <!--头部logo-->
                        <Tabs type="card" :animated="false" v-model="scTabsValue">
                            <Tab-pane label="账户交易营业部变更情况" name="scTabs1">
                                <p id="infoTableList" class="redtext listlength">查询结果共&nbsp;{{dealitems}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="infoTable" :context="self" :data="tableData1" :columns="tableColumns1" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                            <Tab-pane label="账户指定交易变动情况" name="scTabs2">
                                <p id="infoTableListTwo" class="redtext listlength">查询结果共&nbsp;{{dealitemsTwo}}&nbsp;条记录</p>
                                <Table height="600" @on-sort-change="infoTableSort" id="infoTableTwo" :context="self" :data="tableData2" :columns="tableColumns2" size="small" ref="table" border stripe></Table>
                            </Tab-pane>
                        </Tabs>
                        <div style="text-align:right;margin-top:46px;margin-bottom:10px;">
                            <Button id="exportCurrent" type="primary" size="large" @click="exportData(1)"><Icon type="ios-download-outline"></Icon> 导出全部结果为XLS文件</Button>
                        </div>
                        
                    </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                    <Card style="min-height:780px">
                        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                            <b>股东账户</b><label class="redtext fontsize12">（不超过2500个）</label>
                            <Row class="uploadBox">
                                <Upload action="/base-service/api/decode_upfile?uploadType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount">
                                    <Button id="importAccountBtn" type="ghost">导入</Button>
                                </Upload>
                                <Button id="clearAccountBtn" v-on:click="clearOne()">清空</Button>
                            </Row>
                            <Row>
                                <p style="margin: 10px 0 5px 0;">已上传个数：<font id="infoUploadAccount" class="bluetext">{{accountList}}</font></p>
                                <Form-item prop="desc" id="AccountForm">
                                    <Input  id="AccountInput" v-model="formValidate.desc" @on-change="accountListChange" type="textarea" :rows="12" placeholder="请输入股东账号"></Input>
                                </Form-item>
                            </Row>
                            <Form-item class="showrow" prop="showrow">
                                在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p><label class="redtext fontsize12">(最多显示200行)</label></p>
                            </Form-item>
                            <Form-item>
                                <div class="cxBox"><Button id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查询</Button></div>
                            </Form-item>     
                            
                        </Form>

                    </Card>
                </Col>
            </Row>

        </div>
    </section>
</template>
<script>
import 'whatwg-fetch';  

    export default {
        //页面加载时执行
        mounted:function(){
            //获取URL地址参数
            var urlParams=window.location.href;
            var upfileParamsValue={};
            upfileParamsValue.signature=this.getUrlParams(urlParams).signature;
            this.upfileParams = upfileParamsValue;

        },
        data () {
            return {
                //选项卡切换值
                scTabsValue:'scTabs1',
                changeInfo:false,
                //查询参数初始化
                testParams:{},
                orderParams:{},
                urlParams:window.location.href,
                isHide:true,
                //文件解析参数
                upfileParams:this.upfileParamsValue,
                dealitems:0,
                dealitemsTwo:0, 
                //上传股东账户条数
				accountList: 0,
                formValidate: {
                    showrow:20,
                    desc: '',                   
                },
                ruleValidate: {
                    showrow: [
                        { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                    ],
                    desc: [
                        { required: true, message: '请输入股东账号', trigger: 'blur' },
                    ]
                },
                self: this,
                tableData1: [],
                tableData2: [],
                tableColumns1: [
                    {
                        title: '股东账户',
                        key: 'acctId',
                        "fixed": "left",
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '交易营业部变更日',
                        key: 'tradeDate',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '自该变更日起账户交易营业部',
                        key: 'memBranchName',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '自该变更日起账户交易PBU',
                        key: 'pbuId',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '账户最近交易日',
                        key: 'latestTradeDay',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '账户最近交易营业部',
                        key: 'latestBranch',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '账户最近交易PBU',
                        key: 'latestPbu',
                        "width": 150,
                        sortable: true,
                    },
                ],
                tableColumns2: [
                    {
                        title: '股东账户',
                        key: 'acctId',
                        "fixed": "left",
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '指定交易变动日期',
                        key: 'tradeDate',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '变动类型',
                        key: 'chgDesc',
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '对应PBU',
                        key: 'pbuId',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '对应营业部',
                        key: 'branchName',
                        "width": 150,
                        sortable: true,
                    },
                    
                ],
            }
        },
        methods: {
            //获取参数
            getUrlParams:function(url){
                var urlArray=url.split("?")[1].split("&"),
                    urlValue={};
                for(var i=0;i<urlArray.length;i++){
                    var urlRowArray=urlArray[i].split("=");
                    urlValue[urlRowArray[0]]=urlRowArray[1];
                }
                return urlValue;
            },
            //设置fetch请求超时方法
             _fetch:function(fetch_promise, timeout) {
                var abort_fn = null;
                var abortInfo=this;
                //这是一个可以被reject的promise
                var abort_promise = new Promise(function(resolve, reject) {
                        abort_fn = function() {
                            console.log('查询超时abort promise');
                            // abortInfo.$Message.warning('查询超时！请重试！');
                        };
                });
                //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
                var abortable_promise = Promise.race([
                        fetch_promise,
                        abort_promise
                ]);
                setTimeout(function() {
                        abort_fn();
                    }, timeout);
                return abortable_promise;
            }, 
            //股东账户已上传条数
			accountListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				let arrNew = [];
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.accountList = arr.length;
			},
            //股东账号导入
			handleSuccessAccount(response, file, fileList){
                const arry = response.resData;
                console.log(arry)
                let str = '';
                let  arryAll= [];
                for(var i = 0; i < arry.length; i++){
                    arryAll.push(arry[i]);
                }
                console.log(arryAll)
                this.dataLookInfo = arryAll
                this.accountList = arryAll.length;
                str = arryAll.join('\n');
                this.formValidate.desc = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
			},
            //原声js写jquery方法
            hasClass:function(obj, cls){  
                return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
            },
            addClass:function(obj, cls){  
                if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
            },
            removeClass:function(obj, cls){  
                if (this.hasClass(obj, cls)) {  
                    var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                    obj.className = obj.className.replace(reg, ' ');  
                }  
            },
            toggleClass:function(obj,cls){  
                if(this.hasClass(obj,cls)){  
                    this.removeClass(obj, cls);  
                }else{  
                    this.addClass(obj, cls);  
                }  
            },
            //传排序参数
            infoTableSort:function(sort){
                orderParams.field=sort.key;
                orderParams.sort=sort.order;
            },
            //查询表单数据
            searchData:function(requestParam){
                this.orderParams={};
                this.isHide=false;
                let url = '/dwapp/mktdt/br_trade_all';

                // if(this.scTabsValue == 'scTabs1'){
                //     url = '/dwapp/mktdt/br_trd_update';
                //     console.log(url,"url1111111------------------");
                // }
                // if(this.scTabsValue == 'scTabs2'){
                //     url = '/dwapp/mktdt/br_trade_change';
                //     console.log(url,"url222222------------------");
                // }

                this._fetch(fetch(url, {
                    method: "POST",
                    body: JSON.stringify(requestParam),
                    mode: 'cors',
                    headers: {
                        "Content-Type": "application/json",
                        "signature":this.getUrlParams(this.urlParams).signature
                    }
                }), 1800000).then(function (response) {
                    return response.json()
                }, function (error) {
                    this.$Message.error('系统繁忙，刷新页面!');
                }).then(data => {
                    var exportButton1 = document.getElementById("exportCurrent");

                    //取数据
                    var dataResponse=data.resData;
                    var dataError=data.message;
                    var datalength = data.respSize;

                    if(dataResponse == null){
                        this.isHide=true;
                        this.$Message.warning("查询出错"+dataError);
                        this.tableData1 = [];
                        this.tableData2 = [];
                        this.dealitems = 0;
                        this.dealitemsTwo = 0;

                        exportButton1.setAttribute("disabled",true);

                    }else{
                        if(dataResponse.length == 0){
                            this.isHide=true;
                            this.$Message.warning('查询无数据！');
                            this.tableData1 = [];
                            this.tableData2 = [];
                            this.dealitems = 0;
                            this.dealitemsTwo = 0;

                            exportButton1.setAttribute("disabled",true);
                        }else{
                            var dataArray1=[],dataArray2=[];
                            this.dealitems = dataResponse.tradeDepartmentUpdate.size;
                            this.dealitemsTwo =dataResponse.tradeDepartmentChange.size;

                            var dataResponse1 = dataResponse.tradeDepartmentUpdate,
                                dataResponse2 = dataResponse.tradeDepartmentChange;

                            // for(var i=0;i<dataResponse1.length;i++){
                            //     var dataRow={};
                            //     for(var key in dataResponse1[i]){
                            //         dataRow[key] = dataResponse1[i][key];
                            //     }
                            //     dataArray1.push(dataRow);
                            // }

                            // for(var i=0;i<dataResponse2.length;i++){
                            //     var dataRow={};
                            //     for(var key in dataResponse2[i]){
                            //         dataRow[key] = dataResponse2[i][key];
                            //     }
                            //     dataArray2.push(dataRow);
                            // }

                            this.tableData1 = dataResponse1.data;
                            this.tableData2 = dataResponse2.data;
                            exportButton1.removeAttribute("disabled");

                            this.isHide=true;

                        }
                    }
                })
            },
            handleSubmit (name) {
                this.$refs[name].validate((valid) => {
                    const { desc } = this.formValidate;
                    var descValue = desc;
                    //股东账号  10 一个大写字母  9个数字
					if(this.formValidate.desc){
						const descStr = descValue.replace(/[\r\n]/g,',');
						let descArry = descStr.split(',');
                        //判断上传股东账户不能超过2500
                        if(descArry.length>2500){
                            this.$Message.error('股东账号不能超过2500个!');
                            return;
                        }
						for(var i=0; i < descArry.length; i++){
							const descVal = descArry[i].trim();
							const descReg = /^[A-Z]{1}\d{9}/g; 
							if(!descReg.test(descVal) || descVal.length != 10){
								this.$Message.error('股东账号由一个大写字母和9个数字组成！');//AccountForm
								this.addClass(document.getElementById('AccountForm'),'ivu-form-item-error');
								return;
							}
						}
						this.removeClass(document.getElementById('AccountForm'),'ivu-form-item-error');
						// descValue = descArry.join(',');
                        descValue = descArry;
					}

                    if (valid) {
                        this.$Message.success('提交成功!请等待~'); 
                        //获取请求参数
                        this.testParams={
                            "accountId":descValue,"limit":this.formValidate.showrow.toString(),
                            "userId":this.getUrlParams(this.urlParams).userId, "userName":this.getUrlParams(this.urlParams).userName,
                            "startDate":"20170620","endDate":"20170620","secCode":["123123"]
                            }
                        console.log(this.testParams,"-----testParams111111111");
                        this.searchData(this.testParams);
                        
                    } else {
                        this.$Message.error('表单验证失败!');
                    }
                })
            },
            clearOne:function(){
                this.formValidate.desc="";
                this.accountList=0;
            },
            exportData (type) {
                //导出参数
                var descValue = this.testParams.accountId,
                    descStr = descValue.join(",");
                console.log(descStr,"---------------------导出股东账号");
                var downfileParams="&signature="+this.getUrlParams(this.urlParams).signature+
                "&userId="+this.getUrlParams(this.urlParams).userId+"&userName="+this.getUrlParams(this.urlParams).userName+
                "&limit="+this.formValidate.showrow.toString()+"&startDate=20170620&endDate=20170620&secCode=123123"+
                "&accountId="+descStr;
                if (type === 1) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=TRADECHANGE&fileType=xlsx'+downfileParams;                    
                }
            },
        }
    }
</script>