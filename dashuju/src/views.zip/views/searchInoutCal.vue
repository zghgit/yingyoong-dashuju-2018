<template>
    <section class='constWidth'>
        <!--头部-->
        <header></header>
        <Spin id="show" fix class="loadBox" v-bind:class="{hide:ishide}">
            <Icon type="load-c" size=40 class="loadIcon"></Icon>
            <div style="font-size:16px;">&nbsp;&nbsp;&nbsp;数据加载中...</div>
        </Spin>
        <Tabs :animated="false" value="" type="card" class="inoutCalBox" style="min-width:1260px;">
            <Tab-pane label="输出成交明细和费用">
                <Row :gutter="16">
                    <Col span="19">
                    <Card style="min-height:780px;">
                        <p slot="title">输出成交明细和费用</p>
                        <Row style="margin-top:-10px; margin-bottom:10px;">
                            <a>
                                <span @click="modalOne = true" style="color:#5cadff;text-decoration:underline;">查看统计口径</span>
                            </a>
                            <Modal class="modal" title="统计口径说明" v-model="modalOne" class-name="vertical-center-modal" width='700' cancel-text>
                                <h3 class="">
                                    <b>数据说明</b>
                                </h3>
                                <p class="textP">数据时间范围：自2003年初至今
                                    <br>证券选择范围：A股、B股、封闭式基金、ETF基金、债券现券、权证
                                    <br>平台范围： 竞价系统，大宗交易系统</p>
                                <h3 class="">
                                    <b>指标说明</b>
                                </h3>
                                <p class="textP">印花税 = 买（卖）金额 * 买（卖）方向印花税率
                                    <br> 过户费 = 成交股数 / 1000（A股） = 成交金额*0.05% （B 股）
                                    <br> 佣金 = 成交金额 * 佣金费率 注：仅A，B股交易有印花税，过户费。
                                    <br> 债券佣金费率为0.02%，其他按前端输入费率，前端无输入则按缺省0.3%计算
                                </p>
                                </p>
                                <h3 class="">
                                    <b>其他说明</b>
                                </h3>
                                <p class="textP">无</p>
                            </Modal>
                        </Row>
                        <p class="redtext">查询结果共 {{this.data1.length}}记录
                        </p>
                        <Table height="600" :columns="columns1" ref='tableOneExport' :data="data1"></Table>
                        <Row style="float:right;">
                            <Button id="calExportBtnOne" type="primary" style="width:300px;  margin-top:20px;" @click='exportTable' disabled>导出全部结果为XLS文件</Button>
                        </Row>
                    </Card>
                    </Col>
                    <Col span="5">
                    <Card style="min-height:780px;">
                        <p slot="title"></p>
                        <Form ref="formValidateOne" :model="formValidateOne" :rules="ruleValidateOne">
                            <Row class="uploadBox proCalBtnBox">
                                <Upload ref="upload" :show-upload-list="false" accept=".xls,.xlsx,.csv" :default-file-list="defaultList" :format="['xls','csv']" :max-size="2048" :on-format-error="handleFormatError" :on-exceeded-size="handleMaxSize" :before-upload="handleBeforeUpload" multiple action="//jsonplaceholder.typicode.com/posts/" style="display: inline-block;">
                                    <Button type="ghost" class="uploadExcel">Excel上传</Button>
                                </Upload>
                                <Button @click="lookUploadInfo = true" type="ghost">查看</Button>
                                <Modal v-model="lookUploadInfo" title="查看已上传的文件" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="lookInfoTable" border stripe :columns="columnsLookInfo" :data="dataLookInfo"></Table>
                                </Modal>
                                <Button id="templateBtn" @click="templateInfo = true">模板</Button>
                                <Modal title="账面盈利计算文件模板" v-model="templateInfo" width="684" class-name="vertical-center-modal" cancel-text>
                                    <Table id="templateTable" border stripe :columns="columnsTemplate" :data="dataTemplate"></Table>
                                </Modal>
                            </Row>
                            <Row class="procalList" style="margin-top:10px; margin-Bottom:-10px">
                                <p>已上传记录总数:
                                    <span class="bluetext">{{items}}</span>
                                </p>
                                <p style="margin-top:5px;">其中有效记录数:
                                    <span  class="bluetext">{{items}}</span>
                                </p>
                            </Row>
                            <br>
                            <h4>佣金费率</h4>
                            <Form-item>
                                <Input-number :max="100" :min="0" :step="0.1" v-model="formValidateOne.inputNumberOne" style="width:70%;"></Input-number>
                                <label  class="bluetext">&nbsp;&nbsp;%</label>
                            </Form-item>
                            <Form-item prop="inputOne" style="margin-top:-10px;">
                                在页面上显示前&nbsp;&nbsp;
                                <Input-number id="inputOne" v-model="formValidateOne.inputOne" :max="200" :min="1" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p>
                                    <label class="redtext fontsize12">(最多显示200行)</label>
                                </p>
                            </Form-item>
                            <Form-item>
                                <div class="cxBox">
                                    <Button id="searchBtn" type="primary" @click="handleSubmitOne('formValidateOne')" style="float:right;width:80px;">查询</Button>
                                </div>
                            </Form-item>
                        </Form>
                    </Card>
                    </Col>
                </Row>
            </Tab-pane>
            <Tab-pane label="输出买卖记录对应数据表">
                <Row :gutter="16">
                    <Col span="19">
                    <Card style="min-height:780px;">
                        <p slot="title">输出买卖记录对应数据表</p>
                        <Row style="margin-top:-10px; margin-bottom:10px;">
                            <a>
                                <span @click="modalTwo = true" style="color:#5cadff;text-decoration:underline;">查看统计口径</span>
                            </a>
                            <Modal class="modal" title="统计口径说明" v-model="modalTwo" class-name="vertical-center-modal" cancel-text width='700' height='1000' cancel-text>
                                <h3 class="text">
                                    <b>数据说明</b>
                                </h3>
                                <p class="textP">无</p>
                                <h3 class="text">
                                    <b>指标说明</b>
                                </h3>
                                <p class="textP">无</p>
                                </p>
                                <h3 class="text">
                                    <b>其他说明</b>
                                </h3>
                                <p class="textP">无</p>
                            </Modal>
                        </Row>
                        <p class="redtext">查询结果共 {{this.data2.length}}记录
                        </p>
                        <Table height="600" :columns="columns2" ref='tableTwoExport' :data="data2" style="overflow-x:scroll"></Table>
                        <Row style="margin-top: 20px;text-align: center;">
                            <Button id="calExportBtnTwoFirst" type="primary" style="width:300px;" @click='exportTable' disabled>将查询结果导出为XLS文件（先进先出）</Button>
                            <Button id="calExportBtnTwoSecond" type="primary" style="width:300px;  margin-left:10px;" @click='exportTable' disabled>将查询结果导出为XLS文件（后进后出）</Button>
                        </Row>
    
                    </Card>
                    </Col>
                    <Col span="5">
                    <Card style="min-height:780px;">
                        <p slot="title"></p>
                        <Form ref="formValidateTwo" :model="formValidateTwo" :rules="ruleValidateTwo">
                            <Row class="uploadBox proCalBtnBox">
                                <Upload ref="upload" :show-upload-list="false" accept=".xls,.xlsx,.csv" :default-file-list="defaultList" :format="['xls','csv','xlsx']" :max-size="2048" :on-format-error="handleFormatError" :on-exceeded-size="handleMaxSize" :before-upload="handleBeforeUpload" multiple action="//jsonplaceholder.typicode.com/posts/" style="display: inline-block;">
                                    <Button type="ghost" class="uploadExcel">Excel上传</Button>
                                </Upload>
                                <Button @click="formValidateTwo.modalTwoFirst = true" type="ghost">查看</Button>
                                <Modal title="查看已上传的文件" v-model="formValidateTwo.modalTwoFirst" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="lookInfoTable" border stripe :columns="columnsLookInfoTwo" :data="dataLookInfoTwo"></Table>
                                </Modal>
                                <Button @click="formValidateTwo.modalTwoSecond = true" type="ghost">模版</Button>
                                <Modal title="账面盈利计算文件模板" v-model="formValidateTwo.modalTwoSecond" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="templateTable" border stripe :columns="columnsTemplateTwo" :data="dataTemplateTwo"></Table>
                                </Modal>
                            </Row>
    
                            <Row class="procalList" style="margin-top:10px; margin-Bottom:10px">
                                <p>已上传记录总数:
                                    <span  class="bluetext">{{items}}</span>
                                </p>
                                <p style="margin-top:5px;">其中有效记录数:
                                    <span  class="bluetext">{{items}}</span>
                                </p>
                            </Row>
    
                            <b style="font-size:16px;">算法选择</b>
                            <Form-item>
    
                                <Radio-group v-model="formValidateTwo.singleTwo" @on-change="radiochangeTwo">
                                    <Radio label="先进先出" ></Radio>
                                    <Radio label="后进后出" ></Radio>
                                </Radio-group>
                            </Form-item>
    
                            <Form-item prop="inputTwo" style="margin-top:-10px;">
                                在页面上显示前&nbsp;&nbsp;
                                <Input-number id="inputTwo" v-model="formValidateTwo.inputTwo" :max="200" :min="1" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p>
                                    <label class="redtext fontsize12">(最多显示200行)</label>
                                </p>
                            </Form-item>
                            <Form-item>
                                <Button type="primary" @click="handleSubmitTwo('formValidateTwo')" style="float:right;width:80px;">查询</Button>
                            </Form-item>
    
                        </Form>
    
                    </Card>
                    </Col>
                </Row>
    
            </Tab-pane>
            <Tab-pane label="输出盈利统计表" name="tableThreeXls">
    
                <Row :gutter="16">
                    <Col span="19">
                    <Card style="min-height:780px;">
                        <p slot="title">输出盈利统计表</p>
                        <Row style="margin-top:-10px; margin-bottom:10px;">
                            <a>
                                <span @click="modalThree = true" style="color:#5cadff;text-decoration:underline;">查看统计口径</span>
                            </a>
                            <Modal class="modal" title="统计口径说明" v-model="modalThree" class-name="vertical-center-modal" cancel-text width='700' height='1000' cancel-text>
                                <h3 class="text">
                                    <b>数据说明</b>
                                </h3>
                                <p class="textP">无</p>
                                <h3 class="text">
                                    <b>指标说明</b>
                                </h3>
                                <p class="textP">违法所得 =卖出金额 -买入金额 -印花税 - 过户费 -交易佣金估算</p>
                                </p>
                                <h3 class="text">
                                    <b>其他说明</b>
                                </h3>
                                <p class="textP">此盈利算法不特别考虑分红配送的情况</p>
                            </Modal>
                        </Row>
                        <p class="redtext">查询结果共 {{this.data3.length}}记录
                        </p>
                        <Table height="600" :columns="columns3" ref='tableThreeExport' :data="data3"></Table>
                        <Row  style="margin-top: 20px;text-align: center;">
                            <Button id="calExportBtnThreeFirst" type="primary" style="width:300px;" disabled>将查询结果导出为XLS文件（先进先出） </Button>
                            <Button id="calExportBtnThreeSecond" type="primary" style="width:300px; margin-left:10px;" disabled>将查询结果导出为XLS文件（后进后出）</Button>
                        </Row>
                    </Card>
                    </Col>
                    <Col span="5">
                    <Card style="min-height:780px;">
                        <p slot="title"></p>
                        <Form ref="formValidateThree" :model="formValidateThree" :rules="ruleValidateThree">
                            <p slot="title"></p>
                            <b>文件上传</b>
                            <small class="redtext">（先进先出）</small>
                            <Row style="margin-top:10px;" class="uploadBox proCalBtnBox">
                                <Upload ref="upload" :show-upload-list="false" accept=".xls,.xlsx,.csv" :default-file-list="defaultList" :format="['xls','csv']" :max-size="2048" :on-format-error="handleFormatError" :on-exceeded-size="handleMaxSize" :before-upload="handleBeforeUpload" multiple action="//jsonplaceholder.typicode.com/posts/" style="display: inline-block;">
                                    <Button type="ghost" class="uploadExcel">Excel上传</Button>
                                </Upload>
    
                                <Button @click="formValidateThree.modalThreeFirst = true" type="ghost">查看</Button>
                                <Modal title="查看上传列表" v-model="formValidateThree.modalThreeFirst" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="lookInfoTable" border stripe :columns="columnsLookInfoThreeFirst" :data="dataLookInfoThreeFirst"></Table>
                                </Modal>
                                <Button @click="formValidateThree.modalThreeSecond = true" type="ghost">模版</Button>
                                <Modal title="模版" v-model="formValidateThree.modalThreeSecond" width="684" class-name="vertical-center-modal" cancel-text>
                                    <Table id="templateTable" border stripe :columns="columnsTemplateThreeFirst" :data="dataTemplateThreeFirst"></Table>
                                </Modal>
                            </Row>
    
                            <Row style="margin-top:10px; margin-Bottom:15px">
                                <p>已上传记录总数:
                                    <span  class="bluetext">{{items}}</span>
                                </p>
                                <p style="margin-top:5px;">其中有效记录数:
                                    <span  class="bluetext">{{items}}</span>
                                </p>
                            </Row>
                            <b>文件上传</b>
                            <small class="redtext">（后进后出）</small>
    
                            <Row style="margin-top:10px;" class="uploadBox proCalBtnBox" >
                                <Upload ref="upload" :show-upload-list="false" accept=".xls,.xlsx,.csv" :default-file-list="defaultList" :format="['xls','csv']" :max-size="2048" :on-format-error="handleFormatError" :on-exceeded-size="handleMaxSize" :before-upload="handleBeforeUpload" multiple action="//jsonplaceholder.typicode.com/posts/" style="display: inline-block;">
                                    <Button type="ghost"  class="uploadExcel">Excel上传</Button>
                                </Upload>
    
                                <Button @click="formValidateThree.modalThreeThird = true" type="ghost">查看</Button>
                                <Modal title="查看上传列表" v-model="formValidateThree.modalThreeThird" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="lookInfoTable" border stripe :columns="columnsLookInfoThreeSecond" :data="dataLookInfoThreeSecond"></Table>
                                </Modal>
                                <Button @click="formValidateThree.modalThreeForth = true" type="ghost">模版</Button>
                                <Modal title="模版" v-model="formValidateThree.modalThreeForth" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="templateTable" border stripe :columns="columnsTemplateThreeSecond" :data="dataTemplateThreeSecond"></Table>
                                </Modal>
                            </Row>
    
                            <Row style="margin-top:10px; margin-Bottom:10px">
                                <p>已上传记录总数:
                                    <span class="bluetext">{{items}}</span>
                                </p>
                                <p style="margin-top:5px;">其中有效记录数:
                                    <span class="bluetext">{{items}}</span>
                                </p>
                            </Row>
                            <Form-item>
                                <b style="font-size:16px;">算法选择</b>
                                <br>
                                <Radio-group v-model="formValidateThree.singleThree" @on-change="radiochangeThree">
                                    <Radio label="先进先出" id="radioThreeFirst" name="radioThreeFirst" ></Radio>
                                    <Radio label="后进后出" id="radioThreeSecond" name='radioThreeSecond' ></Radio>
                                </Radio-group>
                            </Form-item>
                            <Form-item prop="inputThree" style="margin-top:-10px;">
                                在页面上显示前&nbsp;&nbsp;
                                <Input-number id="inputThree" v-model="formValidateThree.inputThree" :max="200" :min="1" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p>
                                    <label class="redtext fontsize12">(最多显示200行)</label>
                                </p>
                            </Form-item>
                            <Form-item>
                                <Button type="primary" @click="handleSubmitThree('formValidateThree')" style="float:right;width:80px;">查询</Button>
                            </Form-item>
    
                        </Form>
                    </Card>
                    </Col>
                </Row>
            </Tab-pane>
            <Tab-pane label="输出高送转明细" name="tableFourXls">
    
                <Row :gutter="16">
                    <Col span="19">
                    <Card style="min-height:780px;">
                        <p slot="title">输出高送转明细</p>
                        <Row style="margin-top:-10px; margin-bottom:10px;">
                            <a>
                                <span @click="modalFour = true" style="color:#5cadff;text-decoration:underline;">查看统计口径</span>
                            </a>
                            <Modal class="modal" title="统计口径说明" v-model="modalFour" class-name="vertical-center-modal" cancel-text width='700' height='1000' cancel-text>
                                <h3 class="text">
                                    <b>数据说明</b>
                                </h3>
                                <p class="textP">无</p>
                                <h3 class="text">
                                    <b>指标说明</b>
                                </h3>
                                <p class="textP">无</p>
                                </p>
                                <h3 class="text">
                                    <b>其他说明</b>
                                </h3>
                                <p class="textP">根据录入的证券及开始结束时间，输出期间有过送转股的记录(由于对高送转的比例无明确定义，故只要有送转记录的均输出)</p>
                            </Modal>
                        </Row>
                        <p class="redtext">查询结果共{{this.data4.length}}记录</p>
                        <Table height="600" :columns="columns4" ref='tableFourExport' :data="data4"></Table>
                        <Row style="float:right">
                            <Button id="calExportBtnFour" type="primary" style="width:300px;  margin-top:20px;" disabled>导出全部结果为XLS文件</Button>
                        </Row>
                    </Card>
                    </Col>
                    <Col span="5">
                    <Card style="min-height:780px;">
                        <p slot="title"></p>
                        <p style="color:rgb(216,81,36);">
                            <b>如果不上传文件则直接使用输出成交明细和费用中的证卷代码,开始日期,结束日期作为查询条件。</b>
                        </p>
                        <Form ref="formValidateFour" :model="formValidateFour" :rules="ruleValidateFour" style="margin-top:10px">
                            <Row class="uploadBox proCalBtnBox" >
                                <Upload ref="upload" :show-upload-list="false" accept=".xls,.xlsx,.csv" :default-file-list="defaultList" :format="['xls','csv']" :max-size="2048" :on-format-error="handleFormatError" :on-exceeded-size="handleMaxSize" :before-upload="handleBeforeUpload" multiple action="//jsonplaceholder.typicode.com/posts/" style="display: inline-block;">
                                    <Button type="ghost" class="uploadExcel">Excel上传</Button>
                                </Upload>
    
                                <Button @click="formValidateFour.modalFourFirst = true" type="ghost">查看</Button>
                                <Modal title="查看上传列表" v-model="formValidateFour.modalFourFirst" width="884" class-name="vertical-center-modal" cancel-text>
                                    <Table id="lookInfoTable" border stripe :columns="columnsLookInfoFour" :data="dataLookInfoFour"></Table>
                                </Modal>
                                <Button @click="formValidateFour.modalFourSecond = true" type="ghost">模版</Button>
                                <Modal title="模版" v-model="formValidateFour.modalFourSecond" width="684" class-name="vertical-center-modal" cancel-text>
                                    <Table id="templateTable" border stripe :columns="columnsTemplateFour" :data="dataTemplateFour"></Table>
                                </Modal>
                            </Row>
                            <Row style="margin-top:10px; margin-Bottom:10px">
                                <p>已上传记录总数:
                                    <span class="bluetext">{{items}}</span>
                                </p>
                                <p style="margin-top:5px;">其中有效记录数:
                                    <span class="bluetext">{{items}}</span>
                                </p>
                            </Row>
                            <Form-item prop="inputFour">
                                在页面上显示前&nbsp;&nbsp;
                                <Input-number id="inputFourForm" v-model="formValidateFour.inputFour" :max="200" :min="1" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                                <p>
                                    <label class="redtext fontsize12">(最多显示200行)</label>
                                </p>
                            </Form-item>
                            <Form-item>
                                <Button type="primary" @click="handleSubmitFour('formValidateFour')" style="float:right;width:80px;">查询</Button>
                            </Form-item>
                        </Form>
                    </Card>
                    </Col>
                </Row>
    
            </Tab-pane>
        </Tabs>
    </section>
</template>

<script>
// import Introduce from '../components/introduce'


export default {
    name: 'compute',
    data() {
        return {
            //查看 模板
            columnsTemplate: [
                {
                    title: '股东账户',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 100,
                },
                {
                    title: '开始日期',
                    key: 'startDate',
                    width: 150,
                },
                {
                    title: '结束日期',
                    key: 'endDate',
                    width: 150,
                },
                {
                    title: '佣金比例',
                    key: 'yjRate',
                    width: 100,
                },
            ],
            dataTemplate: [
                {
                    gdAccounts: 'A000832200',
                    zqCode: 'ALL',
                    startDate: '20100115',
                    endDate: '20110423',
                    yjRate: 0.002,
                },
                {
                    gdAccounts: 'A530916975',
                    zqCode: 'ALL',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
                {
                    gdAccounts: 'A684165286',
                    zqCode: '600081',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
            ],
            columnsLookInfo: [
                {
                    title: '是否有效',
                    key: 'isEffective',
                    width: 100,
                },
                {
                    title: '股东账户',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 100,
                },
                {
                    title: '开始日期',
                    key: 'startDate',
                    width: 150,
                },
                {
                    title: '结束日期',
                    key: 'endDate',
                    width: 150,
                },
                {
                    title: '佣金比例',
                    key: 'yjRate',
                    width: 100,
                },
                {
                    title: '说明',
                    key: 'explainInfo',
                    width: 100,
                }
            ],
            dataLookInfo: [
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
            ],


            //Two查看模版
            columnsTemplateTwo: [
                {
                    title: '账户代码',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'startDate',
                    width: 90,
                },
                {
                    title: '成交时间',
                    key: 'endDate',
                    width: 90,
                },
                {
                    title: '成交编号',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '成交价格',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '成交金额',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '席位',
                    key: 'startDate',
                    width: 80,
                },
                {
                    title: '申报编码',
                    key: 'endDate',
                    width: 90,
                },
                {
                    title: '申报时间',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '成交方向',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '印花税',
                    key: 'zqCode',
                    width: 80,
                },
                {
                    title: '过户费',
                    key: 'startDate',
                    width: 80,
                },
                {
                    title: '交易佣金估算',
                    key: 'endDate',
                    width: 110,
                },
                {
                    title: '实际交易佣金',
                    key: 'yjRate',
                    width: 110,
                },
            ],
            dataTemplateTwo: [
                {
                    gdAccounts: 'A000832200',
                    zqCode: 'ALL',
                    startDate: '20100115',
                    endDate: '20110423',
                    yjRate: 0.002,
                },
                {
                    gdAccounts: 'A530916975',
                    zqCode: 'ALL',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
                {
                    gdAccounts: 'A684165286',
                    zqCode: '600081',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
            ],
            columnsLookInfoTwo: [
                {
                    title: '是否有效',
                    key: 'isEffective',
                    width: 90,
                },
                {
                    title: '账户代码',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'startDate',
                    width: 90,
                },
                {
                    title: '成交时间',
                    key: 'endDate',
                    width: 90,
                },
                {
                    title: '成交编号',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '成交价格',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '成交金额',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '席位',
                    key: 'startDate',
                    width: 80,
                },
                {
                    title: '申报编码',
                    key: 'endDate',
                    width: 90,
                },
                {
                    title: '申报时间',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '成交方向',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '印花税',
                    key: 'zqCode',
                    width: 80,
                },
                {
                    title: '过户费',
                    key: 'startDate',
                    width: 80,
                },
                {
                    title: '交易佣金估算',
                    key: 'endDate',
                    width: 120,
                },
                {
                    title: '实际交易佣金',
                    key: 'yjRate',
                    width: 120,
                },
                {
                    title: '说明',
                    key: 'explainInfo',
                    width: 70,
                }
            ],
            dataLookInfoTwo: [
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
            ],

            //Three查看模版(先进先出)
            columnsTemplateThreeFirst: [
                {
                    title: '账户代码',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'startDate',
                    width: 90,
                },
                {
                    title: '买方成交编号',
                    key: 'endDate',
                    width: 120,
                },
                {
                    title: '买入价格',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '买入金额',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '买入量',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '买方印花税',
                    key: 'startDate',
                    width: 100,
                },
                {
                    title: '买方过户费',
                    key: 'endDate',
                    width: 100,
                },
                {
                    title: '买方交易佣金估算',
                    key: 'yjRate',
                    width: 150,
                },
                {
                    title: '买方交易实际佣金',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: 'zqCode',
                    width: 250,
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: 'startDate',
                    width: 170,
                },
                {
                    title: '对应该笔成交的卖出',
                    key: 'endDate',
                    width: 160,
                },
                {
                    title: '对应该笔成交卖方印花税',
                    key: 'yjRate',
                    width: 170,
                },
                {
                    title: '对应该笔成交卖方过户费',
                    key: 'zqCode',
                    width: 180,
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: 'startDate',
                    width: 210,
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: 'endDate',
                    width: 220,
                },

            ],
            dataTemplateThreeFirst: [
                {
                    gdAccounts: 'A000832200',
                    zqCode: 'ALL',
                    startDate: '20100115',
                    endDate: '20110423',
                    yjRate: 0.002,
                },
                {
                    gdAccounts: 'A530916975',
                    zqCode: 'ALL',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
                {
                    gdAccounts: 'A684165286',
                    zqCode: '600081',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
            ],
            columnsLookInfoThreeFirst: [
                {
                    title: '是否有效',
                    key: 'isEffective',
                    width: 90,
                },
                {
                    title: '账户代码',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'startDate',
                    width: 90,
                },
                {
                    title: '买方成交编号',
                    key: 'endDate',
                    width: 120,
                },
                {
                    title: '买入价格',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '买入金额',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '买入量',
                    key: 'zqCode',
                    width: 80,
                },
                {
                    title: '买方印花税',
                    key: 'startDate',
                    width: 100,
                },
                {
                    title: '买方过户费',
                    key: 'endDate',
                    width: 100,
                },
                {
                    title: '买方交易佣金估算',
                    key: 'yjRate',
                    width: 150,
                },
                {
                    title: '买方交易实际佣金',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: 'zqCode',
                    width: 250,
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: 'startDate',
                    width: 180,
                },
                {
                    title: '对应该笔成交的卖出',
                    key: 'endDate',
                    width: 160,
                },
                {
                    title: '对应该笔成交卖方印花税',
                    key: 'yjRate',
                    width: 180,
                },
                {
                    title: '对应该笔成交卖方过户费',
                    key: 'zqCode',
                    width: 180,
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: 'startDate',
                    width: 220,
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: 'endDate',
                    width: 220,
                },
                {
                    title: '说明',
                    key: 'explainInfo',
                    width: 70,
                }
            ],
            dataLookInfoThreeFirst: [
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
            ],
            //three  后进后出
            //Three查看模版
            columnsTemplateThreeSecond: [
                {
                    title: '账户代码',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'startDate',
                    width: 90,
                },
                {
                    title: '卖方成交编号',
                    key: 'endDate',
                    width: 120,
                },
                {
                    title: '卖入价格',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '卖入金额',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '卖入量',
                    key: 'zqCode',
                    width: 80,
                },
                {
                    title: '卖方印花税',
                    key: 'startDate',
                    width: 100,
                },
                {
                    title: '卖方过户费',
                    key: 'endDate',
                    width: 100,
                },
                {
                    title: '卖方交易佣金估算',
                    key: 'yjRate',
                    width: 150,
                },
                {
                    title: '卖方交易实际佣金',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: 'zqCode',
                    width: 250,
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: 'startDate',
                    width: 180,
                },
                {
                    title: '对应该笔成交的卖出',
                    key: 'endDate',
                    width: 160,
                },
                {
                    title: '对应该笔成交买方印花税',
                    key: 'yjRate',
                    width: 180,
                },
                {
                    title: '对应该笔成交买方过户费',
                    key: 'zqCode',
                    width: 180,
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: 'startDate',
                    width: 220,
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: 'endDate',
                    width: 220,
                },

            ],
            dataTemplateThreeSecond: [
                {
                    gdAccounts: 'A000832200',
                    zqCode: 'ALL',
                    startDate: '20100115',
                    endDate: '20110423',
                    yjRate: 0.002,
                },
                {
                    gdAccounts: 'A530916975',
                    zqCode: 'ALL',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
                {
                    gdAccounts: 'A684165286',
                    zqCode: '600081',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
            ],
            columnsLookInfoThreeSecond: [
                {
                    title: '是否有效',
                    key: 'isEffective',
                    width: 90,
                },
                {
                    title: '账户代码',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'startDate',
                    width: 90,
                },
                {
                    title: '卖方成交编号',
                    key: 'endDate',
                    width: 120,
                },
                {
                    title: '卖入价格',
                    key: 'yjRate',
                    width: 90,
                },
                {
                    title: '卖入金额',
                    key: 'gdAccounts',
                    width: 90,
                },
                {
                    title: '卖入量',
                    key: 'zqCode',
                    width: 80,
                },
                {
                    title: '卖方印花税',
                    key: 'startDate',
                    width: 100,
                },
                {
                    title: '卖方过户费',
                    key: 'endDate',
                    width: 100,
                },
                {
                    title: '卖方交易佣金估算',
                    key: 'yjRate',
                    width: 150,
                },
                {
                    title: '卖方交易实际佣金',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: 'zqCode',
                    width: 250,
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: 'startDate',
                    width: 180,
                },
                {
                    title: '对应该笔成交的卖出',
                    key: 'endDate',
                    width: 160,
                },
                {
                    title: '对应该笔成交买方印花税',
                    key: 'yjRate',
                    width: 180,
                },
                {
                    title: '对应该笔成交买方过户费',
                    key: 'zqCode',
                    width: 180,
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: 'startDate',
                    width: 220,
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: 'endDate',
                    width: 220,
                },

                {
                    title: '说明',
                    key: 'explainInfo',
                    width: 70,
                }
            ],
            dataLookInfoThreeSecond: [
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
            ],

            //Four查看模版
            //查看 模板
            columnsTemplateFour: [
                {
                    title: '股东账户',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 100,
                },
                {
                    title: '开始日期',
                    key: 'startDate',
                    width: 150,
                },
                {
                    title: '结束日期',
                    key: 'endDate',
                    width: 150,
                },
                {
                    title: '佣金比例',
                    key: 'yjRate',
                    width: 100,
                },
            ],
            dataTemplateFour: [
                {
                    gdAccounts: 'A000832200',
                    zqCode: 'ALL',
                    startDate: '20100115',
                    endDate: '20110423',
                    yjRate: 0.002,
                },
                {
                    gdAccounts: 'A530916975',
                    zqCode: 'ALL',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
                {
                    gdAccounts: 'A684165286',
                    zqCode: '600081',
                    startDate: '20091221',
                    endDate: '20170607',
                    yjRate: 0.00025,
                },
            ],
            columnsLookInfoFour: [
                {
                    title: '是否有效',
                    key: 'isEffective',
                    width: 100,
                },
                {
                    title: '股东账户',
                    key: 'gdAccounts',
                    width: 150,
                },
                {
                    title: '证券代码',
                    key: 'zqCode',
                    width: 100,
                },
                {
                    title: '开始日期',
                    key: 'startDate',
                    width: 150,
                },
                {
                    title: '结束日期',
                    key: 'endDate',
                    width: 150,
                },
                {
                    title: '佣金比例',
                    key: 'yjRate',
                    width: 100,
                },
                {
                    title: '说明',
                    key: 'explainInfo',
                    width: 100,
                }
            ],
            dataLookInfoFour: [
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
                {
                    isEffective: '是',
                    gdAccounts: 'A111111111',
                    zqCode: '601390',
                    startDate: '2015-04-01',
                    endDate: '2015-04-30',
                    yjRate: 0.003,
                    explainInfo: '',
                },
            ],

            lookUploadInfo: false,
            templateInfo: false,

            ishide: true,

            modalOne: false,
            modalTwo: false,
            modalThree: false,
            modalFour: false,
            items: 0,


            table: 'tableOneXls',

            modal7: false,
            modal8: false,

            defaultList: [],
            imgName: '',
            single: '先进先出',
            visible: false,
            uploadList: [],
            inputTwo: 20,
            inputThree: 20,
            inputFour: 20,



            formValidateOne: {
                inputOne: 20,
                inputNumberOne: 0.3,
                modalOneFirst: false,
                modalOneSecond: false,

            },
            ruleValidateOne: {

            },
            formValidateTwo: {
                inputTwo: 20,
                inputNumberTwo: 0.3,
                modalTwoFirst: false,
                modalTwoSecond: false,
                singleTwo: '先进先出',

            },
            ruleValidateTwo: {

            },
            formValidateThree: {
                inputThree: 20,

                modalThreeFirst: false,
                modalThreeSecond: false,
                modalThreeThird: false,
                modalThreeForth: false,
                singleThree: '先进先出',

            },
            ruleValidateThree: {

            },
            formValidateFour: {
                inputFour: 20,

                modalFourFirst: false,
                modalFourSecond: false,


            },
            ruleValidateFour: {

            },
            columns1: [
                {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '成交时间',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '成交编号',
                    key: '',
                    width: 90,
                },
                {
                    title: '成交价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '成交金额',
                    key: '',
                    width: 110,
                    sortable:true
                },

                {
                    title: '席位',
                    key: '',
                    width: 60,
                },
                {
                    title: '申报编码',
                    key: '',
                    width: 90,
                },
                {
                    title: '申报时间',
                    key: '',
                    width: 90,
                },
                {
                    title: '成交方向',
                    key: '',
                    width: 90,
                },
                {
                    title: '印花税',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '过户费',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '交易佣金估算',
                    key: '',
                    width: 150,
                    sortable:true
                },
                {
                    title: '实际交易佣金',
                    key: '',
                    width: 150,
                    sortable:true
                },
            ],
            columns2: [
                {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '买方成交编号',
                    key: 'date',
                    width: 110,
                },
                {
                    title: '买入价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入金额',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入量',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '买方印花税',
                    key: '',
                    width: 120,
                    sortable:true
                },
                {
                    title: '买方过户费',
                    key: '',
                    width: 120,
                    sortable:true
                },
                {
                    title: '买方交易佣金估算',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '买方交易实际佣金',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: '',
                    width: 250,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方印花税',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方过户费',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 230,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 220,
                    sortable:true
                },
            ],
            columnsTwoFirst: [
                 {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '买方成交编号',
                    key: 'date',
                    width: 110,
                },
                {
                    title: '买入价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入金额',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入量',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '买方印花税',
                    key: '',
                    width: 120,
                    sortable:true
                },
                {
                    title: '买方过户费',
                    key: '',
                    width: 120,
                    sortable:true
                },
                {
                    title: '买方交易佣金估算',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '买方交易实际佣金',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: '',
                    width: 250,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方印花税',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方过户费',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 230,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 220,
                    sortable:true
                },
            ],
            columnsTwoSecond: [
                {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '卖方成交编号',
                    key: 'date',
                    width: 110,
                },
                {
                    title: '卖入价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '卖入金额',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '卖入量',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '卖方印花税',
                    key: '',
                    width: 120,
                    sortable:true
                },
                {
                    title: '卖方过户费',
                    key: '',
                    width: 120,
                    sortable:true
                },
                {
                    title: '卖方交易佣金估算',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '卖方交易实际佣金',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方印花税',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方过户费',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: '',
                    width: 230,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: '',
                    width: 220,
                    sortable:true
                },
            ],
            columns3: [
                {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,

                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '买方成交编号',
                    key: 'date',
                    width: 120,
                },
                {
                    title: '买入价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入金额',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入量',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '买方印花税',
                    key: '',
                    width: 140,
                    sortable:true
                },
                {
                    title: '买方过户费',
                    key: '',
                    width: 140,
                    sortable:true
                },
                {
                    title: '买方交易佣金估算',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '买方交易实际佣金',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方印花税',
                    key: '',
                    width: 230,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方过户费',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 250,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 250,
                    sortable:true
                },
            ],
            columnsThreeFirst: [
                {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,

                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '买方成交编号',
                    key: 'date',
                    width: 120,
                },
                {
                    title: '买入价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入金额',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '买入量',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {
                    title: '买方印花税',
                    key: '',
                    width: 140,
                    sortable:true
                },
                {
                    title: '买方过户费',
                    key: '',
                    width: 140,
                    sortable:true
                },
                {
                    title: '买方交易佣金估算',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '买方交易实际佣金',
                    key: '',
                    width: 200,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方印花税',
                    key: '',
                    width: 230,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方过户费',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 250,
                    sortable:true
                },
                {
                    title: '对应该笔成交卖方交易佣金估算',
                    key: '',
                    width: 250,
                    sortable:true
                },
            ],
            columnsThreeSecond: [
                {
                    title: '账户代码',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '证卷代码',
                    key: 'date',
                    width: 90,

                },
                {
                    title: '交易日期',
                    key: 'date',
                    width: 90,
                },
                {
                    title: '卖方成交编号',
                    key: 'date',
                    width: 120,
                },
                {
                    title: '卖入价格',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '卖入金额',
                    key: '',
                    width: 110,
                    sortable:true
                },
                {
                    title: '卖入量',
                    key: '',
                    width: 100,
                    sortable:true
                },
                {

                    title: '卖方印花税',
                    key: '',
                    width: 140,
                    sortable:true
                },
                {
                    title: '卖方过户费',
                    key: '',
                    width: 140,
                    sortable:true
                },
                {
                    title: '卖方交易佣金估算',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '卖方交易实际佣金',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出价格',
                    key: '',
                    width: 250,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出金额',
                    key: '',
                    width: 180,
                    sortable:true
                },
                {
                    title: '对应该笔成交的卖出',
                    key: '',
                    width: 180,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方印花税',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方过户费',
                    key: '',
                    width: 220,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: '',
                    width: 230,
                    sortable:true
                },
                {
                    title: '对应该笔成交买方交易佣金估算',
                    key: '',
                    width: 230,
                    sortable:true
                },
            ],
            columns4: [
                {
                    title: '证卷代码',
                    width: 160,
                },
                {
                    key: '',
                    title: '股权登记日',
                    width: 180,
                },
                {
                    title: '上市流通日',
                    key: '',
                    width: 180,
                },
                {
                    title: '送配比例（10送）',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '配股比例（10配）',
                    key: '',
                    width: 160,
                    sortable:true
                },
                {
                    title: '配股价格',
                    key: '',
                    width: 160,
                    sortable:true
                },
            ],
            data1: [],
            data2: [],
            data3: [],
            data4: [],
        }

    },
    mounted() {
        // this.uploadList = this.$refs.upload.fileList;

    },
    methods: {
        handleSubmitOne(name) {
            this.$refs[name].validate((valid) => {
                console.log(1)
                if (valid) {
                    this.$Message.success('提交成功!');
                    this.ishide = false;
                    this.searchOne();
                } else {
                    this.$Message.error('表单验证失败!');
                }
            })
        },
        handleSubmitTwo(name) {
            this.$refs[name].validate((valid) => {
                console.log(1)
                if (valid) {
                    this.$Message.success('提交成功!');
                    this.ishide = false;
                    this.searchTwo();
                } else {
                    this.$Message.error('表单验证失败!');
                }
            })
        },
        handleSubmitThree(name) {
            this.$refs[name].validate((valid) => {
                console.log(1)
                if (valid) {
                    this.$Message.success('提交成功!');
                    this.ishide = false;
                    this.searchThree();
                } else {
                    this.$Message.error('表单验证失败!');
                }
            })
        },
        handleSubmitFour(name) {
            this.$refs[name].validate((valid) => {
                console.log(1)
                if (valid) {
                    this.$Message.success('提交成功!');
                    this.ishide = false;
                    this.searchFour();
                } else {
                    this.$Message.error('表单验证失败!');
                }
            })
        },


        handleView(name) {
            this.imgName = name;
            this.visible = true;
        },
        handleFormatError(file) {
            this.$Notice.warning({
                title: '文件格式不正确',
                desc: '文件 ' + file.name + ' 格式不正确，请上传 xls 格式的表格。'
            });
        },
        handleMaxSize(file) {
            this.$Notice.warning({
                title: '超出文件大小限制',
                desc: '文件 ' + file.name + ' 太大，不能超过 2M。'
            });
        },
        handleBeforeUpload() {
            const check = this.uploadList.length < 5;
            if (!check) {
                this.$Notice.warning({
                    title: '最多只能上传 5 个表格。'
                });
            }
            return check;
        },
        searchOne: function () {
            var calExportBtnOne = document.getElementById("calExportBtnOne");

            //jsonOne数据
            var arrayOne = {}
            var inputNumberOne = this.formValidateOne.inputNumberOne
            var inputOne = this.formValidateOne.inputOne
            arrayOne.inputNumberOne = this.formValidateOne.inputNumberOne
            arrayOne.inputOne = this.formValidateOne.inputOne
            var jsonOne = JSON.stringify(arrayOne)
            console.log(jsonOne)


            //获取数据 并传递数据
            const url = 'http://api.iia.cbpass.net/GetFillData3';
            fetch(url, {
                method: "POST",
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                return response.json()
            }, function (error) {
                console.log(error)
            }).then(data => {
                calExportBtnOne.removeAttribute("disabled");


                var dataResponse = data.Data.Sets1;
                const table = this.table
                var tableValue = table
                var dataArray = [];
                for (var i = 0; i < dataResponse.length; i++) {
                    var dataRow = {};
                    for (var key in dataResponse[i]) {
                        dataRow[key] = dataResponse[i][key];
                    }
                    dataArray.push(dataRow);
                }
                this.data1 = dataArray;


                console.log(dataArray.length)
                if (dataArray.length > 0) {
                    this.ishide = true;
                }
            })
        },
        searchTwo: function () {
            var calExportBtnTwoFirst = document.getElementById("calExportBtnTwoFirst");
            var calExportBtnTwoSecond = document.getElementById("calExportBtnTwoSecond");

            //jsonTwo数据
            var arrayTwo = {}
            var singleTwo = this.formValidateTwo.singleTwo
            var inputTwo = this.formValidateTwo.inputTwo
            arrayTwo.singleTwo = this.formValidateTwo.singleTwo
            arrayTwo.inputTwo = this.formValidateTwo.inputTwo
            var jsonTwo = JSON.stringify(arrayTwo)
            console.log(jsonTwo)


            //获取数据 并传递数据
            const url = 'http://api.iia.cbpass.net/GetFillData3';
            fetch(url, {
                method: "POST",
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                return response.json()
            }, function (error) {
                console.log(error)
            }).then(data => {

                calExportBtnTwoFirst.removeAttribute("disabled");
                calExportBtnTwoSecond.removeAttribute("disabled");


                var dataResponse = data.Data.Sets1;
                const table = this.table
                var tableValue = table
                var dataArray = [];
                for (var i = 0; i < dataResponse.length; i++) {
                    var dataRow = {};
                    for (var key in dataResponse[i]) {
                        dataRow[key] = dataResponse[i][key];
                    }
                    dataArray.push(dataRow);
                }

                this.data2 = dataArray;


                console.log(dataArray.length)
                if (dataArray.length > 0) {
                    this.ishide = true;
                }
            })
        },
        searchThree: function () {
            var calExportBtnThreeFirst = document.getElementById("calExportBtnThreeFirst");
            var calExportBtnThreeSecond = document.getElementById("calExportBtnThreeSecond");


            //jsonTHree数据
            var arrayThree = {}
            var singleThree = this.formValidateThree.singleThree
            var inputThree = this.formValidateThree.inputThree
            arrayThree.singleThree = this.formValidateThree.singleThree
            arrayThree.inputThree = this.formValidateThree.inputThree
            var jsonThree = JSON.stringify(arrayThree)
            console.log(jsonThree)


            //获取数据 并传递数据
            const url = 'http://api.iia.cbpass.net/GetFillData3';
            fetch(url, {
                method: "POST",
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                return response.json()
            }, function (error) {
                console.log(error)
            }).then(data => {

                calExportBtnThreeFirst.removeAttribute("disabled");
                calExportBtnThreeSecond.removeAttribute("disabled");
                this.columns = this.columns4

                var dataResponse = data.Data.Sets1;
                const table = this.table
                var tableValue = table
                var dataArray = [];
                for (var i = 0; i < dataResponse.length; i++) {
                    var dataRow = {};
                    for (var key in dataResponse[i]) {
                        dataRow[key] = dataResponse[i][key];
                    }
                    dataArray.push(dataRow);
                }

                this.data3 = dataArray;


                console.log(dataArray.length)
                if (dataArray.length > 0) {
                    this.ishide = true;
                }
             

            })
        },

        searchFour: function () {
            var calExportBtnFour = document.getElementById("calExportBtnFour");


            //jsonFour数据
            var arrayFour = {}
            var inputFour = this.formValidateFour.inputFour
            arrayFour.inputFour = this.formValidateFour.inputFour
            var jsonFour = JSON.stringify(arrayFour)
            console.log(jsonFour)

            //获取数据 并传递数据
            const url = 'http://api.iia.cbpass.net/GetFillData3';
            fetch(url, {
                method: "POST",
                mode: 'cors',
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                return response.json()
            }, function (error) {
                console.log(error)
            }).then(data => {

                calExportBtnFour.removeAttribute("disabled");

                var dataResponse = data.Data.Sets1;
                const table = this.table
                var tableValue = table
                var dataArray = [];
                for (var i = 0; i < dataResponse.length; i++) {
                    var dataRow = {};
                    for (var key in dataResponse[i]) {
                        dataRow[key] = dataResponse[i][key];
                    }
                    dataArray.push(dataRow);
                }

                this.data4 = dataArray;

                console.log(dataArray.length)
                if (dataArray.length > 0) {
                    this.ishide = true;
                }
            })
        },
        radiochangeTwo :function(){
            if(this.formValidateTwo.singleTwo == '先进先出'){
                console.log(1)
                
                this.columns2 =  this.columnsTwoFirst
            }
            if(this.formValidateTwo.singleTwo == '后进后出'){
                console.log(2)
                
                this.columns2 = this.columnsTwoSecond
                 
            }
        },
        
        radiochangeThree :function() {
            if(this.formValidateThree.singleThree == '先进先出'){
                console.log(1)
                this.columns3 = this.columnsThreeFirst
            }
            if(this.formValidateThree.singleThree == '后进后出'){
                console.log(2)
                this.columns3 = this.columnsThreeSecond
            }
        },

        // 导出xls表格
        exportTable: function () {
            this.$refs.tableOneExport.exportCsv({
                filename: '输出成交明细和费用',
            })
            this.$refs.tableTwoExport.exportCsv({
                filename: '输出买卖记录对应数据表'
            })
            this.$refs.tableThreeExport.exportCsv({
                filename: '输出盈利统计表'
            })
            this.$refs.tableFourExport.exportCsv({
                filename: '输出高送转明细'
            })
        },
    }


}
</script>


