<template>
    <section class="constWidth">
       <!--头部logo-->
       <header></header>
       <!--标题框折叠面板-->
       <Collapse id="dealPanel" class="dealPanel" v-model="searchPanel" v-on:on-change="panelChange">
        <Panel name="1">
            账户证券交易情况查询
            <!--查询框-->
            <div slot="content" id="searchAccountBox" class="searchAccountBox">
                    <router-link to="/showInfo2">
                        <span class="lookInfo">查看统计口径</span>
                    </router-link>
                    <Form class="dealForm" ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                        <Row class="dateBox">
                            <Col span="12">
                                <b>开始日期</b>
                                <Form-item prop="startdate" id="startDateForm">
                                    <Date-picker id="startDate" type="date" :options="options3" placeholder="选择开始日期" v-model="formValidate.startdate" style="width: 360px"></Date-picker>
                                </Form-item>
                            </Col>
                            <Col span="12">
                                <b>结束日期</b>
                                <Form-item prop="enddate" id="endDateForm">
                                    <Date-picker id="endDate" type="date" :options="options4" placeholder="选择结束日期" v-model="formValidate.enddate" style="width: 360px"></Date-picker>
                                </Form-item>
                            </Col>                    
                        </Row>

                        <Row>
                            <Col span="12">
                                <Row class="uploadBox uploadLeft">
                                    <b>股东账号</b>
                                    <Upload action="/base-service/api/decode_upfile?uploadType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount">
                                        <Button id="importAccountBtn" type="ghost">导入</Button>
                                    </Upload>
                                    <Button id="clearAccountBtn" v-on:click="clearOne()">清空</Button>
                                    <span class="leftp">已导入&nbsp;<font id="dealUploadAccount" class="redtext">{{accountList}}</font>&nbsp;条</span>
                                    <label class="redtext fontsize12">（不超过2500个）</label>
                                </Row>
                                <Form-item prop="desc" class="inputAccount" id="AccountForm">
                                    <Input  id="AccountInput" v-model="formValidate.desc" @on-change="accountListChange" type="textarea" :rows="6" placeholder="请输入股东账号" style="width:360px;"></Input>
                                </Form-item>
                                <Form-item class="showrow" prop="showrow">
                                    在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行&nbsp;&nbsp;<label class="redtext fontsize12">(最多显示200行)</label>
                                </Form-item>

                            </Col>
                            <Col span="12">
                                <Row class="rightRadioBox">
                                    <b>统计对象</b>
                                    <Radio-group v-model="formValidate.cxtype" class="dealradio" v-on:on-change="showzq">
                                        <Radio id="codeRadio" label="按证券代码"></Radio>
                                        <Radio  id="typeRadio" label="按证券大类"></Radio>
                                        <Radio  id="allRadio" label="按所有证券"></Radio>
                                    </Radio-group>  
                                </Row>
                                <div id="zqcode" style="margin-left:68px;margin-top:16px;">
                                    <Row class="uploadBox zqdmUpload">
                                        <Upload action="/base-service/api/decode_upfile?uploadType=SECCODE" :headers="upfileParams" accept=".txt" :on-success="handleSuccessCode">
                                            <Button id="importcodeBtn" type="ghost">导入</Button>
                                        </Upload>
                                        <Button id="clearcodeBtn" v-on:click="clearTwo()">清空</Button>
                                        <span class="rightp">已导入&nbsp;<font id="dealUploadCode" class="redtext">{{codeList}}</font>&nbsp;条</span>
                                        <label class="redtext fontsize12">（不超过1000个）</label>
                                    </Row>
                                    <Input id="codeInput" v-model="formValidate.zqdmRows" @on-change="codeListChange" type="textarea" :rows="4" placeholder="请输入证券代码"  style="width:360px;"></Input>
                                </div>         
                                <div id="zqseries" class="hide" style="margin-left:68px;">
                                    <Checkbox-group v-model="formValidate.seriesList" class="dealCheckbox" @on-change="checkAllGroupChangeBond2">
                                        <Checkbox id="zqcheckbox" label="债券"></Checkbox>
                                        <Checkbox id="jjcheckbox" label="基金"></Checkbox>
                                        <Checkbox id="gpcheckbox" label="股票"></Checkbox>
                                        <p class="redtext">{{bondTypeTip}}</p>
                                    </Checkbox-group>
                                </div>

                            </Col>
                        </Row>
                        <Form-item>
                            <div class="cxBox"><Button class="searchDealBtn" id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查&nbsp;&nbsp;询</Button></div>
                        </Form-item>               
                    </Form>
            </div>
        </Panel>
    </Collapse>

       <!--初始无数据提示图片-->
       <div id="sorryBox" class="sorryBox">
           <img src="../assets/img/sorry.png"  />
           <h3>还没有查询内容哦！</h3>
       </div>

       <!--维度运算和数据表格-->
       <div id="resultBox" class="hide">
            <!--维度运算-->
            <div class="wdcalBox">
                <Row>
                    <Col span="9">
                        <Card class="wdBox">
                            <p slot="title"><b class="redtext">*</b>&nbsp;维度</p>
                            <Form ref="formValidate2" :model="formValidate2" :rules="ruleValidate2">
                                <Form-item prop="wdCheck">
                                    <Checkbox-group v-model="formValidate2.wdCheck" @on-change="wdChange">
                                    <Checkbox id="wdCheck1" label="股东账户"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck2" label="股东名称"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck3" label="交易日期"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck4" label="会员营业部"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck5" label="会员"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck6" label="PBU"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck7" label="证券代码"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck8" label="证券简称"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck9" label="该证券当日总成交量（维度）"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck10" label="该证券当日总成交额（维度）"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck11" label="成交编号"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck12" label="订单编号"></Checkbox>
                                    <br>
                                    <Checkbox id="wdCheck13" label="成交时间"></Checkbox>
                                    <br>
                                </Checkbox-group>
                                </Form-item>
                            </Form>
                            
                        </Card>
                    </Col>
                    <Col span="9">
                        <Card class="dlBox">
                            <p slot="title">度量</p>
                            <div style="border-bottom: 1px solid #e9e9e9;padding-bottom:10px;margin-bottom:10px;">
                                <Checkbox id="dlCheckAll" :indeterminate="indeterminate" :value="checkAll" @click.prevent.native="handleCheckAll">全选</Checkbox>
                            </div>
                            <Checkbox-group v-model="checkAllGroup" @on-change="checkAllGroupChange">
                                <Checkbox id="dlCheck1" label="买成交数量（合计）"></Checkbox><br>
                                <Checkbox id="dlbuyVolumeRatio" label="买成交数量占比"></Checkbox><br>
                                <Checkbox id="dlCheck2" label="买成交金额（合计）"></Checkbox><br>
                                <Checkbox id="dlCheck3" label="卖成交数量（合计）"></Checkbox><br>
                                <Checkbox id="dlsellVolumeRatio" label="卖成交数量占比"></Checkbox><br>
                                <Checkbox id="dlCheck4" label="卖成交金额（合计）"></Checkbox><br>
                                <Checkbox id="dlCheck5" label="买成交数量（大宗）"></Checkbox><br>
                                <Checkbox id="dlCheck6" label="买成交金额（大宗）"></Checkbox><br>
                                <Checkbox id="dlCheck7" label="卖成交数量（大宗）"></Checkbox><br>
                                <Checkbox id="dlCheck8" label="卖成交金额（大宗）"></Checkbox><br>
                            </Checkbox-group>
                        </Card>
                    </Col>
                    <Col span="6">
                        <Card>
                            <p slot="title">操作</p>
                            显示行数&nbsp;&nbsp;<Input-number  id="wdCalRows" :max="wdMax" :min="1" v-model="czrows" style="width: 80px"></Input-number>
                            <br><br>
                            <label class="redtext fontsize12">（最多显示200行 , 维度运算行数不能超过查询限制行数 ！）</label>
                        </Card>
                    </Col>
                </Row>

                <Row class="calbtnBox">
                    <Button class="wdcalBtn" id="wdCalBtn" type="primary" @click="handleSubmit2('formValidate2')">维度运算</Button>
                </Row>

            </div>

            <!--数据表格-->
            <div class="dataTable">
                <p id="dealTableList" class="redtext listlength">查询完毕&nbsp;!&nbsp;运算结果总记录数为:&nbsp;{{dealitems}}&nbsp;行&nbsp;,&nbsp;显示记录数为: 前&nbsp;{{showdealitems}}&nbsp;行</p>
                <Spin id="loadBox" fix class="loadBox hide">
                    <Icon type="load-c" size=40 class="loadIcon"></Icon>
                    <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                </Spin>
                <Table id="dealTable" border :columns="dealTable" :data="dealTableData" size="small" ref="table"></Table>
                <br>
                <div class="dealExport">
                    <Button id="exportCurrent" type="primary" size="large" @click="exportData(1)" disabled><Icon type="ios-download-outline"></Icon> 导出当前表格数据（csv格式）</Button>
                    <Button id="exportListCsv" type="primary" size="large" @click="exportData(2)" disabled><Icon type="ios-download-outline"></Icon> 导出逐笔明细数据（csv格式）</Button>
                    <Button id="exportListExcel" type="primary" size="large" @click="exportData(3)" disabled><Icon type="ios-download-outline"></Icon> 导出逐笔明细数据（Excel格式）</Button>
                    <Button id="exportListDbf" type="primary" size="large" @click="exportData(4)" disabled><Icon type="ios-download-outline"></Icon> 导出逐笔明细数据（DBF格式）</Button>
                </div>       

            </div>

       </div>

    </section>
</template>
<script>
import 'whatwg-fetch';

//获取URL地址参数
var urlParams=window.location.href;
var upfileParamsValue={};
upfileParamsValue.signature=getUrlParams(urlParams).signature;

//导出参数
var downfileParams="&signature="+getUrlParams(urlParams).signature+"&userId="+getUrlParams(urlParams).userId+"&userName="+getUrlParams(urlParams).userName;

function getUrlParams(url){
    var urlArray=url.split("?")[1].split("&"),
    urlValue={};
    for(var i=0;i<urlArray.length;i++){
        var urlRowArray=urlArray[i].split("=");
        urlValue[urlRowArray[0]]=urlRowArray[1];
    }
    return urlValue;
}

//维度运算表格数据
var wdTableData;

    //日期初始值
    let lastTradeDate="";
    //查询参数初始化
    let searchParams={};

    //格式化日期
    Date.prototype.format = function(format) {
       var date = {
              "M+": this.getMonth() + 1,
              "d+": this.getDate(),
              "h+": this.getHours(),
              "m+": this.getMinutes(),
              "s+": this.getSeconds(),
              "q+": Math.floor((this.getMonth() + 3) / 3),
              "S+": this.getMilliseconds()
       };
       if (/(y+)/i.test(format)) {
              format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
       }
       for (var k in date) {
              if (new RegExp("(" + k + ")").test(format)) {
                     format = format.replace(RegExp.$1, RegExp.$1.length == 1
                            ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
              }
       }
       return format;
    }

    //维度运算所有表头	
    var dataThead = {"股东账户": "acctId", "股东名称": "acctName", "交易日期": "tradeDate", "会员营业部": "memBranchName",
                "证券代码": "secCode","证券简称": "secName", "买成交数量（合计）" : "buyVol", 
                "买成交数量占比": "buyRatio", "买成交金额（合计）": "buyAmt","买成交价格（合计）":"buyPrice",
                "卖成交数量（合计）": "sellVol","卖成交数量占比": "sellRatio","卖成交金额（合计）": "sellAmt",
                "卖成交价格（合计）":  "sellPrice","买成交数量（大宗）":"buyVolBt","买成交金额（大宗）":"buyAmtBt",
                "卖成交数量（大宗）":"sellVolBt","卖成交金额（大宗）":"sellAmtBt","会员":"memName","PBU":"pbuId",
                "成交编号":"tradeNo","订单编号":"orderNo","成交时间":"tradeTime","该证券当日总成交量（维度）":"secTradeVolDmn",
                "该证券当日总成交额（维度）":"secTradeAmtDmn"};

    export default {
        data () {
            return {
                wdMax:20,
                //文件解析参数
                upfileParams:upfileParamsValue,
				//上传股东账户条数
				accountList: 0,
				//证券代码已上传条数
				codeList: 0,
                //开始日期
                options3: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                //结束日期 
                options4: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                bondTypeTip:'',
                formValidate2: {
                    wdCheck: ['股东账户','股东名称','交易日期','会员营业部','证券代码','证券简称'],
                },
                ruleValidate2: {
                    wdCheck: [
                        { required: true, type: 'array', min: 1, message: '至少选择一个维度', trigger: 'change' },
                    ],
                },
                dealitems:0,
                showdealitems:0,
                dealTable: [		
                    {
                        "title": "股东账户",
                        "key": "acctId",
                        "fixed": "left",
                        "width": 200
                    },
                    {
                        "title": "股东名称",
                        "key": "acctName",
                        "width": 150,
                    },
                    {
                        "title": "交易日期",
                        "key": "tradeDate",
                        "width": 150,
                    },
                    {
                        "title": "会员营业部",
                        "key": "memBranchName",
                        "width": 150,
                    },
                    {
                        "title": "证券代码",
                        "key": "secCode",
                        "width": 150,
                    },
                    {
                        "title": "证券简称",
                        "key": "secName",
                        "width": 150,
                    },
                    {
                        "title": "买成交数量（合计）",
                        "key": "buyVol",
                        "width": 150,
                    },
                    {
                        "title": "买成交数量占比",
                        "key": "buyRatio",
                        "width": 150,
                    },
                    {
                        "title": "买成交金额（合计）",
                        "key": "buyAmt",
                        "width": 150,
                    },
                    {
                        "title": "买成交价格（合计）",
                        "key": "buyPrice",
                        "width": 150,
                    },
                    {
                        "title": "卖成交数量（合计）",
                        "key": "sellVol",
                        "width": 150,
                    },
                    {
                        "title": "卖成交数量占比",
                        "key": "sellRatio",
                        "width": 150,
                    },
                    {
                        "title": "卖成交金额（合计）",
                        "key": "sellAmt",
                        "width": 150,
                    } ,
                    {
                        "title": "卖成交价格（合计）",
                        "key": "sellPrice",
                        "width": 150,
                    }
                ],
                dealTableData: [],
                fenmuList: [
                    {
                        value: 'fenzi1',
                        label: '买成交数量（合计）'
                    },
                    {
                        value: 'fenzi2',
                        label: '买成交数量占比'
                    },
                    {
                        value: 'fenzi3',
                        label: '买成交金额（合计）'
                    },
                    {
                        value: 'fenzi4',
                        label: '卖成交数量（合计）'
                    },
                    {
                        value: 'fenzi5',
                        label: '卖成交数量占比'
                    },
                    {
                        value: 'fenzi6',
                        label: '卖成交金额（合计）'
                    },
                    {
                        value: 'fenzi7',
                        label: '买成交数量（大宗）'
                    },
                    {
                        value: 'fenzi8',
                        label: '买成交金额（大宗）'
                    },
                    {
                        value: 'fenzi9',
                        label: '卖成交数量（大宗）'
                    },
                    {
                        value: 'fenzi10',
                        label: '卖成交金额（大宗）'
                    }
                ],
                blfenmu: '',
                fenziList: [
                    {
                        value: 'fenzi1',
                        label: '买成交数量（合计）'
                    },
                    {
                        value: 'fenzi2',
                        label: '买成交数量占比'
                    },
                    {
                        value: 'fenzi3',
                        label: '买成交金额（合计）'
                    },
                    {
                        value: 'fenzi4',
                        label: '卖成交数量（合计）'
                    },
                    {
                        value: 'fenzi5',
                        label: '卖成交数量占比'
                    },
                    {
                        value: 'fenzi6',
                        label: '卖成交金额（合计）'
                    },
                    {
                        value: 'fenzi7',
                        label: '买成交数量（大宗）'
                    },
                    {
                        value: 'fenzi8',
                        label: '买成交金额（大宗）'
                    },
                    {
                        value: 'fenzi9',
                        label: '卖成交数量（大宗）'
                    },
                    {
                        value: 'fenzi10',
                        label: '卖成交金额（大宗）'
                    }
                ],
                blfenzi: '',
                blName:'比率名称',
                indeterminate3: false,
                checkAll3: false,
                checkAllGroup3: [],
                indeterminate2: false,
                checkAll2: false,
                checkAllGroup2: [],
                indeterminate: false,
                checkAll: false,
                checkAllGroup: ['买成交数量（合计）', '买成交数量占比','买成交金额（合计）','卖成交数量（合计）','卖成交数量占比','卖成交金额（合计）'],
                sumCheck:[],
                czrows:20,
                lookysdl: false,
                searchPanel: '1',
                arrow:"︿",
                dmNumber:0,
                showLength:1000,
                uploadgdzh: '',
                self: this,
                formValidate: {
                    startdate: new Date(this.initialDate()),
                    enddate: new Date(this.initialDate()),
                    desc: '',
                    cxtype: '按证券代码',
                    seriesList: ['债券','基金','股票'],
                    zqdmRows:"",
                    showrow:20,
                },
                ruleValidate: {
                    showrow: [
                        { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                    ],
                    startdate: [
                        { required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }
                    ],
                    enddate: [
                        { required: true, type: 'date', message: '请选择结束日期', trigger: 'change' }
                    ],
                    desc: [
                        { required: true, message: '请输入股东账号', trigger: 'blur' },
                    ]
                },

            }
        },
        methods: {
            //设置fetch请求超时方法
             _fetch:function(fetch_promise, timeout) {
                var abort_fn = null;
                var abortInfo=this;
                //这是一个可以被reject的promise
                var abort_promise = new Promise(function(resolve, reject) {
                        abort_fn = function() {
                            console.log('查询超时abort promise');
                            // abortInfo.$Message.warning('查询超时！请重试！');
                        };
                });
                //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
                var abortable_promise = Promise.race([
                        fetch_promise,
                        abort_promise
                ]);
                setTimeout(function() {
                        abort_fn();
                    }, timeout);
                return abortable_promise;
            }, 
			//股东账户已上传条数
			accountListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				let arrNew = [];
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.accountList = arr.length;
			},
			//证券代码已上传条数
			codeListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.codeList = arr.length;
			},
            //请求初始日期
            initialDate:function(){
                var obj=new XMLHttpRequest();
                obj.open('GET','/base-service/api/predate',false);
                obj.setRequestHeader("signature",getUrlParams(urlParams).signature);
                obj.onreadystatechange=function(){
                    if(obj.readyState == 4 && obj.status == 200){
                        const responseData=JSON.parse(obj.responseText);
                        //上一个交易日
                        lastTradeDate = responseData.resData.lastTradeDate;
                        lastTradeDate = lastTradeDate.slice(0,4)+"-"+lastTradeDate.slice(4,6)+"-"+lastTradeDate.slice(6,8);
						lastTradeDate = new Date(lastTradeDate);
			
                    }
                };
                obj.send(null);
                return lastTradeDate;
            },
            hasClass:function(obj, cls){  
                return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
            },
            addClass:function(obj, cls){  
                if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
            },
            removeClass:function(obj, cls){  
                if (this.hasClass(obj, cls)) {  
                    var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                    obj.className = obj.className.replace(reg, ' ');  
                }  
            },
            toggleClass:function(obj,cls){  
                if(this.hasClass(obj,cls)){  
                    this.removeClass(obj, cls);  
                }else{  
                    this.addClass(obj, cls);  
                }  
            },
            wdChange:function(){
                //判断是否禁用成交数量占比
                let wdCheck=this.formValidate2.wdCheck;
                var checkparent1=document.getElementById("dlbuyVolumeRatio"),
                    checkparent2=document.getElementById("dlsellVolumeRatio"),
                    check1=document.getElementById("dlbuyVolumeRatio").getElementsByTagName("input")[0],
                    check2=document.getElementById("dlsellVolumeRatio").getElementsByTagName("input")[0];
                if(!(wdCheck.indexOf("交易日期")>=0&&(wdCheck.indexOf("证券代码")>=0||wdCheck.indexOf("证券简称")>=0))){
                    check1.setAttribute("disabled",true);
                    check2.setAttribute("disabled",true);
                    this.addClass(checkparent1,"ivu-checkbox-wrapper-disabled");
                    this.addClass(checkparent2,"ivu-checkbox-wrapper-disabled");
                }else{
                    check1.removeAttribute("disabled");
                    check2.removeAttribute("disabled");
                    this.removeClass(checkparent1,"ivu-checkbox-wrapper-disabled");
                    this.removeClass(checkparent2,"ivu-checkbox-wrapper-disabled");
                }
            },
            handleSubmit2 (name) {
                this.$refs[name].validate((valid) => {
                    if (valid) {
                        this.$Message.success('提交成功!请等待~');
                        this.dimensionCal();
                    } else {
                        this.$Message.error('至少选择一个维度!');
                    }
                })
            },
            exportData (type) {
                if (type === 1) {
                    this.$refs.table.exportCsv({
                        filename: '账户证券交易情况当前表格数据'
                    });
                } else if (type === 2) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ACCT&fileType=csv'+downfileParams;                    
                } else if (type === 3) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ACCT&fileType=xlsx'+downfileParams;
                } else if (type === 4) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=ACCT&fileType=dbf'+downfileParams;
                }
            },
            dimensionCal:function(){
                //提示维度运算中
                this.$Message.info("维度运算中",8);
                var wdcalArray=this.formValidate2.wdCheck.concat(this.checkAllGroup);
                //判断是否显示成交价格
                if(wdcalArray.indexOf("买成交数量（合计）")>=0&&wdcalArray.indexOf("买成交金额（合计）")>=0){
                    var index=wdcalArray.indexOf("买成交金额（合计）");
                    wdcalArray.splice(index+1, 0, "买成交价格（合计）");
                }
                if(wdcalArray.indexOf("卖成交数量（合计）")>=0&&wdcalArray.indexOf("卖成交金额（合计）")>=0){
                    var index=wdcalArray.indexOf("卖成交金额（合计）");
                    wdcalArray.splice(index+1, 0, "卖成交价格（合计）");
                }
                this.dealTable=[];

				for(var i=0;i<wdcalArray.length;i++){
				    var title = {};
					title.title = wdcalArray[i];
					title.key = dataThead[wdcalArray[i]];
					title.width = 150;
                    this.dealTable.push(title);
                }

                this.dealTableData = wdTableData.slice(0,this.czrows);
				this.showdealitems = this.dealTableData.length;

            },
            handleCheckAll () {
                if (this.indeterminate) {
                    this.checkAll = false;
                } else {
                    this.checkAll = !this.checkAll;
                }
                this.indeterminate = false;

                if (this.checkAll) {
                    this.checkAllGroup = ['买成交数量（合计）', '买成交数量占比', '买成交金额（合计）','卖成交数量（合计）','卖成交数量占比','卖成交金额（合计）','买成交数量（大宗）','买成交金额（大宗）','卖成交数量（大宗）','卖成交金额（大宗）'];
                } else {
                    this.checkAllGroup = [];
                }
            },
            checkAllGroupChange (data) {
                if (data.length === 10) {
                    this.indeterminate = false;
                    this.checkAll = true;
                } else if (data.length > 0) {
                    this.indeterminate = true;
                    this.checkAll = false;
                } else {
                    this.indeterminate = false;
                    this.checkAll = false;
                }
            },
            checkAllGroupChangeBond2 (data) {
                if (data.length === 3) {
                    this.indeterminate = false;
                    this.checkAll = true;
                    this.bondTypeTip = '';
                } else if (data.length > 0) {
                    this.indeterminate = true;
                    this.checkAll = false;
                    this.bondTypeTip = '';
                } else {
                    this.indeterminate = false;
                    this.checkAll = false;
                    this.bondTypeTip = '证券大类不能为空，请选择';
                }
            },
            handleSubmit (name) {
                this.$refs[name].validate((valid) => {
					const { startdate, enddate, desc, cxtype, seriesList, zqdmRows } = this.formValidate;
                    var cxtypeVaule = cxtype,
						descValue = desc,
						zqdmRowsValue = zqdmRows,
						seriesListArry = seriesList;
					//股东账号  长度10 一个大写字母  9个数字
					if(this.formValidate.desc){
						const descStr = descValue.replace(/[\r\n]/g,',');
						let descArry = descStr.split(',');
                        //判断上传股东账户不能超过2500
                        if(descArry.length>2500){
                            this.$Message.error('股东账号不能超过2500个!');
                            return;
                        }
						for(var i=0; i < descArry.length; i++){
							const descVal = descArry[i].trim();
							const descReg = /^[A-Z]{1}\d{9}/g; 
							if(!descReg.test(descVal) || descVal.length != 10){
								this.$Message.error('股东账号由一个大写字母和9个数字组成！');//AccountForm
								this.addClass(document.getElementById('AccountForm'),'ivu-form-item-error');
								return;
							}
						}
						this.removeClass(document.getElementById('AccountForm'),'ivu-form-item-error');
                        descValue = descArry;
					}
						
				    //日期
                    var startdateValue = startdate,
                        enddateValue = enddate;
						
                    if (startdateValue && enddateValue && (startdateValue.getTime() > enddateValue.getTime())) {
                        document.getElementById('startDateForm').className += ' ivu-form-item-error';
                        document.getElementById('endDateForm').className += ' ivu-form-item-error';
                        this.$Message.error('开始日期不能大于结束日期!');
                        return;
                    };
                    this.removeClass(document.getElementById('startDateForm'),'ivu-form-item-error');
                    this.removeClass(document.getElementById('endDateForm'),'ivu-form-item-error');

                    if(cxtypeVaule == '按证券代码'){
                        var textareaBond1 = document.getElementById('codeInput'),
                            textareaBond1Body = textareaBond1.getElementsByTagName('textarea')[0];
                        this.formValidate.seriesList = [];
                        if (textareaBond1Body.value == '') {
                           this.addClass(textareaBond1, 'ivu-form-item-error');
                           return;
                        };
						//证券代码由 6个数字组成
						if(this.formValidate.zqdmRows){
                            //证券代码为 ALL
                            if(this.formValidate.zqdmRows == "ALL" || this.formValidate.zqdmRows == "all" || this.formValidate.zqdmRows == "All"){
                                zqdmRowsValue = ["ALL"];
                            }else{
                                const zqdmRowsStr = zqdmRowsValue.replace(/[\r\n]/g,',');
                                let zqdmRowsArry = zqdmRowsStr.split(',');
                                //判断上传证券代码不能超过1000
                                if(zqdmRowsArry.length>1000){
                                    this.$Message.error('证券代码不能超过1000个!');
                                    return;
                                }
                                for(var i=0; i < zqdmRowsArry.length; i++){
                                    const zqdmRowsVal = zqdmRowsArry[i].trim();
                                    const zqdmRowsReg = /\d{6}/g; 
                                    if(!zqdmRowsReg.test(zqdmRowsVal) || zqdmRowsVal.length != 6){
                                        this.$Message.error('证券代码由6个数字组成！！');
                                        this.addClass(textareaBond1,'ivu-form-item-error');
                                        return;
                                    }
                                }
                                this.removeClass(textareaBond1,'ivu-form-item-error');
                                zqdmRowsValue = zqdmRowsArry;
                            }
						}
                        this.removeClass(textareaBond1, 'ivu-form-item-error');
                    }else if(cxtypeVaule == '按证券大类'){
                        if(this.formValidate.seriesList.length == 0){
                            this.bondTypeTip = '证券大类不能为空，请选择';
                            return;
                        }
                    } else if(cxtypeVaule == '按所有证券'){
                        this.formValidate.seriesList = [];
                    }
					//验证
                    if (valid) {
						const  bsf = {'债券': 'BON','基金': 'FUN','股票': 'EQU'};
						let bsfWord = '';
						let arry = [];
						if(cxtypeVaule == '按证券代码'){
						    this.formValidate.seriesList = [];
						} else if(cxtypeVaule == '按证券大类'){
							if(seriesList.length){
								for (var i = 0; i < seriesList.length; i++) {
								   arry.push(bsf[seriesList[i]])
								}
								bsfWord = arry;
							}
						} else if(cxtypeVaule == '按所有证券'){
							this.formValidate.seriesList = [];
						}
					    //日期格式
					    const startdateFormat = startdateValue.format('yyyyMMdd');
                        const enddateFormat = enddateValue.format('yyyyMMdd');
						//证券大类提示
                        this.bondTypeTip = '';
						//提交提示
                        this.$Message.success('提交成功!请等待~');
                        this.addClass(document.getElementById("sorryBox"),"hide");
                        this.addClass(document.getElementById("dealPanel").getElementsByClassName("ivu-collapse-item-active")[0],"ivu-collapse-item");
                        document.getElementById("dealPanel").getElementsByClassName("ivu-collapse-content")[0].style.display="none";
                        this.removeClass(document.getElementById("resultBox"),"hide");

                        //维度运算数据恢复初始值
                        this.formValidate2.wdCheck=['股东账户','股东名称','交易日期','会员营业部','证券代码','证券简称'];
                        this.checkAllGroup=['买成交数量（合计）', '买成交数量占比','买成交金额（合计）','卖成交数量（合计）','卖成交数量占比','卖成交金额（合计）'];
                        this.czrows=20;
                        this.wdChange();
                        this.dealTable=[		
                        {
                            "title": "股东账户",
                            "key": "acctId",
                            "fixed": "left",
                            "width": 200
                        },
                        {
                            "title": "股东名称",
                            "key": "acctName",
                            "width": 150,
                        },
                        {
                            "title": "交易日期",
                            "key": "tradeDate",
                            "width": 150,
                        },
                        {
                            "title": "会员营业部",
                            "key": "memBranchName",
                            "width": 150,
                        },
                        {
                            "title": "证券代码",
                            "key": "secCode",
                            "width": 150,
                        },
                        {
                            "title": "证券简称",
                            "key": "secName",
                            "width": 150,
                        },
                        {
                            "title": "买成交数量（合计）",
                            "key": "buyVol",
                            "width": 150,
                        },
                        {
                            "title": "买成交数量占比",
                            "key": "buyRatio",
                            "width": 150,
                        },
                        {
                            "title": "买成交金额（合计）",
                            "key": "buyAmt",
                            "width": 150,
                        },
                        {
                            "title": "买成交价格（合计）",
                            "key": "buyPrice",
                            "width": 150,
                        },
                        {
                            "title": "卖成交数量（合计）",
                            "key": "sellVol",
                            "width": 150,
                        },
                        {
                            "title": "卖成交数量占比",
                            "key": "sellRatio",
                            "width": 150,
                        },
                        {
                            "title": "卖成交金额（合计）",
                            "key": "sellAmt",
                            "width": 150,
                        } ,
                        {
                            "title": "卖成交价格（合计）",
                            "key": "sellPrice",
                            "width": 150,
                        }
                    ]

                        this.removeClass(document.getElementById("dealPanel").getElementsByClassName("ivu-collapse-item")[0],"ivu-collapse-item-active");
						this.searchPanel = '';

                        searchParams={
                            "startDate":startdateFormat,"endDate":enddateFormat,"accountId":descValue,
                            "limit":this.formValidate.showrow.toString(),"userId":getUrlParams(urlParams).userId,
                            "userName":getUrlParams(urlParams).userName 
                        }
					    //instrument_id   //证券代码 //证券大类 //按所有证券
					    if(zqdmRowsValue){
                            searchParams.secCode=zqdmRowsValue;
                        }else if(bsfWord){
                            searchParams.secType=bsfWord;
                        }else{
                            searchParams.allType="ALL";
                        }

                        //声明加载中
                        var loadBox = document.getElementById("loadBox");
                        this.removeClass(loadBox,"hide");
						//接口请求处理  dealTableData
						const url = '/dwapp/mktdt/acct_trd_details';
					
						this._fetch(fetch(url, {
                            method: "POST",
                            body: JSON.stringify(searchParams),
                            mode: 'cors',
                            headers: {
                                "Content-Type": "application/json",
                                "signature":getUrlParams(urlParams).signature
                            }
                        }), 1800000).then(function (response) {
							return response.json()
						}, function (error) {
							this.$Message.error('系统繁忙，刷新页面!');
						}).then(data => {
                            var exportButton1 = document.getElementById("exportCurrent"),
                                exportButton2 = document.getElementById("exportListCsv"),
                                exportButton3 = document.getElementById("exportListExcel"),
                                exportButton4 = document.getElementById("exportListDbf");

                            //取数据
                            var dataResponse=data.resData;
                            var dataError=data.message;
                            var datalength = data.respSize;

                            if(dataResponse == null){
                                //展开查询框
                                this.addClass(document.getElementById("dealPanel").getElementsByClassName("ivu-collapse-item")[0],"ivu-collapse-item-active");
						        this.searchPanel = '1';

                                this.addClass(loadBox,"hide");
                                this.$Message.warning("查询出错"+dataError);
                                this.dealTableData = [];
                                this.dealitems = 0;
                                this.showdealitems = 0;

                                exportButton1.setAttribute("disabled",true);
                                exportButton2.setAttribute("disabled",true);
                                exportButton3.setAttribute("disabled",true);
                                exportButton4.setAttribute("disabled",true);

                            }else{
                                if(dataResponse.length == 0){
                                    this.addClass(loadBox,"hide");
                                    this.$Message.warning('查询无数据！');

                                    this.dealTableData = [];
                                    this.dealitems = 0;
                                    this.showdealitems = 0;

                                    exportButton1.setAttribute("disabled",true);
                                    exportButton2.setAttribute("disabled",true);
                                    exportButton3.setAttribute("disabled",true);
                                    exportButton4.setAttribute("disabled",true);
                                }else{
                                    var dataArray=[];
                                    this.dealitems = datalength;
                                    this.wdMax = this.formValidate.showrow;

                                    for(var i=0;i<dataResponse.length;i++){
                                        var dataRow={};
                                        for(var key in dataResponse[i]){
                                            dataRow[key] = dataResponse[i][key];
                                        }
                                        dataArray.push(dataRow);
                                    }
                                    this.dealTableData = dataArray;
                                    wdTableData = dataArray;
                                    this.showdealitems = this.dealTableData.length;

                                    exportButton1.removeAttribute("disabled");
                                    exportButton2.removeAttribute("disabled");
                                    exportButton3.removeAttribute("disabled"); 
                                    exportButton4.removeAttribute("disabled");

                                    //隐藏加载中
                                    this.addClass(loadBox,"hide");

                                }

                            }

						})

                    } else {
                        this.$Message.error('表单验证失败!');
                    }
                })
            },
            clearOne:function(){
                this.formValidate.desc="";
                this.accountList=0;
            },
            clearTwo:function(){
                this.formValidate.zqdmRows="";
                this.codeList=0;
            },
            showzq:function(){
                var zqseries = document.getElementById('zqseries'),
                zqcode = document.getElementById('zqcode'); 
                if(this.formValidate.cxtype=="按证券代码"){
                    this.addClass(zqseries, "hide"); 
                    this.removeClass(zqcode, "hide");
                    this.bondTypeTip = '';            
                }
                if(this.formValidate.cxtype=="按证券大类"){
                    this.removeClass(zqseries, "hide"); 
                    this.addClass(zqcode, "hide");
                    this.formValidate.zqdmRows="";
                    this.formValidate.seriesList = ['债券','基金','股票'];
                }
                if(this.formValidate.cxtype=="按所有证券"){
                    this.addClass(zqseries, "hide"); 
                    this.addClass(zqcode, "hide");
                    this.formValidate.zqdmRows="";
                    this.bondTypeTip = ''; 
                }
            },
			//股东账号导入
			handleSuccessAccount(response, file, fileList){
				const arry = response.resData;
				let str = '';
				let  arryAll= [];
				for(var i = 0; i < arry.length; i++){
				    arryAll.push(arry[i]);
				}
				this.accountList = arryAll.length;
				str = arryAll.join('\n');
			    this.formValidate.desc = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
			},
			//证券代码导入
			handleSuccessCode(response, file, fileList){
			    const arry = response.resData;
				let str = '';
				let  arryAll= [];
				for(var i = 0; i < arry.length; i++){
				    arryAll.push(arry[i]);
				}
				this.codeList = arryAll.length
				str = arryAll.join('\n');
			    this.formValidate.zqdmRows = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
			},
        }
    }
</script>