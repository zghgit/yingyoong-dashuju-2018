<template>
    <section class="constWidth">
        <!--头部logo-->
        <header></header>
        <h2 class="infoTitle">成交明细及对手方信息查询</h2>
        <div class="mainBox">
            <Row :gutter="16">
                <Col span="19">
                    <Card style="min-height:780px">
                        <router-link to="/showInfo1">
                            <span class="lookInfo">查看统计口径</span>
                        </router-link>
                        <p id="infoTableList" class="redtext listlength">查询结果共&nbsp;{{dealitems}}&nbsp;条记录</p>
                        <Spin id="loadBox" fix class="loadBox hide">
                            <Icon type="load-c" size=40 class="loadIcon"></Icon>
                            <div>&nbsp;&nbsp;&nbsp;数据加载中...</div>
                        </Spin>
                        <Table @on-sort-change="infoTableSort" id="infoTable" :context="self" :data="tableData1" :columns="tableColumns1" size="small" ref="table" border stripe></Table>
                        <div style="text-align:center;margin-top:46px;margin-bottom:10px;">
                            <Button id="exportCurrent" type="primary" size="large" @click="exportData(1)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为CSV文件</Button>
                            <Button id="exportAll" type="primary" size="large" @click="exportData(2)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为XLSX文件</Button>
                            <Button id="exportDbf" type="primary" size="large" @click="exportData(3)" disabled><Icon type="ios-download-outline"></Icon> 导出全部结果为DBF文件</Button>
                        </div>
                        
                    </Card>
                </Col>
                <Col span="5" class="infoRightCard">
                    <Card style="min-height:780px">
                        <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
                        <b>开始日期</b>
                        <Form-item prop="startdate" id="startDateForm">
                            <Date-picker id="startDate" type="date" :options="startOption" placeholder="选择开始日期" v-model="formValidate.startdate"></Date-picker>
                        </Form-item>
                        <b>结束日期</b>
                        <Form-item prop="enddate" id="endDateForm">
                            <Date-picker id="endDate" type="date" :options="endOption" placeholder="选择结束日期" v-model="formValidate.enddate"></Date-picker>
                        </Form-item>
                        <b>股东账号</b><label class="redtext fontsize12">（不超过2500个）</label>
                        <Row class="uploadBox">
                            <Upload action="/base-service/api/decode_upfile?uploadType=ACCID" :headers="upfileParams" accept=".txt" :on-success="handleSuccessAccount">
                                <Button id="importAccountBtn" type="ghost">导入</Button>
                            </Upload>
                            <Button id="clearAccountBtn" v-on:click="clearOne()">清空</Button>
                        </Row>
                        <Row>
                            <p>已上传个数：<font id="infoUploadAccount" class="bluetext">{{accountList}}</font></p>
                            <Form-item prop="desc" id="AccountForm">
                                <Input  id="AccountInput" v-model="formValidate.desc" @on-change="accountListChange" type="textarea" :rows="4" placeholder="请输入股东账号"></Input>
                            </Form-item>
                        </Row>
                        <row><b>统计对象</b></row>
                        <Radio-group v-model="formValidate.cxtype" class="zqradio" v-on:on-change="showzq">
                            <row>
                                <Radio id="codeRadio" label="按证券代码"></Radio><label class="redtext fontsize12">（不超过1000个）</label>
                                <div id="zqcode">
                                    <Row class="uploadBox">
                                        <Upload action="/base-service/api/decode_upfile?uploadType=SECCODE" :headers="upfileParams" accept=".txt" :on-success="handleSuccessCode">
                                            <Button id="importcodeBtn" type="ghost">导入</Button>
                                        </Upload>
                                        <Button id="clearcodeBtn" v-on:click="clearTwo()">清空</Button>
                                    </Row>
                                    <Row>
                                        <p>已上传个数：<font id="infoUploadCode" class="bluetext">{{codeList}}</font></p>
                                        <Input id="codeInput" v-model="formValidate.zqdmRows" @on-change="codeListChange" type="textarea" :rows="4" placeholder="请输入..."></Input>
                                        
                                    </Row>
                                    <p class="zqCodeTip">{{zqCodeTip}}</p>
                                </div>
                            </row>
                            <row>
                                <Radio  id="typeRadio" label="按证券大类"></Radio>
                                <div id="zqseries" class="hide">
                                    <Checkbox-group v-model="formValidate.seriesList" @on-change="bondTypeCheckChange">
                                        <Checkbox id="zqcheckbox" label="债券"></Checkbox><br>
                                        <Checkbox id="jjcheckbox" label="基金"></Checkbox><br>
                                        <Checkbox id="gpcheckbox" label="股票"></Checkbox><br>
                                    </Checkbox-group>
                                    <p class="zqCodeTip">{{zqTypeTip}}</p>
                                </div>
                            </row>
                            <row><Radio  id="allRadio" label="按所有证券"></Radio></row>
                        </Radio-group>
                        <Form-item class="showrow" prop="showrow">
                            在页面上显示前&nbsp;&nbsp;<Input-number id="showrowInput" :max="200" :min="1" v-model="formValidate.showrow" size="small" style="width: 70px;"></Input-number>&nbsp;&nbsp;行
                            <p><label class="redtext fontsize12">(最多显示200行)</label></p>
                        </Form-item>
                        <Form-item>
                            <div class="cxBox"><Button id="searchBtn" type="primary" @click="handleSubmit('formValidate');">查询</Button></div>
                        </Form-item>     
                        
                    </Form>

                    </Card>
                </Col>
            </Row>

        </div>
    </section>
</template>
<script>
import 'whatwg-fetch';  

//获取URL地址参数
var urlParams=window.location.href;
var upfileParamsValue={};
upfileParamsValue.signature=getUrlParams(urlParams).signature;

function getUrlParams(url){
    var urlArray=url.split("?")[1].split("&"),
    urlValue={};
    for(var i=0;i<urlArray.length;i++){
        var urlRowArray=urlArray[i].split("=");
        urlValue[urlRowArray[0]]=urlRowArray[1];
    }
    return urlValue;
}

//日期初始值
let lastTradeDate="";

//查询参数初始化
let testParams={};
let orderParams={};

    export default {
        
        data () {
            return {
                //文件解析参数
                upfileParams:upfileParamsValue,
                dealitems:0,
                //上传股东账户条数
				accountList: 0,
				//证券代码已上传条数
				codeList: 0,
		        //开始日期
                startOption: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                //结束日期 
                endOption: {
                    disabledDate (date) {
                        return date && date.valueOf() > Date.now();
                    }
                },
                zqTypeTip:"",
                zqCodeTip:"",
                formValidate: {
                    showrow:20,
                    startdate:new Date(this.initialDate()),
                    enddate: new Date(this.initialDate()),
                    desc: '',
                    seriesList: ['债券','基金','股票'],
                    cxtype: '按证券代码',
                    zqdmRows:"",                    
                },
                ruleValidate: {
                    showrow: [
                        { required: true,type: 'number', message: '显示行数不能为空', trigger: 'blur' }
                    ],
                    startdate: [
                        { required: true, type: 'date', message: '请选择开始日期', trigger: 'change' }
                    ],
                    enddate: [
                        { required: true, type: 'date', message: '请选择结束日期', trigger: 'change' }
                    ],
                    desc: [
                        { required: true, message: '请输入股东账号', trigger: 'blur' },
                    ]
                },
                dmNumber:0,
                items:0,
                showLength:1000,
                uploadgdzh: '',
                self: this,
                tableData1: [],
                tableColumns1: [
                    {
                        title: '证券代码',
                        key: 'secCode',
                        "fixed": "left",
                        "width": 200,
                        sortable: true,
                    },
                    {
                        title: '证券简称',
                        key: 'secName',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '交易日期',
                        key: 'tradeDate',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交时间',
                        key: 'tradeTime',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交编号',
                        key: 'tradeNo',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交价格',
                        key: 'tradePrice',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交数量',
                        key: 'tradeVol',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '成交金额',
                        key: 'tradeAmt',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方股东代码',
                        key: 'buyAcctId',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方股东名称',
                        key: 'buyAcctName',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方会员营业部',
                        key: 'buyBranchName',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '买方交易PBU',
                        key: 'buyPbuId',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方股东代码',
                        key: 'sellAcctId',
                        "width": 150,
                        sortable: true,
                    },
                    {
                        title: '卖方股东名称',
                        key: 'sellAcctName',
                        "width": 150,
                        sortable: true,                        
                    },
                    {
                        title: '卖方会员营业部',
                        key: 'sellBranchName',
                        "width": 150,
                        sortable: true,                        
                    },
                    {
                        title: '卖方交易PBU',
                        key: 'sellPbuId',
                        "width": 150,
                        sortable: true,                        
                    },
                    
                ]
            }
        },
        methods: {
            //设置fetch请求超时方法
             _fetch:function(fetch_promise, timeout) {
                var abort_fn = null;
                var abortInfo=this;
                //这是一个可以被reject的promise
                var abort_promise = new Promise(function(resolve, reject) {
                        abort_fn = function() {
                            console.log('查询超时abort promise');
                            // abortInfo.$Message.warning('查询超时！请重试！');
                        };
                });
                //这里使用Promise.race，以最快 resolve 或 reject 的结果来传入后续绑定的回调
                var abortable_promise = Promise.race([
                        fetch_promise,
                        abort_promise
                ]);
                setTimeout(function() {
                        abort_fn();
                    }, timeout);
                return abortable_promise;
            }, 
            //股东账户已上传条数
			accountListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				let arrNew = [];
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.accountList = arr.length;
			},
			//证券代码已上传条数
			codeListChange:function(e){
			    const val = e.target.value;
				const arr = val.trim().split("\n");
				const accountReg = /[A-z]\d$/g;
				
				for(var i = 0; i < arr.length; i++){
				   if(arr[i] == '' || typeof arr[i] == 'undefined'){
				      arr.splice(i, 1);
					  i= i-1;
				   }
				}
				this.codeList = arr.length;
			},
            //股东账号导入
			handleSuccessAccount(response, file, fileList){
				const arry = response.resData;
				let str = '';
				let  arryAll= [];
				for(var i = 0; i < arry.length; i++){
					arryAll.push(arry[i]);
				}
				this.accountList = arryAll.length;
				str = arryAll.join('\n');
			    this.formValidate.desc = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
			},
			//证券代码导入
			handleSuccessCode(response, file, fileList){
			    const arry = response.resData;
				let str = '';
				let  arryAll= [];
				for(var i = 0; i < arry.length; i++){
				    arryAll.push(arry[i]);
				}
				this.codeList = arryAll.length
				str = arryAll.join('\n');
			    this.formValidate.zqdmRows = str;
                if(response.message != null){
                    this.$Message.warning(response.message);
                }
			},
            //请求初始日期
            initialDate:function(){
                var obj=new XMLHttpRequest();
                obj.open('GET','/base-service/api/predate',false);
                obj.setRequestHeader("signature",getUrlParams(urlParams).signature);
                obj.onreadystatechange=function(){
                    if(obj.readyState == 4 && obj.status == 200){
                        const responseData=JSON.parse(obj.responseText);
                        //上一个交易日
                        lastTradeDate = responseData.resData.lastTradeDate;
                        lastTradeDate = lastTradeDate.slice(0,4)+"-"+lastTradeDate.slice(4,6)+"-"+lastTradeDate.slice(6,8);
                    }
                };
                obj.send(null);
                return lastTradeDate;
            },
            //原声js写jquery方法
            hasClass:function(obj, cls){  
                return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));  
            },
            addClass:function(obj, cls){  
                if (!this.hasClass(obj, cls)) obj.className += " " + cls;  
            },
            removeClass:function(obj, cls){  
                if (this.hasClass(obj, cls)) {  
                    var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');  
                    obj.className = obj.className.replace(reg, ' ');  
                }  
            },
            toggleClass:function(obj,cls){  
                if(this.hasClass(obj,cls)){  
                    this.removeClass(obj, cls);  
                }else{  
                    this.addClass(obj, cls);  
                }  
            },
            //按证券大类单选中的多选选项变化
            bondTypeCheckChange:function(data){
                if (data.length === 3) {
                    this.zqTypeTip = '';
                } else if (data.length > 0) {
                    this.zqTypeTip = '';
                } else {
                    this.zqTypeTip = '请选择证券大类';
                }
            },
            //传排序参数
            infoTableSort:function(sort){
                orderParams.field=sort.key;
                orderParams.sort=sort.order;
            },
            //查询表单数据
            searchData:function(requestParam){
                orderParams={};
                var loadBox = document.getElementById("loadBox");
                this.removeClass(loadBox,"hide");
                const url = '/dwapp/mktdt/both_side_trd_details';

                this._fetch(fetch(url, {
                    method: "POST",
                    body: JSON.stringify(requestParam),
                    mode: 'cors',
                    headers: {
                        "Content-Type": "application/json",
                        "signature":getUrlParams(urlParams).signature
                    }
                }), 1800000).then(function (response) {
                    return response.json()
                }, function (error) {
                    this.$Message.error('系统繁忙，刷新页面!');
                }).then(data => {
                    var exportButton1 = document.getElementById("exportCurrent"),
	                    exportButton2 = document.getElementById("exportAll"),
	                    exportButton3 = document.getElementById("exportDbf");

                    //取数据
                    var dataResponse=data.resData;
                    var dataError=data.message;
                    var datalength = data.respSize;

                    if(dataResponse == null){
                        this.addClass(loadBox,"hide");
                        this.$Message.warning("查询出错"+dataError);
                        this.tableData1 = [];
                        this.dealitems = 0;

                        exportButton1.setAttribute("disabled",true);
	                    exportButton2.setAttribute("disabled",true);
	                    exportButton3.setAttribute("disabled",true);

                    }else{
                        if(dataResponse.length == 0){
                            this.addClass(loadBox,"hide");
                            this.$Message.warning('查询无数据！');
                            this.tableData1 = [];
                            this.dealitems = 0;

                            exportButton1.setAttribute("disabled",true);
                            exportButton2.setAttribute("disabled",true);
                            exportButton3.setAttribute("disabled",true);
                        }else{
                            var dataArray=[];
                            this.dealitems = datalength;

                            for(var i=0;i<dataResponse.length;i++){
                                var dataRow={};
                                for(var key in dataResponse[i]){
                                    dataRow[key] = dataResponse[i][key];
                                }
                                dataArray.push(dataRow);
                            }

                            this.tableData1 = dataArray;
                            exportButton1.removeAttribute("disabled");
                            exportButton2.removeAttribute("disabled");
                            exportButton3.removeAttribute("disabled"); 

                            this.addClass(loadBox,"hide");

                        }
                    }
                })
            },
            handleSubmit (name) {
                this.$refs[name].validate((valid) => {
                    const { startdate, enddate, desc, cxtype, seriesList, zqdmRows } = this.formValidate;
					
                    var cxtypeVaule = cxtype,
						descValue = desc,
						zqdmRowsValue = zqdmRows,
						seriesListArry = seriesList;

                    //日期
                    var startdateValue = this.formValidate.startdate,
                        enddateValue = this.formValidate.enddate;
                    if (startdateValue && enddateValue && startdateValue.getTime() > enddateValue.getTime()) {
                        document.getElementById('startDateForm').className += ' ivu-form-item-error';
                        document.getElementById('endDateForm').className += ' ivu-form-item-error';
                        this.$Message.error('开始日期不能大于结束日期!');
                        return;
                    };
                    this.removeClass(document.getElementById('startDateForm'),'ivu-form-item-error');
                    this.removeClass(document.getElementById('endDateForm'),'ivu-form-item-error');

                    //股东账号  10 一个大写字母  9个数字
					if(this.formValidate.desc){
						const descStr = descValue.replace(/[\r\n]/g,',');
						let descArry = descStr.split(',');
                        //判断上传股东账户不能超过2500
                        if(descArry.length>2500){
                            this.$Message.error('股东账号不能超过2500个!');
                            return;
                        }
						for(var i=0; i < descArry.length; i++){
							const descVal = descArry[i].trim();
							const descReg = /^[A-Z]{1}\d{9}/g; 
							if(!descReg.test(descVal) || descVal.length != 10){
								this.$Message.error('股东账号由一个大写字母和9个数字组成！');//AccountForm
								this.addClass(document.getElementById('AccountForm'),'ivu-form-item-error');
								return;
							}
						}
						this.removeClass(document.getElementById('AccountForm'),'ivu-form-item-error');
						// descValue = descArry.join(',');
                        descValue = descArry;
					}
				
                    if(cxtypeVaule == '按证券代码'){
                        var textareaBond1 = document.getElementById('codeInput'),
                            textareaBond1Body = textareaBond1.getElementsByTagName('textarea')[0];
                        this.formValidate.seriesList = [];
                        if (textareaBond1Body.value == '') {
                           this.addClass(textareaBond1, 'ivu-form-item-error');
                           this.zqCodeTip="请输入证券代码";
                           return;
                        };

                        //证券代码由 6个数字组成
						if(this.formValidate.zqdmRows){
                            //证券代码为 ALL
                            if(this.formValidate.zqdmRows == "ALL" || this.formValidate.zqdmRows == "all" || this.formValidate.zqdmRows == "All"){
                                zqdmRowsValue = ["ALL"];
                            }else{
                                const zqdmRowsStr = zqdmRowsValue.replace(/[\r\n]/g,',');
                                let zqdmRowsArry = zqdmRowsStr.split(',');
                                //判断上传证券代码不能超过1000
                                if(zqdmRowsArry.length>1000){
                                    this.$Message.error('证券代码不能超过1000个!');
                                    return;
                                }
                                for(var i=0; i < zqdmRowsArry.length; i++){
                                    const zqdmRowsVal = zqdmRowsArry[i].trim();
                                    const zqdmRowsReg = /\d{6}/g; 
                                    if(!zqdmRowsReg.test(zqdmRowsVal) || zqdmRowsVal.length != 6){
                                        this.$Message.error('证券代码由6个数字组成！！');
                                        this.addClass(textareaBond1,'ivu-form-item-error');
                                        return;
                                    }
                                }
                                this.removeClass(textareaBond1,'ivu-form-item-error');
                                zqdmRowsValue = zqdmRowsArry;
                            }
							
						}

                        this.removeClass(textareaBond1, 'ivu-form-item-error');
                        this.zqCodeTip="";

                    }else if(cxtypeVaule == '按证券大类'){
                        if(this.formValidate.seriesList.length == 0){
                            this.zqTypeTip = '证券大类不能为空，请选择';
                            return;
                        }

                    } else if(cxtypeVaule == '按所有证券'){
                        this.formValidate.seriesList = [];

                    }

                    if (valid) {
                        this.zqTypeTip = '';
                        this.$Message.success('提交成功!请等待~'); 

                        //获取请求参数
                        const  bsf = {'债券': 'BON','基金': 'FUN','股票': 'EQU'};
                        let bsfWord = '';
                        let arry = [];
                        if(cxtypeVaule == '按证券代码'){
                            this.formValidate.seriesList = [];
                        } else if(cxtypeVaule == '按证券大类'){
                            if(seriesList.length){
                                for (var i = 0; i < seriesList.length; i++) {
                                    arry.push(bsf[seriesList[i]])
                                }
                                bsfWord = arry;
                            }
                        } else if(cxtypeVaule == '按所有证券'){
                            this.formValidate.seriesList = [];
                        }
                        //日期格式
                        var startdateFormat = startdateValue.format('yyyy-MM-dd');
                        var enddateFormat = enddateValue.format('yyyy-MM-dd');

                        startdateFormat=startdateFormat.split("-").join("");
                        enddateFormat=enddateFormat.split("-").join("");

                        testParams={
                            "startDate":startdateFormat,"endDate":enddateFormat,"accountId":descValue,
                            "limit":this.formValidate.showrow.toString(),
                            "userId":getUrlParams(urlParams).userId, "userName":getUrlParams(urlParams).userName
                            }

                        if(zqdmRowsValue){
                            testParams.secCode=zqdmRowsValue;
                        }else if(bsfWord){
                            testParams.secType=bsfWord;
                        }else{
                            testParams.allType="ALL";
                        }
                        console.log(testParams,"-----testParams111111111");
                        this.searchData(testParams);
                        
                    } else {
                        this.$Message.error('表单验证失败!');
                    }
                })
            },
            clearOne:function(){
                this.formValidate.desc="";
                this.accountList=0;
            },
            clearTwo:function(){
                this.formValidate.zqdmRows="";
                this.codeList=0;
            },
            showzq:function(){
                var zqseries = document.getElementById('zqseries'),
                zqcode = document.getElementById('zqcode'); 
                if(this.formValidate.cxtype=="按证券代码"){
                    this.addClass(zqseries, "hide"); 
                    this.removeClass(zqcode, "hide");
                    this.zqTypeTip = ''; 
                    this.codeList=0; 
                }
                if(this.formValidate.cxtype=="按证券大类"){
                    this.removeClass(zqseries, "hide"); 
                    this.addClass(zqcode, "hide"); 
                    this.formValidate.zqdmRows="";
                    this.formValidate.seriesList = ['债券','基金','股票'];
                }
                if(this.formValidate.cxtype=="按所有证券"){
                    this.addClass(zqseries, "hide"); 
                    this.addClass(zqcode, "hide"); 
                    this.formValidate.zqdmRows="";
                    this.zqTypeTip = ''; 
                }
            },
            exportData (type) {
                //导出参数
                var downfileParams="&signature="+getUrlParams(urlParams).signature+
                "&userId="+getUrlParams(urlParams).userId+"&userName="+getUrlParams(urlParams).userName+
                "&sortby="+orderParams.field+"&sort="+orderParams.sort;
                if (type === 1) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=TRADEBUYANDSALE&fileType=csv'+downfileParams;                    
                } else if (type === 2) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=TRADEBUYANDSALE&fileType=xlsx'+downfileParams; 
                } else if (type === 3) {
                    window.location.href='/dwapp/download/dwapp_downfile?reportType=TRADEBUYANDSALE&fileType=dbf'+downfileParams; 
                }
            },
        }
    }
</script>